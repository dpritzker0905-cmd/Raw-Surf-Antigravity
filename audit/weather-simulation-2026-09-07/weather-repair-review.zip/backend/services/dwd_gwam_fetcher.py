"""
DWD GWAM (Global WAve Model) GLOBAL-COARSE marine fetcher — moves ICON marine off open-meteo.

ICON marine = DWD's gwam model. Open-meteo just resells it; DWD publishes it free (no auth) on
opendata.dwd.de. Moving ICON marine to DWD-direct frees its open-meteo budget (companion to the
GFS→NOAA and EURO→Copernicus migrations).

SOURCE (confirmed live):
  https://opendata.dwd.de/weather/maritime/wave_models/gwam/grib/{RUN}/{var}/GWAM_{VAR}_{YYYYMMDD}{RUN}_{FFF}.grib2.bz2
  - RUN ∈ {00, 12} (GWAM runs twice daily); FFF = f000..f174 every 3 h (~7.25 days, 59 steps).
  - global 0.25° regular lat/lon; ONE bz2-compressed single-variable GRIB2 message per (variable, hour).
  - so we download whole small files (~300 KB each) — NO .idx byte-range trick (unlike the GFS atmos file).

OUTPUT: Open-Meteo-shaped point dicts (612-pt coarse grid) with the 9 om vars for 3 layers
(waves/swell_1/wind_waves — gwam has NO secondary swell, matching the existing ICON behavior),
__provider:'dwd'. The caller keeps provider='open-meteo' so the manifest (source_dataset='dwd_gwam')
stays byte-identical to the open-meteo path — zero regression.

MASKING (the GOTCHA): GRIB land/ice cells are masked; np.asarray(masked) would leak the _FillValue as a
real number (the EURO Copernicus 10,000-ft bug). We np.ma.filled(..., NaN) + _sanitize so masked/
out-of-range cells become None.

USAGE:
  - Subprocess (production): python dwd_gwam_fetcher.py '<payload-json>' -> writes JSON to output_path.
  - Standalone verify (Render shell, no args): python backend/services/dwd_gwam_fetcher.py
    DWD_GWAM_FETCHER_QUICK=1 -> tiny region + ~2 days for a fast smoke test.
"""
import os
import sys
import json
import time
import bz2
import uuid
import tempfile
from pathlib import Path
from datetime import datetime, timezone, timedelta

BASE = "https://opendata.dwd.de/weather/maritime/wave_models/gwam/grib"
HTTP_TIMEOUT = 60

# (gwam variable dir/token, open-meteo var, unit). 3 layers; gwam has no secondary swell.
VAR_MAP = [
    ("swh",  "wave_height",                 "m"),
    ("mwd",  "wave_direction",              "°"),
    ("tm10", "wave_period",                 "s"),
    ("shts", "swell_wave_height",           "m"),
    ("mdts", "swell_wave_direction",        "°"),
    ("mpts", "swell_wave_period",           "s"),
    ("shww", "wind_wave_height",            "m"),
    ("mdww", "wind_wave_direction",         "°"),
    ("mpww", "wind_wave_period",            "s"),
]
OM_UNITS = {om: u for _, om, u in VAR_MAP}
OM_ORDER = [om for _, om, _ in VAR_MAP]

# direction variable -> the height variable that weights its energy mean (E ∝ H²). VAR_MAP lists each
# height IMMEDIATELY BEFORE its direction, so the height array is always already decoded (and retained
# for the hour) when its direction is processed. Same vortex-root fix as the GFS fetcher (2026-07-02):
# point-sampling a partition direction every 10° aliases into a rotating field; the energy-weighted
# circular mean over the 10° block (energy_mean_direction_block) is smooth + physically meaningful.
# Kill switch: DWD_GWAM_DIR_BLOCKMEAN=0 -> legacy point sampling.
DIR_TO_HEIGHT = {
    "wave_direction": "wave_height",
    "swell_wave_direction": "swell_wave_height",
    "wind_wave_direction": "wind_wave_height",
}

# SCALAR (height/period) BLOCK-MEAN over the 10° coarse block — the fix for the ENCLOSED-SEA DROPOUT
# (2026-07-22): heights were POINT-SAMPLED at the coarse cell centre (arr[r,c]). A 10° cell whose centre
# lands on a masked native cell — a coastline, a delta (Mississippi at (30,-90)), or an enclosed-sea edge
# — sampled NaN and the whole cell was dropped, so the Gulf of Mexico / Mediterranean / Gulf of California /
# Black Sea / Baltic / … went BLANK for ICON worldwide (they render correctly for GFS, which already
# block-means its heights — energy_mean_height_block, 2026-07-04). Block-mean = RMS over the block's FINITE
# (ocean) subcells, so a cell survives as long as ANY ocean subcell exists in the block; an all-NaN (true
# land) block still drops, so nothing paints on land. Periods energy-mean over the same block. This is the
# exact NOAA-coarse mechanism ported to GWAM. Kill: DWD_GWAM_SCALAR_BLOCKMEAN=0 -> legacy centre-point sampling.
HEIGHT_VARS = {"wave_height", "swell_wave_height", "wind_wave_height"}
PERIOD_TO_HEIGHT = {
    "wave_period": "wave_height",
    "swell_wave_period": "swell_wave_height",
    "wind_wave_period": "wind_wave_height",
}

try:
    from _fetch_common import (energy_mean_direction_block, energy_mean_direction_block_multi_conf,
                               energy_mean_height_block, energy_mean_scalar_block)      # script-by-path
    from _fetch_blockmean_vec import (direction_block_batch, height_block_batch,
                                      multi_dir_conf_batch, scalar_block_batch)
except ImportError:
    from services._fetch_common import (energy_mean_direction_block, energy_mean_direction_block_multi_conf,
                                        energy_mean_height_block, energy_mean_scalar_block)  # package context
    from services._fetch_blockmean_vec import (direction_block_batch, height_block_batch,
                                               multi_dir_conf_batch, scalar_block_batch)


def _vector_blockmean() -> bool:
    """Same switch, same semantics, same oracle as the NOAA lane (noaa_gfs_wave_fetcher:65).

    MEASURED at HEAD on this lane's real variable mix (3 height + 3 scalar + 2 direction +
    1 multi_conf), 721x1440 native, 30% NaN, both paths warmed:
        global_mid  half=4  14,940 pts x 57 steps -> 10.10x, ~90.1 s saved per run, 24.2 MB peak
        pilot       half=1     609 pts x 17 steps -> 76.26x, ~1.0 s
        coarse      half=20    612 pts x 57 steps ->  1.13x, ~0.9 s
    ⚠️ The audit's "coarse LOSES 0.8x" did not replicate -- coarse is a small win -- so there is no
    resolution gate here. ⛔ But the coarse saving is ~1 s: this is worth having on global_mid and is
    noise elsewhere. Read PER CALL, not at import, so it stays flippable at runtime.
    Kill: FETCH_VECTOR_BLOCKMEAN=0 restores the per-point loop, which is retained, not deleted."""
    return os.environ.get("FETCH_VECTOR_BLOCKMEAN", "1") != "0"

# §0B-a render-confidence export for the TOTAL direction (parity with the NOAA coarse fetcher,
# wired 2026-07-15): the FE fades crest rendering below ~0.65 confidence, but only when the field
# is present (absent → full confidence → ICON coarse crests rendered confidently wrong in bimodal
# water, same class as the EURO 07-14 wrong-direction report). Single-pair multi_conf yields the
# IDENTICAL direction as energy_mean_direction_block plus the circular resultant length R.
# The normalizer picks up "{direction_key}_confidence" generically. Kill: DWD_GWAM_DIR_CONFIDENCE=0.
DIR_CONFIDENCE_OM = "wave_direction_confidence"


def _coarse_axis(lo, hi, step):
    """Delegates to the ONE inclusive axis truth (fencepost round 2, 2026-07-18): the inlined
    exclusive copy under-supplied the east column + north row vs the normalizer's inclusive grid
    (dead-edge stripe class). Full-wrap 360° lon stays exclusive inside coarse_axis."""
    try:
        from _fetch_common import coarse_axis            # script-by-path
    except ImportError:
        from services._fetch_common import coarse_axis   # package context
    return coarse_axis(lo, hi, step)


def _sanitize_om(om, x):
    """Drop NaN (incl. masked land/ice) AND physically-impossible values -> None (no fill-value leaks)."""
    if x != x:  # NaN
        return None
    x = float(x)
    if "height" in om:
        return round(x, 4) if 0.0 <= x <= 30.0 else None
    if "period" in om:
        return round(x, 4) if 0.0 <= x <= 40.0 else None
    if "direction" in om:
        return round(x, 4) if 0.0 <= x <= 360.0 else None
    return round(x, 4)


def _pick_cycle(requests, now, max_f):
    """Probe DWD newest-first for a COMPLETE GWAM run (f000 + the requested last hour present for swh).
    GWAM runs 00/12Z, lands ~5-6 h after. Returns (cycle_dt, yyyymmdd, run) or (None, None, None)."""
    cands = []
    for d in range(0, 3):
        day = now - timedelta(days=d)
        for run in ("12", "00"):
            cyc = day.replace(hour=int(run), minute=0, second=0, microsecond=0)
            if cyc <= now:
                cands.append(cyc)
    cands.sort(reverse=True)  # newest first
    for cyc in cands:
        date = cyc.strftime("%Y%m%d")
        run = cyc.strftime("%H")
        pfx = f"{BASE}/{run}/swh/GWAM_SWH_{date}{run}_"
        try:
            r0 = requests.head(f"{pfx}000.grib2.bz2", timeout=HTTP_TIMEOUT)
            rN = requests.head(f"{pfx}{max_f:03d}.grib2.bz2", timeout=HTTP_TIMEOUT)
            if r0.status_code == 200 and rN.status_code == 200:
                return cyc, date, run
        except Exception:
            continue
    return None, None, None


def _download_grib(requests, url, tmp):
    """GET a .grib2.bz2, decompress, write a temp .grib2, return its path (or None)."""
    r = requests.get(url, timeout=HTTP_TIMEOUT)
    if r.status_code != 200 or not r.content:
        raise RuntimeError(f"GET {url} -> HTTP {r.status_code}")
    raw = bz2.decompress(r.content)
    out = tmp / f"gwam_{uuid.uuid4().hex}.grib2"
    with open(out, "wb") as fh:
        fh.write(raw)
    return out


def fetch_global_coarse(payload):
    """Return (points_or_regions, steps_ok, steps_failed, times) for the global grid via DWD GWAM.

    MULTI-BBOX (2026-07-13, single-download-pass): DWD publishes whole-globe files per (var, hour)
    with no spatial byte-range, so per-region fetch passes re-download identical bytes — the pilots
    lane blew its budget the first time the ICON pilot ran 4 regions (run 29249603524 post-mortem).
    A payload `bboxes: {region_id: bbox}` samples EVERY region from each decoded field in ONE pass:
    N regions for one region's download cost. Returns ({region_id: [points]}, ...) in multi mode;
    the legacy single-`bbox` path is unchanged (list of points)."""
    import numpy as np
    # POOLED, not the module: same .get/.head, one handshake instead of one per call (~346 ms/call
    # measured vs NOMADS). See _fetch_common.http_session. Kill: FETCH_HTTP_SESSION=0.
    try:
        from _fetch_common import http_session           # script-by-path
    except ImportError:
        from services._fetch_common import http_session  # package context
    requests = http_session()
    import pygrib
    import gc

    multi = payload.get("bboxes") or None            # {region_id: bbox} -> multi-region mode
    regions = dict(multi) if multi else {"__single__": payload["bbox"]}
    resolution = float(payload.get("resolution", 10.0))
    forecast_days = int(payload.get("forecast_days", 7))
    max_f = min(int(forecast_days) * 24, 174)

    axes = {}    # rid -> (lats, lons)
    for rid, bb in regions.items():
        axes[rid] = (_coarse_axis(float(bb["south"]), float(bb["north"]), resolution),
                     _coarse_axis(float(bb["west"]), float(bb["east"]), resolution))
    f_hours = list(range(0, max_f + 1, 3))

    cycle_dt, date, run = _pick_cycle(requests, datetime.now(timezone.utc), max_f)
    if not date:
        sys.stderr.write("[dwd_gwam_fetcher] no complete GWAM run found on DWD opendata\n")
        return ({} if multi else []), 0, 0, None

    tmp = Path(tempfile.gettempdir())
    # Native GWAM grid is global 0.25° -> half-block in native cells; longitude always wraps.
    blockmean = os.environ.get("DWD_GWAM_DIR_BLOCKMEAN", "1") != "0"
    export_confidence = blockmean and os.environ.get("DWD_GWAM_DIR_CONFIDENCE", "1") != "0"
    # Height/period block-mean (enclosed-sea dropout fix, see HEIGHT_VARS note). Default ON.
    scalar_blockmean = os.environ.get("DWD_GWAM_SCALAR_BLOCKMEAN", "1") != "0"
    half = max(1, int(round(resolution / 0.25 / 2.0)))
    # The confidence series is initialized WITH the variables so failed steps keep it time-aligned.
    series_keys = OM_ORDER + ([DIR_CONFIDENCE_OM] if export_confidence else [])
    series_by = {rid: [{om: [] for om in series_keys} for _ in range(len(la) * len(lo))]
                 for rid, (la, lo) in axes.items()}
    idx_by = None    # rid -> [(r, c), ...] built together on the first decoded message
    times = []
    steps_ok = 0
    steps_failed = 0

    for f in f_hours:
        target_len = steps_ok + steps_failed + 1
        # Height arrays retained for THIS hour so each direction variable can energy-weight its block
        # mean (VAR_MAP orders every height immediately before its direction). Reset per hour.
        height_arrs = {}
        try:
            # Decode each variable's single-message file for this forecast hour ONCE; sample all regions.
            for var, om, _u in VAR_MAP:
                url = f"{BASE}/{run}/{var}/GWAM_{var.upper()}_{date}{run}_{f:03d}.grib2.bz2"
                out = None
                try:
                    out = _download_grib(requests, url, tmp)
                    grbs = pygrib.open(str(out))
                    msg = grbs.read()[0]
                    if idx_by is None:
                        glats, glons = msg.latlons()
                        lat1d = np.asarray(glats[:, 0], dtype=float)
                        lon1d = np.asarray(glons[0, :], dtype=float)
                        is_360 = bool(lon1d.max() > 180.0)
                        idx_by = {}
                        for rid, (lats, lons) in axes.items():
                            im = []
                            for la in lats:
                                r = int(np.abs(lat1d - la).argmin())
                                for lo in lons:
                                    tlon = (lo % 360.0) if is_360 else lo
                                    c = int(np.abs(lon1d - tlon).argmin())
                                    im.append((r, c))
                            idx_by[rid] = im
                    arr = np.ma.filled(np.ma.asarray(msg.values).astype(float), np.nan)
                    grbs.close()
                    if om in DIR_TO_HEIGHT.values():
                        height_arrs[om] = arr
                    h_arr = height_arrs.get(DIR_TO_HEIGHT[om]) if (blockmean and om in DIR_TO_HEIGHT) else None
                    is_height = scalar_blockmean and om in HEIGHT_VARS
                    p_h_arr = height_arrs.get(PERIOD_TO_HEIGHT[om]) if (scalar_blockmean and om in PERIOD_TO_HEIGHT) else None
                    _conf_here = export_confidence and om == "wave_direction"
                    for rid, im in idx_by.items():
                        series = series_by[rid]
                        # ── VECTORIZED PATH (FETCH_VECTOR_BLOCKMEAN) ──────────────────────────────
                        # The branch is chosen per-VARIABLE above (`h_arr`, `is_height`, `p_h_arr`,
                        # `_conf_here` are all loop-invariant here), so it hoists out of the point
                        # loop exactly as it does in the NOAA lane. Each batch form vectorizes only
                        # the INTERIOR points and DELEGATES clamped edge rows to the scalar function
                        # handed to it — which is what makes the result identical rather than close.
                        # The scalar loop below is the permanent oracle, not dead code.
                        if _vector_blockmean() and im:
                            _rs = np.fromiter((p[0] for p in im), dtype=np.intp, count=len(im))
                            _cs = np.fromiter((p[1] for p in im), dtype=np.intp, count=len(im))
                            _vals = _confs = _present = None
                            if h_arr is not None and _conf_here:
                                _vals, _confs, _present = multi_dir_conf_batch(
                                    [(arr, h_arr)], arr, _rs, _cs, half, True,
                                    lambda _r, _c, _h=half: energy_mean_direction_block_multi_conf(
                                        [(arr, h_arr)], arr, _r, _c, _h, True))
                            elif h_arr is not None:
                                _vals = direction_block_batch(
                                    arr, h_arr, _rs, _cs, half, True,
                                    lambda _r, _c, _h=half: energy_mean_direction_block(
                                        arr, h_arr, _r, _c, _h, True))
                            elif is_height:
                                _vals = height_block_batch(
                                    arr, _rs, _cs, half, True,
                                    lambda _r, _c, _h=half: energy_mean_height_block(
                                        arr, _r, _c, _h, True))
                            elif p_h_arr is not None:
                                _vals = scalar_block_batch(
                                    arr, p_h_arr, _rs, _cs, half, True,
                                    lambda _r, _c, _h=half: energy_mean_scalar_block(
                                        arr, p_h_arr, _r, _c, _h, True))
                            if _vals is not None:
                                for pi in range(len(im)):
                                    _x = float(_vals[pi])
                                    if _confs is not None:
                                        # ⭐ `conf_present` carries the scalar's `None` — "no
                                        # blockwise evidence" — which NaN cannot represent. Folding
                                        # it to NaN would make "not sampled" look like "computed and
                                        # undefined", the conflation the refusal rules exist to stop.
                                        _cv = float(_confs[pi])
                                        series[pi][DIR_CONFIDENCE_OM].append(
                                            round(_cv, 4) if bool(_present[pi]) else None)
                                    # ⛔ PASS THE RAW VALUE — `_sanitize_om` owns the NaN test.
                                    # This line originally read `_x if _x == _x else None`, a
                                    # "defensive" NaN->None normalisation, and THAT was the bug:
                                    # `_sanitize_om`'s guard is `if x != x`, and `None != None` is
                                    # **False**, so None slipped past it into `float(None)` ->
                                    # TypeError -> the enclosing `except` nulled the ENTIRE variable
                                    # for that forecast hour. Measured: 53,136 differing cells, ALL
                                    # of them num->None, zero None->num, zero numeric.
                                    # ★ The conversion was the defect. The scalar path below passes
                                    # the raw value for exactly this reason.
                                    series[pi][om].append(_sanitize_om(om, _x))
                                continue
                        for pi, (r, c) in enumerate(im):
                            if h_arr is not None and _conf_here:
                                x, conf = energy_mean_direction_block_multi_conf([(arr, h_arr)], arr, r, c, half, True)
                                series[pi][DIR_CONFIDENCE_OM].append(round(float(conf), 4) if conf is not None else None)
                            elif h_arr is not None:
                                x = energy_mean_direction_block(arr, h_arr, r, c, half, True)
                            elif is_height:
                                # RMS of the block's finite (ocean) subcells — survives enclosed-sea cells
                                # whose 10° centre lands on masked land; all-NaN (true land) still drops.
                                x = energy_mean_height_block(arr, r, c, half, True)
                            elif p_h_arr is not None:
                                x = energy_mean_scalar_block(arr, p_h_arr, r, c, half, True)
                            else:
                                x = arr[r, c]
                                if _conf_here:  # point sample: no blockwise evidence either way
                                    series[pi][DIR_CONFIDENCE_OM].append(None)
                            series[pi][om].append(_sanitize_om(om, x))
                except Exception as ve:
                    # one variable failed this hour -> None for it; keep series lengths aligned
                    # (the confidence series rides wave_direction, so it aligns here too)
                    _keys = [om] + ([DIR_CONFIDENCE_OM] if (export_confidence and om == "wave_direction") else [])
                    for series in series_by.values():
                        for pt in series:
                            for k in _keys:
                                if len(pt[k]) < target_len:
                                    pt[k].append(None)
                    sys.stderr.write(f"[dwd_gwam_fetcher] {var} f{f:03d} failed: {type(ve).__name__}: {ve}\n")
                finally:
                    try:
                        if out and out.exists():
                            out.unlink()
                    except Exception:
                        pass
            times.append((cycle_dt + timedelta(hours=f)).strftime("%Y-%m-%dT%H:%M:%SZ"))
            steps_ok += 1
        except Exception as e:
            for series in series_by.values():
                for pt in series:
                    for om in series_keys:
                        if len(pt[om]) < target_len:
                            pt[om].append(None)
            times.append((cycle_dt + timedelta(hours=f)).strftime("%Y-%m-%dT%H:%M:%SZ"))
            steps_failed += 1
            sys.stderr.write(f"[dwd_gwam_fetcher] f{f:03d} failed: {type(e).__name__}: {e}\n")
        finally:
            gc.collect()

    if idx_by is None:
        return ({} if multi else []), 0, steps_failed, None

    def _assemble(rid):
        lats, lons = axes[rid]
        series = series_by[rid]
        points = []
        pi = 0
        for la in lats:
            for lo in lons:
                hourly = {"time": times}
                for om in series_keys:
                    hourly[om] = series[pi][om]
                points.append({
                    "latitude": float(la), "longitude": float(lo),
                    "generationtime_ms": 0, "utc_offset_seconds": 0,
                    "timezone": "GMT", "timezone_abbreviation": "GMT", "elevation": 0,
                    "__provider": "dwd", "__model_run_time": cycle_dt.isoformat(),
                    "hourly_units": {"time": "iso8601", **OM_UNITS,
                                     **({DIR_CONFIDENCE_OM: "fraction"} if export_confidence else {})},
                    "hourly": hourly,
                })
                pi += 1
        return points

    if multi:
        return {rid: _assemble(rid) for rid in regions}, steps_ok, steps_failed, times
    return _assemble("__single__"), steps_ok, steps_failed, times


def main():
    if len(sys.argv) >= 2:
        payload = json.loads(sys.argv[1])
    else:
        quick = os.environ.get("DWD_GWAM_FETCHER_QUICK", "") == "1"
        days = int(os.environ.get("DWD_GWAM_FETCHER_DAYS", "2" if quick else "7"))
        bbox = ({"west": -80.0, "south": 20.0, "east": -40.0, "north": 40.0} if quick
                else {"west": -180.0, "south": -80.0, "east": 180.0, "north": 85.0})
        payload = {"bbox": bbox, "resolution": 10.0, "forecast_days": days, "output_path": ""}

    t0 = time.time()
    points, ok, failed, times = fetch_global_coarse(payload)
    elapsed = time.time() - t0

    out_path = payload.get("output_path", "")
    # Multi-region mode: `points` is {region_id: [points]} -> wrap in the keyed envelope the
    # multi service fns unwrap; flatten for the summary stats. Single mode unchanged (plain list).
    is_multi = isinstance(points, dict)
    out_obj = {"__multi_region__": True, "regions": points} if is_multi else points
    flat = [p for pts in points.values() for p in pts] if is_multi else points

    if out_path and flat:
        with open(out_path, "w") as f:
            json.dump(out_obj, f)

    nz = 0
    sample_max = None
    if flat:
        wh = [v for p in flat for v in p["hourly"].get("wave_height", []) if v is not None]
        nz = sum(1 for v in wh if v and v > 0)
        sample_max = max(wh) if wh else None
    print(f"SUMMARY: regions={len(points) if is_multi else 1} points={len(flat)} steps_ok={ok} "
          f"steps_failed={failed} "
          f"timesteps={len(times) if times else 0} forecast_end={times[-1] if times else '?'} "
          f"wave_height_nonzero={nz} wave_height_max={sample_max} elapsed={elapsed:.1f}s "
          f"wrote={'yes:'+out_path if (out_path and flat) else 'no(standalone)'}")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        import traceback
        print(f"ERROR: {e}")
        traceback.print_exc()
        sys.exit(1)
