import math
import logging
from services.weather_pipeline.cycle_provenance import time_provenance
from typing import Optional, Dict, Any, Tuple, List
from services.weather_pipeline.schemas import (
    NormalizedProduct, NormalizedPointDetail, NormalizedPointResponse
)

logger = logging.getLogger(__name__)


def deduce_grid_resolution(grid) -> float:
    """Grid spacing in degrees, or 0.0 when it cannot be deduced.

    THE canonical definition (WS-CAN-0014, 2026-08-13). It previously lived as a staticmethod on
    PointResolutionService, which now delegates here, so the quantity has ONE producer rather than
    a copy per consumer.
    """
    if not grid or not grid.vectors:
        return 0.0
    lats = sorted(set(v.lat for v in grid.vectors))
    if len(lats) > 1:
        return round(lats[1] - lats[0], 4)
    lons = sorted(set(v.lng for v in grid.vectors))
    return round(lons[1] - lons[0], 4) if len(lons) > 1 else 0.0


def resolution_or_none(grid):
    """The value as it must appear ON THE WIRE: a real spacing, or None.

    ⛔ WS-CAN-0014. `resolution` was declared on NormalizedPointResponse and NEVER populated —
    measured live 2026-08-13, `null` at four geographies including two `inside_regional_tile`
    responses where the spacing is known. The consumer half was built anyway:
    backendWeatherServiceClientDiag.js:203-210 derives it from served grid bounds and labels it
    `resolutionSource`, which is a good fallback and a bad permanent contract, and TruthOverlay's
    `COARSE n GRID` / `RESOLUTION UNKNOWN` provenance states depend on that derivation.

    ★ 0.0 is deduce_grid_resolution's "could not tell", NOT a 0-degree grid. It must reach the wire
    as None — the same measure-or-refuse rule as WS-CAN-0010/0063: never emit a number nobody
    measured.
    """
    res = deduce_grid_resolution(grid)
    return res if res and res > 0 else None


class PointSampler:
    """
    Samples point forecasts from NormalizedProduct grid files
    using high-fidelity Bilinear Interpolation.
    """

    def sample_point(
        self,
        product: NormalizedProduct,
        lat: float,
        lng: float
    ) -> NormalizedPointResponse:
        """
        Samples a coordinate from a NormalizedProduct grid.
        Returns a NormalizedPointResponse.
        """
        lat = round(lat, 4)
        lng = round(lng, 4)
        warnings = []
        is_estimated = product.is_estimated
        estimate_basis = product.estimate_basis or {}

        # 1. Bounds verification
        grid = product.grid
        if not grid or not grid.vectors:
            return self._build_unavailable_response(product, lat, lng, "Empty or missing grid data")

        lats = sorted(list(set(v.lat for v in grid.vectors)))
        if not lats:
            return self._build_unavailable_response(product, lat, lng, "Invalid grid coordinates list")

        bounds = grid.bounds
        if not bounds:
            lons_fallback = sorted(list(set(v.lng for v in grid.vectors)))
            if not lons_fallback:
                return self._build_unavailable_response(product, lat, lng, "Invalid grid coordinates list")
            from services.weather_pipeline.schemas import CoverageBounds
            bounds = CoverageBounds(west=lons_fallback[0], south=lats[0], east=lons_fallback[-1], north=lats[-1])

        # Monotonic longitude mapping helpers for antimeridian crossing
        def to_monotonic_lng(x: float, west: float) -> float:
            val = x - west
            if val < 0:
                val += 360.0
            return west + val

        def from_monotonic_lng(mono_x: float) -> float:
            wrapped = mono_x % 360.0
            if wrapped > 180.0:
                wrapped -= 360.0
            return wrapped

        lons_mono = sorted(list(set(to_monotonic_lng(v.lng, bounds.west) for v in grid.vectors)))
        lng_mono = to_monotonic_lng(lng, bounds.west)

        min_lat, max_lat = bounds.south, bounds.north
        min_lon_mono, max_lon_mono = lons_mono[0], lons_mono[-1]

        in_lat = min_lat <= lat <= max_lat
        in_lng = min_lon_mono <= lng_mono <= max_lon_mono

        # Enforce strict coverage check as requested by User Condition 5
        if not in_lat or not in_lng:
            warnings.append("Requested point falls outside the authoritative grid boundaries")
            is_estimated = False
            estimate_basis["out_of_bounds"] = {
                "grid_min_lat": min_lat,
                "grid_max_lat": max_lat,
                "grid_min_lon": bounds.west,
                "grid_max_lon": bounds.east
            }
            estimate_basis["fallback_attempted"] = True
            # Return estimates as 0 when out of bounds
            detail = NormalizedPointDetail(
                requested_lat=lat,
                requested_lng=lng,
                sampled_lat=lat,
                sampled_lng=lng,
                speed=0.0,
                direction=0.0,
                u=0.0,
                v=0.0,
                period=0.0,
                gust=None,
                value=None,
                interpolation_method="out_of_bounds_fallback"
            )
            return NormalizedPointResponse(
                resolution=resolution_or_none(product.grid),
                model=product.model,
                provider=product.provider,
                domain=product.domain,
                layer=product.layer,
                run_time=product.run_time,
                **time_provenance(product),
                valid_time=product.valid_time,
                is_forecast_authoritative=False,
                is_estimated=is_estimated,
                estimate_basis=estimate_basis,
                point=detail,
                value_kind=product.value_kind,
                value_unit=product.value_unit,
                display_unit_hint=product.display_unit_hint,
                units=product.units,
                source_variables=product.source_variables,
                freshness_sec=product.freshness_sec,
                warnings=warnings,
                source_dataset=product.source_dataset,
                is_test_fixture=product.is_test_fixture,
                upstream_provider=product.upstream_provider,
                upstream_model=product.upstream_model
            )

        # 2. Build coordinate map for constant-time lookup
        coordinate_map = {(v.lat, v.lng): v for v in grid.vectors}

        def get_vector_safe(lat_val: float, lon_val: float):
            vec = coordinate_map.get((lat_val, lon_val))
            if vec is not None:
                return vec
            if abs(lon_val) == 180.0:
                return coordinate_map.get((lat_val, -lon_val))
            return None

        # 3. Locate bounding box coordinates
        lat0, lat1 = self._find_surrounding_brackets(lats, lat)
        lon0_mono, lon1_mono = self._find_surrounding_brackets(lons_mono, lng_mono)
        lon0 = from_monotonic_lng(lon0_mono)
        lon1 = from_monotonic_lng(lon1_mono)

        # Exact match path
        if lat0 == lat1 and lon0 == lon1:
            vec = get_vector_safe(lat0, lon0)
            if vec:
                detail = NormalizedPointDetail(
                    requested_lat=lat,
                    requested_lng=lng,
                    sampled_lat=lat0,
                    sampled_lng=lon0,
                    speed=vec.speed,
                    direction=vec.direction,
                    u=vec.u,
                    v=vec.v,
                    period=vec.period,
                    gust=getattr(vec, "gust", None),
                    value=getattr(vec, "value", None),
                    speed_spread=getattr(vec, "speed_spread", None),
                    interpolation_method="exact_match"
                )
                return self._build_success_response(product, is_estimated, estimate_basis, detail, warnings)

        # 4. Fetch 4 grid intersections
        v11 = get_vector_safe(lat0, lon0) # bottom-left
        v12 = get_vector_safe(lat0, lon1) # bottom-right
        v21 = get_vector_safe(lat1, lon0) # top-left
        v22 = get_vector_safe(lat1, lon1) # top-right

        # Solve fractions:
        t = (lng_mono - lon0_mono) / (lon1_mono - lon0_mono) if lon1_mono != lon0_mono else 0.0
        u = (lat - lat0) / (lat1 - lat0) if lat1 != lat0 else 0.0

        # Weights
        w11 = (1.0 - t) * (1.0 - u)
        w12 = t * (1.0 - u)
        w21 = (1.0 - t) * u
        w22 = t * u

        # Check if it's a scalar layer
        is_scalar = (product.domain.lower() == "weather" and product.layer.lower() in ("pressure", "precipitation"))
        if is_scalar:
            v11 = get_vector_safe(lat0, lon0)
            v12 = get_vector_safe(lat0, lon1)
            v21 = get_vector_safe(lat1, lon0)
            v22 = get_vector_safe(lat1, lon1)
            
            corners = [v for v in [v11, v12, v21, v22] if self._is_vector_valid(v, product.domain, product.layer)]
            if not corners:
                return self._build_unavailable_response(product, lat, lng, f"No valid {product.layer} data in grid")
                
            if len(corners) < 4:
                valid_scalar = [v for v in grid.vectors if self._is_vector_valid(v, product.domain, product.layer)]
                if valid_scalar:
                    nearest = self._find_nearest_vector(valid_scalar, lat, lng)
                    detail = NormalizedPointDetail(
                        requested_lat=lat,
                        requested_lng=lng,
                        sampled_lat=nearest.lat,
                        sampled_lng=nearest.lng,
                        speed=0.0,
                        direction=0.0,
                        u=0.0,
                        v=0.0,
                        value=nearest.value,
                        interpolation_method="nearest_scalar_fallback"
                    )
                    return self._build_success_response(product, is_estimated, estimate_basis, detail, warnings)
                else:
                    return self._build_unavailable_response(product, lat, lng, f"No valid {product.layer} data in grid")
                
            val11 = v11.value
            val12 = v12.value
            val21 = v21.value
            val22 = v22.value
            
            interp_val = w11 * val11 + w12 * val12 + w21 * val21 + w22 * val22
            
            detail = NormalizedPointDetail(
                requested_lat=lat,
                requested_lng=lng,
                sampled_lat=round(lat, 4),
                sampled_lng=round(lng, 4),
                speed=0.0,
                direction=0.0,
                u=0.0,
                v=0.0,
                value=round(interp_val, 4),
                interpolation_method="bilinear_scalar"
            )
            return self._build_success_response(product, is_estimated, estimate_basis, detail, warnings)

        corner_weights = [
            (v11, w11),
            (v12, w12),
            (v21, w21),
            (v22, w22)
        ]

        valid_ocean_corners = [
            (v, w) for v, w in corner_weights
            if self._is_vector_valid(v, product.domain, product.layer)
        ]

        if len(valid_ocean_corners) == 4:
            # 1. Standard Bilinear Interpolation
            interp_u = w11 * v11.u + w12 * v12.u + w21 * v21.u + w22 * v22.u
            interp_v = w11 * v11.v + w12 * v12.v + w21 * v21.v + w22 * v22.v
            
            interp_period = 0.0
            p_sum_weights = 0.0
            for v, w in corner_weights:
                if v is not None and v.period is not None:
                    interp_period += w * v.period
                    p_sum_weights += w
            if p_sum_weights > 0.0:
                interp_period = interp_period / p_sum_weights

            interp_gust = 0.0
            g_sum_weights = 0.0
            for v, w in corner_weights:
                vg = getattr(v, "gust", None)
                if v is not None and vg is not None:
                    interp_gust += w * vg
                    g_sum_weights += w
            if g_sum_weights > 0.0:
                interp_gust = interp_gust / g_sum_weights
            else:
                interp_gust = None
            
            interp_speed = math.sqrt(interp_u**2 + interp_v**2)
            interp_dir = math.atan2(-interp_u, -interp_v) * (180.0 / math.pi)
            if interp_dir < 0.0:
                interp_dir += 360.0

            detail = NormalizedPointDetail(
                requested_lat=lat,
                requested_lng=lng,
                sampled_lat=round(lat, 4),
                sampled_lng=round(lng, 4),
                speed=round(interp_speed, 4),
                direction=round(interp_dir, 2),
                u=round(interp_u, 4),
                v=round(interp_v, 4),
                period=round(interp_period, 2),
                gust=round(interp_gust, 4) if interp_gust is not None else None,
                interpolation_method="bilinear"
            )
            return self._build_success_response(product, is_estimated, estimate_basis, detail, warnings)

        elif len(valid_ocean_corners) >= 2:
            # 2. Bilinear Ocean Masked (Normalized Bilinear over valid ocean corners)
            sum_w = sum(w for v, w in valid_ocean_corners)
            if sum_w > 0.0:
                interp_u = 0.0
                interp_v = 0.0
                interp_period = 0.0
                p_sum_w = 0.0
                
                interp_gust = 0.0
                g_sum_w = 0.0
                
                for v, w in valid_ocean_corners:
                    norm_w = w / sum_w
                    interp_u += norm_w * v.u
                    interp_v += norm_w * v.v
                    if v.period is not None:
                        interp_period += norm_w * v.period
                        p_sum_w += norm_w
                    vg = getattr(v, "gust", None)
                    if vg is not None:
                        interp_gust += norm_w * vg
                        g_sum_w += norm_w
                
                if p_sum_w > 0.0:
                    interp_period = interp_period / p_sum_w
                if g_sum_w > 0.0:
                    interp_gust = interp_gust / g_sum_w
                else:
                    interp_gust = None
                
                interp_speed = math.sqrt(interp_u**2 + interp_v**2)
                interp_dir = math.atan2(-interp_u, -interp_v) * (180.0 / math.pi)
                if interp_dir < 0.0:
                    interp_dir += 360.0

                detail = NormalizedPointDetail(
                    requested_lat=lat,
                    requested_lng=lng,
                    sampled_lat=round(lat, 4),
                    sampled_lng=round(lng, 4),
                    speed=round(interp_speed, 4),
                    direction=round(interp_dir, 2),
                    u=round(interp_u, 4),
                    v=round(interp_v, 4),
                    period=round(interp_period, 2),
                    gust=round(interp_gust, 4) if interp_gust is not None else None,
                    interpolation_method="bilinear_ocean_masked"
                )
                return self._build_success_response(product, is_estimated, estimate_basis, detail, warnings)
            else:
                # Fallback to nearest ocean vector if sum of weights is zero
                valid_vectors = [v for v in grid.vectors if self._is_vector_valid(v, product.domain, product.layer)]
                if valid_vectors:
                    nearest = self._find_nearest_vector(valid_vectors, lat, lng)
                    detail = NormalizedPointDetail(
                        requested_lat=lat,
                        requested_lng=lng,
                        sampled_lat=nearest.lat,
                        sampled_lng=nearest.lng,
                        speed=nearest.speed,
                        direction=nearest.direction,
                        u=nearest.u,
                        v=nearest.v,
                        period=nearest.period,
                        gust=getattr(nearest, "gust", None),
                        # ⭐ SINGLE-VECTOR READ ⇒ CARRIES THE SPREAD. `schemas.py:145` states the
                        # contract as "exact match / NEAREST", and this branch reads exactly one
                        # `nearest` vector — the same situation as `exact_match`, so the spread it
                        # publishes is a measured per-cell sd, not an invented one.
                        # ⛔ The BILINEAR paths still leave it None on purpose: averaging standard
                        # deviations across neighbouring cells is a different quantity.
                        # ⚠️ Until MASTER-AUDIT-10.0 §1.2 this was the implementation half of a
                        # contract that only the docstring kept: `exact_match` is reachable ONLY at a
                        # product grid's four CORNERS (`_find_surrounding_brackets` collapses only at
                        # an axis endpoint), so the spread reached 0 of 1,103 served spots.
                        speed_spread=getattr(nearest, "speed_spread", None),
                        interpolation_method="nearest_ocean_fallback"
                    )
                    warnings.append("Bilinear corners contain land/masked cells and sum of ocean weights is zero; fallback to nearest ocean neighbor.")
                    return self._build_success_response(product, is_estimated, estimate_basis, detail, warnings)
                else:
                    return self._build_unavailable_response(product, lat, lng, "No valid ocean corners exist and no valid ocean data in grid")

        elif len(valid_ocean_corners) == 1:
            # 3. Fallback to Nearest Ocean Vector (exactly 1 valid ocean corner exists)
            valid_vectors = [v for v in grid.vectors if self._is_vector_valid(v, product.domain, product.layer)]
            if valid_vectors:
                nearest = self._find_nearest_vector(valid_vectors, lat, lng)
                detail = NormalizedPointDetail(
                    requested_lat=lat,
                    requested_lng=lng,
                    sampled_lat=nearest.lat,
                    sampled_lng=nearest.lng,
                    speed=nearest.speed,
                    direction=nearest.direction,
                    u=nearest.u,
                    v=nearest.v,
                    period=nearest.period,
                    gust=getattr(nearest, "gust", None),
                    # Single-vector read — see the note on the sibling `nearest_ocean_fallback` above.
                    speed_spread=getattr(nearest, "speed_spread", None),
                    interpolation_method="nearest_ocean_fallback"
                )
                warnings.append("Bilinear corners contain land/masked cells; fallback to nearest ocean neighbor.")
                return self._build_success_response(product, is_estimated, estimate_basis, detail, warnings)
            else:
                return self._build_unavailable_response(product, lat, lng, "No valid ocean corners exist and no valid ocean data in grid")
        else:
            # 0 valid ocean corners in the bracketing cell. At COARSE resolution this is often an
            # OPEN-OCEAN point whose nearest coarse cells are all land-masked (e.g. the central Gulf of
            # Mexico: corners (20/30, -90/-100) snap to inland TX/LA/MX) — NOT a genuinely-inland point.
            # The heatmap interpolates from farther valid ocean cells, so the infobox showed a misleading
            # "0 ft / 0 dir" where the map shows waves. Fall back to the nearest valid ocean vector IF it's
            # within ~1.5 grid cells; deep-inland points (nearest ocean farther) stay unavailable.
            valid_vectors = [v for v in grid.vectors if self._is_vector_valid(v, product.domain, product.layer)]
            if valid_vectors:
                nearest = self._find_nearest_vector(valid_vectors, lat, lng)
                pos_diffs = [lats[i + 1] - lats[i] for i in range(len(lats) - 1)]
                grid_res = min(pos_diffs) if pos_diffs else 10.0
                max_dist = max(grid_res * 1.5, 1.0)
                d = math.hypot(nearest.lat - lat, nearest.lng - lng)
                if d <= max_dist:
                    detail = NormalizedPointDetail(
                        requested_lat=lat,
                        requested_lng=lng,
                        sampled_lat=nearest.lat,
                        sampled_lng=nearest.lng,
                        speed=nearest.speed,
                        direction=nearest.direction,
                        u=nearest.u,
                        v=nearest.v,
                        period=nearest.period,
                        gust=getattr(nearest, "gust", None),
                        # Single-vector read — see the note on `nearest_ocean_fallback` above.
                        speed_spread=getattr(nearest, "speed_spread", None),
                        interpolation_method="nearest_ocean_coarse_masked"
                    )
                    warnings.append(
                        f"All bracketing corners land/masked at coarse resolution; nearest ocean vector "
                        f"{d:.1f}deg away (<= {max_dist:.1f}deg) — matches heatmap interpolation."
                    )
                    return self._build_success_response(product, is_estimated, estimate_basis, detail, warnings)
            # Genuinely inland (no valid ocean within range): no data.
            return self._build_unavailable_response(product, lat, lng, "No valid ocean corners exist in grid bounding box")

    def _is_vector_valid(self, v: Any, domain: str, layer: str) -> bool:
        if v is None:
            return False
            
        domain_lower = domain.lower()
        layer_lower = layer.lower()
        
        has_explicit_is_valid = hasattr(v, "model_fields_set") and "is_valid" in v.model_fields_set
        if has_explicit_is_valid:
            return getattr(v, "is_valid", True)
            
        # Legacy fallback heuristics
        if domain_lower == "weather" and layer_lower in ("pressure", "precipitation"):
            return getattr(v, "value", None) is not None
        elif domain_lower == "marine":
            if getattr(v, "period", 0.0) == 0.0 and getattr(v, "speed", 0.0) == 0.0:
                return False
            return True
        elif domain_lower == "wind":
            return True
            
        return getattr(v, "is_valid", True)

    @staticmethod
    def _find_surrounding_brackets(coords: List[float], val: float) -> Tuple[float, float]:
        """Finds the bounding bracket values around val."""
        if val <= coords[0]:
            return coords[0], coords[0]
        if val >= coords[-1]:
            return coords[-1], coords[-1]
            
        for i in range(len(coords) - 1):
            if coords[i] <= val <= coords[i+1]:
                return coords[i], coords[i+1]
        return coords[0], coords[-1]

    @staticmethod
    def _find_nearest_vector(vectors: List[Any], lat: float, lng: float) -> Any:
        """Finds the single nearest vector by geometric distance, supporting antimeridian crossing."""
        best_vec = vectors[0]
        min_dist = float("inf")
        for v in vectors:
            d_lng = abs(v.lng - lng)
            if d_lng > 180.0:
                d_lng = 360.0 - d_lng
            dist = (v.lat - lat)**2 + d_lng**2
            if dist < min_dist:
                min_dist = dist
                best_vec = v
        return best_vec
    def _build_unavailable_response(
        self,
        product: NormalizedProduct,
        lat: float,
        lng: float,
        reason: str
    ) -> NormalizedPointResponse:
        detail = NormalizedPointDetail(
            requested_lat=lat,
            requested_lng=lng,
            sampled_lat=lat,
            sampled_lng=lng,
            speed=0.0,
            direction=0.0,
            u=0.0,
            v=0.0,
            period=0.0,
            gust=None,
            interpolation_method="unavailable"
        )
        return NormalizedPointResponse(
            resolution=resolution_or_none(product.grid),
            model=product.model,
            provider=product.provider,
            domain=product.domain,
            layer=product.layer,
            run_time=product.run_time,
            **time_provenance(product),
            valid_time=product.valid_time,
            is_forecast_authoritative=False,
            is_estimated=False,
            estimate_basis={"unavailable_reason": reason},
            point=detail,
            value_kind=product.value_kind,
            value_unit=product.value_unit,
            display_unit_hint=product.display_unit_hint,
            product_id=product.product_id,
            units=product.units,
            source_variables=product.source_variables,
            freshness_sec=product.freshness_sec,
            warnings=[f"Point unavailable: {reason}"],
            source_dataset=product.source_dataset,
            is_test_fixture=product.is_test_fixture,
            upstream_provider=product.upstream_provider,
            upstream_model=product.upstream_model
        )

    def _build_success_response(
        self,
        product: NormalizedProduct,
        is_estimated: bool,
        estimate_basis: Dict[str, Any],
        detail: NormalizedPointDetail,
        warnings: List[str]
    ) -> NormalizedPointResponse:
        return NormalizedPointResponse(
            resolution=resolution_or_none(product.grid),
            model=product.model,
            provider=product.provider,
            domain=product.domain,
            layer=product.layer,
            run_time=product.run_time,
            **time_provenance(product),
            valid_time=product.valid_time,
            is_forecast_authoritative=not is_estimated,
            is_estimated=is_estimated,
            estimate_basis=estimate_basis if is_estimated else None,
            point=detail,
            value_kind=product.value_kind,
            value_unit=product.value_unit,
            display_unit_hint=product.display_unit_hint,
            product_id=product.product_id,
            units=product.units,
            source_variables=product.source_variables,
            freshness_sec=product.freshness_sec,
            warnings=warnings,
            source_dataset=product.source_dataset,
            is_test_fixture=product.is_test_fixture,
            upstream_provider=product.upstream_provider,
            upstream_model=product.upstream_model
        )
