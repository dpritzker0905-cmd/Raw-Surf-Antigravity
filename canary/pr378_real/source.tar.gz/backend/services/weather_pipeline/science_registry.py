"""THE SCIENCE REGISTRY — every physical constant in the forecast chain, with its PROVENANCE
and its PUBLISHED VALIDITY RANGE, in one machine-readable place.

WHY THIS EXISTS (2026-08-05)
---------------------------
`GAMMA_MAX_STEEP = 1.25` sat in `surf_transform.py` for weeks with a docstring citing Weggel (1972)
and Kaminsky (1994). Both citations are real. The value is still **54% above the highest breaker
index ever measured in the field** (Carini et al. 2021: plunging 0.73-0.81 over 1,600+ waves at the
Duck FRF). Nobody caught it, because the provenance lived in PROSE and prose is not checkable: a
docstring can name a source without the value being inside what that source observed.

    ***  A CITATION IS NOT A RANGE CHECK.  ***

So: constants declare their published range HERE, and `test_science_registry.py` asserts that (a) the
live value in the module still equals the registry, and (b) it sits inside the published range --
with an explicit, reasoned grandfather list so existing debt is DOCUMENTED rather than silently
tolerated, and any NEW out-of-range constant fails the build.

HOW TO USE IT
-------------
* Reading a constant for science:  `science_registry.value("GAMMA_MAX_STEEP")`
* Explaining a number to a user / the sim:  `science_registry.provenance("GAMMA_MAX_STEEP")`
* Adding a constant: add a `Constant(...)` below. The guard FAILS if a module defines a science
  constant that is not registered -- that is deliberate.
  ⚠️⚠️ THAT SENTENCE WAS PROSE UNTIL 2026-08-08, AND PROSE IS THE THING THIS FILE EXISTS TO REPLACE.
  No scan existed: `test_science_registry.py` walks the registry OUTWARD to its modules, and nothing
  walked a module INWARD. Proven by planting two unregistered constants here -- one of them
  `9.99` -- and watching the suite stay green at 9 passed. It is now implemented by
  `tests/test_science_registry_coverage.py` as a shrink-only ratchet over the declared forecast
  chain, frozen at the measured debt: **42 unregistered against 11 registered**, 32 of them real
  unsourced calibration. Register new constants here; grandfather them there only with a reason. Register it, with a real source.

CONVENTIONS
-----------
* `method` is how the number was OBSERVED, and it is load-bearing: FIELD beats LAB beats MODEL.
  A laboratory plane-slope regular-wave value does not automatically apply to a field significant
  wave height -- see GAMMA_MAX_STEEP's own note.
* `published_range` is what the SOURCE observed or validated, NOT what we would like to be true.
  If a source gives no range, say so with `published_range=None` and set `status=UNVALIDATED`.
* ASCII only. This file is imported by the MCP weather sim, which prints to a cp1252 stdout.
"""

from typing import Dict, NamedTuple, Optional, Tuple

# --- status vocabulary -------------------------------------------------------------------------
IN_RANGE = "in_range"            # live value sits inside the published range
OUT_OF_RANGE = "out_of_range"    # live value is outside it -- MUST carry a `debt_reason`
UNVALIDATED = "unvalidated"      # no published range exists for this quantity
DERIVED = "derived"              # our own calibration, not a published constant


class Constant(NamedTuple):
    name: str
    value: float
    units: str
    what: str                       # one line a non-specialist can read
    module: str                     # dotted path of the module that defines the live value
    source: str                     # author, year, venue
    method: str                     # "field" | "laboratory" | "reanalysis" | "model" | "owner"
    sample: str                     # n, and what the n counts
    published_range: Optional[Tuple[float, float]]
    status: str
    debt_reason: str = ""           # required when status == OUT_OF_RANGE
    applies_to: str = ""            # the wave-height convention / regime the source measured


_REGISTRY: Dict[str, Constant] = {}


def _add(c: Constant) -> None:
    if c.status == OUT_OF_RANGE and not c.debt_reason:
        raise ValueError("%s is OUT_OF_RANGE and must carry a debt_reason" % c.name)
    _REGISTRY[c.name] = c


_add(Constant(
    name="MARINE_REGIONAL_MIN_COVERAGE_FRACTION",
    value=0.70,
    units="fraction of requested longitude-latitude rectangle",
    what="Minimum regional coverage accepted before the covering coarse fallback.",
    module="services.weather_pipeline.grid_resolver_selection",
    source="OURS. Audit 14 WP-2 explicitly permits clamped regional coverage at >=70%.",
    method="owner",
    sample="Selection policy, not an empirically calibrated physical constant. "
           "Sebastian edge sensitivity and threshold controls in test_regional_edge_selection.py.",
    published_range=None,
    status=DERIVED,
    applies_to="Marine manifest selection only; actual served bounds still determine partial_coverage. "
               "Does not increase upstream resolution or manufacture cells outside the tile.",
))


# --- depth-limited breaking --------------------------------------------------------------------

_add(Constant(
    name="W_WIND",
    value=0.60,
    units="dimensionless (weight in the wind/period quality blend, W_WIND + W_PERIOD == 1)",
    what="How much of the non-size half of the score is carried by wind cleanliness.",
    module="services.weather_pipeline.surf_rating",
    source="OURS. Lineage: Espejo, Losada & Mendez (2014), Global Planet. Change 121 19-25, "
           "a multivariable standardized surf index; the split itself is not from that paper",
    method="owner",
    sample="Set in the rating model's first commit 1ba30f57 (2026-06-28) and never changed since. "
           "Jacobian measured 2026-08-08 over 3,000 conditions (h 0.3-9 m, Tp 4-18 s, wind 1-20 m/s "
           "x 3 directions, 4 live references): the constrained rotation W_WIND 0.60+d / "
           "W_PERIOD 0.40-d moves 87.7% of cases, median 0.8 and max 5.6 points, 8% of them across "
           "a level boundary. The highest-reach unsourced constant in the rating chain.",
    published_range=None,
    status=DERIVED,
    debt_reason="",
    applies_to=(
        "A CONSTRAINED PAIR, NOT TWO KNOBS. Perturbing one member alone changes the SUM, so it "
        "measures the normalisation rather than the weighting -- measured, scaling BOTH by 1.1 "
        "(ratio unchanged) moves 96.3% of cases at median 1.9 points, more than either rotation. "
        "test_rating_blend_weights_are_a_normalised_pair pins the sum. THE CITATION NAMES A "
        "LINEAGE, NOT THE NUMBER: Espejo et al. propose an expert-judgment index over a different "
        "variable set (it also carries tides and SST), and no source consulted 2026-08-08 states a "
        "0.60/0.40 wind-vs-period split. Hence DERIVED with no published range, rather than a "
        "borrowed one."),
))

_add(Constant(
    name="W_PERIOD",
    value=0.40,
    units="dimensionless (weight in the wind/period quality blend, W_WIND + W_PERIOD == 1)",
    what="How much of the non-size half of the score is carried by swell period.",
    module="services.weather_pipeline.surf_rating",
    source="OURS. Lineage: Espejo, Losada & Mendez (2014), Global Planet. Change 121 19-25, "
           "a multivariable standardized surf index; the split itself is not from that paper",
    method="owner",
    sample="The complement of W_WIND, same origin commit 1ba30f57 (2026-06-28), never changed. "
           "See W_WIND for the measured Jacobian of the pair.",
    published_range=None,
    status=DERIVED,
    debt_reason="",
    applies_to="See W_WIND: the two are one degree of freedom, and the sum is pinned by a test.",
))

_add(Constant(
    name="SHELF_KF_FLOOR",
    value=0.316,
    units="dimensionless (fraction of offshore swell HEIGHT retained across the shelf)",
    what="Floor on cross-shelf bottom-friction transmission: never model more dissipation than the "
         "cited field observations support.",
    module="services.weather_pipeline.surf_transform",
    source="Ardhuin, O'Reilly, Herbers & Jessen (2003), J. Phys. Oceanogr. 33(9) 1921-1939, "
           "Swell Transformation across the Continental Shelf. Part I",
    method="field",
    sample="North Carolina - Virginia continental shelf, autumn 1999. Maximum reduction in wave "
           "ENERGY of 93% near the Virginia coastline where the shelf is widest, for ONE event, in "
           "light winds with onshore propagation and little directional spread.",
    # Height goes as sqrt(energy), so the source's observed attenuation spans a retention of
    # sqrt(1-0.93) = 0.265 at its maximum-loss event up to ~1.0 where swell crossed with little
    # loss. 0.316 sits inside that. A future value below 0.265 would claim more dissipation than
    # the source ever observed, and this range is what makes that checkable rather than arguable.
    published_range=(0.265, 1.0),
    status=IN_RANGE,
    debt_reason="",
    applies_to=(
        "ONE SHELF, ONE SEASON, and the shipped value does NOT equal its own derivation. The live "
        "0.316 is sqrt(1-0.90); the source reports 93%, which gives sqrt(1-0.93) = 0.265. The 90% "
        "figure appears in no primary record -- this repo's earliest note (2026-06-28) quoted 93% "
        "correctly and the 2026-07-29 comment that derived the constant used 90%. So the floor is "
        "19.5% MORE conservative than the citation requires: where it binds it retains more height, "
        "never less. Measured 2026-08-08 at Tp 16 s over the 1,386-entry shore-normal asset, the "
        "floor binds on 38 spots (2.74%); moving it to the source-consistent 0.265 would lower 30 "
        "of them by 16.3% and release 8 to their unfloored value. That is a calibration change and "
        "an OWNER decision, not a silent correction. NOTE ALSO that 93% is a single-event maximum "
        "on one shelf, not a validated global envelope -- treating it as one would repeat the "
        "GAMMA_MAX_STEEP error in the opposite direction."),
))

_add(Constant(
    name="SHELF_CF_SCALE_DEFAULT",
    value=0.0,
    units="dimensionless (scale on SHELF_FRICTION_CF; 0 = the chain adds no cross-shelf friction)",
    what="How much cross-shelf bottom friction the chain applies ON TOP of the model field at the spot.",
    module="services.weather_pipeline.surf_transform",
    source="OURS. Nearshore judge shelf arm (scripts/run_nearshore_validation.py, no_friction_ab) against "
           "CDIP nearshore buoys on wide shelves; runs of 2026-09-28 (PR #136's first run, CI 36375348896, "
           "CI 36432875668). Shadow A/B of the served frames: run 36462075711",
    method="field",
    sample="48 wide-shelf station-hours (Duck, Wrightsville, Cape Canaveral, Fort Pierce and neighbours): "
           "friction off closer on 78% / 82.5% / 75% of hours, MAE -38% / -40% / -34%; the chain stays low "
           "with it off (bias -0.10 / -0.06 m), so no scale in (0, 0.25] fits better than 0.",
    published_range=None,
    status=DERIVED,
    debt_reason="",
    applies_to=(
        "The served field at a wide-shelf spot is already shelf water: GFS-Wave (WAVEWATCH III) applies "
        "bottom friction in its own source terms, and /point at the spot read 0.44 (Duck) to 0.66 (Cape "
        "Canaveral) of /point at the shelf edge. Friction across the whole shelf width from the edge therefore "
        "counted the shelf twice. The previous 0.25 (2026-07-17) was fitted to forecaster reports, not "
        "instruments. Narrow and deep shelves are unaffected (friction ~1.0 there). SHELF_KF_FLOOR only binds "
        "while this is > 0. SURF_SHELF_CF_SCALE=0.25 restores the legacy chain."),
))

_add(Constant(
    name="GAMMA",
    value=0.78,
    units="dimensionless (H_b / h_b)",
    what="Reference depth-limited breaker index used when the period is unknown.",
    module="services.weather_pipeline.surf_transform",
    source="McCowan (1894) solitary-wave limit; ubiquitous in coastal engineering",
    method="theory",
    sample="analytic",
    published_range=(0.73, 0.83),
    status=IN_RANGE,
    applies_to="regular / solitary waves",
))

_add(Constant(
    name="GAMMA_MIN",
    value=0.63,
    units="dimensionless",
    what="Floor of the period-dependent breaker index: short-period windchop breaks low and mushy.",
    module="services.weather_pipeline.surf_transform",
    source="Carini et al. (2021), J. Geophys. Res. -- spilling breakers",
    method="field",
    sample="413 spilling waves of 1,600+ observed, Duck FRF (LIDAR + infrared)",
    published_range=(0.63, 0.71),
    status=IN_RANGE,
    debt_reason="",
    applies_to="individual waves at onset of breaking",
))

_add(Constant(
    name="GAMMA_MAX",
    value=0.81,
    units="dimensionless",
    what="Ceiling of the period-dependent breaker index when NO bottom slope is supplied.",
    module="services.weather_pipeline.surf_transform",
    source="Carini et al. (2021) plunging 0.73-0.81; Goda (2010) reanalysis",
    method="field",
    sample="111 plunging waves at Duck FRF; Goda: multi-source field + laboratory reanalysis",
    published_range=(0.73, 0.81),
    status=IN_RANGE,
    debt_reason="",
    applies_to="individual waves at onset of breaking",
))

_add(Constant(
    name="GAMMA_MAX_STEEP",
    value=0.81,
    units="dimensionless",
    what="Ceiling of the breaker index when a bottom slope IS supplied (steep-reef plunging).",
    module="services.weather_pipeline.surf_transform",
    source="Carini et al. (2021) JGR; Goda (2010) Coastal Eng. J.; Chin (2022) Water Sci. Eng.",
    method="field",
    sample="Carini: 1,600+ waves, Duck FRF. Chin: basin experiments, oblique incidence 15-30 deg.",
    published_range=(0.73, 0.81),
    status=IN_RANGE,
    debt_reason="",
    applies_to="Hs (significant height) -- but the sources measured individual/regular waves",
))

_add(Constant(
    name="WEGGEL_SLOPE_VALIDITY_HI",
    value=0.07,
    units="dimensionless (bed slope m = tan beta)",
    what="Upper bed slope at which Weggel-class breaker-index formulas are still validated.",
    module="services.weather_pipeline.surf_transform",
    source="Camenen & Larson (2007), Predictive Formulas for Breaker Depth Index and Breaker Type",
    method="laboratory",
    sample="524 cases collected from 22 published sources",
    published_range=(0.01, 0.07),
    status=IN_RANGE,
    debt_reason="",
    applies_to=(
        "PLANE BEACH slopes. Camenen & Larson: predictions are 'typically not satisfactory' above "
        "m > 0.1. Our live _slope_proxy = depth_m/(shelf_width_km*1000) is a SHELF-scale quantity, "
        "not a beach slope; bathymetry.bed_slope_at is the nearshore partner. Measured 2026-08-05: "
        "Teahupoo 0.156 and Uluwatu 0.129 exceed 0.1 even with the real asset -- 2 of 10 anchors "
        "are outside the formula's evidence base whichever slope is fed."),
))

_add(Constant(
    name="BATTJES_STIVE_GAMMA_MAX",
    value=0.90,
    units="dimensionless (H_max / d)",
    what="Upper bound of the SATURATION breaker index for a RANDOM (significant) wave field.",
    module="services.weather_pipeline.surf_transform",   # the quantity our cap actually is
    source="Battjes & Stive (1985), J. Geophys. Res.; Battjes & Janssen (1978) ICCE",
    method="laboratory + field",
    sample="B&S 1985: extensive lab + field, plane and barred beaches; r=0.98, rms 6%, zero bias",
    published_range=(0.50, 0.90),
    status=UNVALIDATED,          # documented for comparison; not yet the live law
    debt_reason="",
    applies_to=(
        "*** THIS IS THE GAMMA OUR CAP ACTUALLY IS, AND IT IS NOT THE ONE WE USE. *** "
        "`estimate_surf` caps a SIGNIFICANT-scale height with H <= gamma*d -- that is the "
        "Battjes-Janssen saturation form, whose calibrated law is "
        "gamma = 0.5 + 0.4*tanh(33*s0), range 0.50-0.90. The individual-wave incipient index "
        "(Weggel/Goda/Carini, 0.73-0.81) answers a DIFFERENT question: how tall ONE wave stands at "
        "the breakpoint. "
        "MEASURED 2026-08-05 at fixed Hs=2 m, sweeping Tp 5->22 s: our breaker_index RISES "
        "(0.632 -> 1.050) while Battjes-Stive FALLS (0.874 -> 0.535). OPPOSITE SIGN across the "
        "whole range; at Tp=18 s ours is 1.78x theirs. "
        "PHYSICAL BOUND CHECK -- displayed height as a multiple of breaking depth d: "
        "live (gamma 1.25, H110 off) = 1.25d = 1.54x the 0.81d ceiling on ANY individual wave; "
        "live + H110 on = 1.59d = 1.96x. Self-consistent alternative: Battjes-Stive swell gamma "
        "~0.55 WITH H110 on = 0.70d, which sits correctly just under 0.81d. "
        "NOTE the product tension: 'long-period swell breaks taller' is TRUE of an individual wave "
        "and FALSE of the saturation coefficient. It belongs in the H(1/10) conversion and in "
        "shoaling -- NOT in an inflated gamma. OWNER DECISION."),
))

_add(Constant(
    name="REFRACTION_KR",
    value=0.873,
    units="dimensionless (Kr, nearshore refraction coefficient)",
    what="Energy lost to refraction between offshore and the break. The transform assumed 1.0.",
    module="services.weather_pipeline.surf_transform",
    source="validate_nearshore_transform.py --composed, against the CDIP instrument archive",
    method="field",
    sample="394,331 QC-good swell hours across 10 independent California CDIP sites (2026-09-27)",
    published_range=(0.75, 1.30),
    status=IN_RANGE,
    debt_reason="",
    applies_to=(
        "RE-MEASURED 2026-09-27 AGAINST THE CHAIN IT MULTIPLIES: 0.797 was observed(near/deep) / Ks "
        "ONLY, so it absorbed shelf friction and directional blocking that the chain ALSO applies "
        "(shelf_dissipation, _height_exposure_factor) -- counted twice. Divided by the chain's own "
        "friction x shoaling x exposure on the same pairs and hours: median 0.873 (per site "
        "0.640-1.173); the Ks-only side reproduces 0.797 exactly. History of the 0.797 below. "
        "*** THE PARTNER OF SURF_HEIGHT_H110. NEITHER MAY SHIP ALONE. *** Assuming Kr = 1.0 "
        "over-predicted nearshore height by 1/0.797 = +25.5%; emitting Hs where the published surf "
        "standard is H1/10 (x1.27) left us -21.3% low. Net (1/0.797)/1.27 = 0.988 -- right by "
        "ACCIDENT within 1.2%. Both shipped together 2026-08-05; measured median displayed-height "
        "change +1.2% across 56 spot/sea cases, with -17.8% at p10 where the depth cap binds. "
        "0.797 is the MEDIAN: Kr is directional and swings to 1.75x at a single site (one CDIP site "
        "focuses 1.30 from 150 deg and blocks 0.75 from 270 deg), which is why the published_range "
        "spans 0.75-1.30. A per-spot refraction model needs the shore normal plus the finer "
        "bathymetry asset -- both of which now exist, so the 'deferred to v3' note is itself stale. "
        "Applied to the TRANSFORMED height, never the offshore input: Komar is non-linear in Hs "
        "(Hb ~ Hs^0.8), so scaling the input yields 0.834 and +5.9% instead of +1.2%."),
))

# --- wave height conventions -------------------------------------------------------------------

_add(Constant(
    name="H110_OVER_HS",
    value=1.27,
    units="dimensionless",
    what="Ratio H(1/10) / H(1/3). SURF_HEIGHT_H110 -- DEFAULT ON since 2026-08-05, paired with REFRACTION_KR.",
    module="services.weather_pipeline.surf_height_convention",
    source="Rayleigh distribution of wave heights; Goda (2010) surf-zone reanalysis",
    method="theory + field",
    sample="Goda: multi-source; ratio departs from Rayleigh inside the surf zone",
    published_range=(1.25, 1.30),
    status=IN_RANGE,
    applies_to=(
        "DEEP water Rayleigh statistics. Goda: H1/10, H1/3 and Hrms relative to Hm0 all INCREASE "
        "with nonlinearity toward the outer surf zone, so 1.27 is a deep-water figure applied "
        "nearshore. MEASURED 2026-08-05: flipping SURF_HEIGHT_H110 alone moves the served height "
        "+27.0% on 7 of 8 anchor cases (memory recorded +25.5%; replicates)."),
))

# --- directional exposure ----------------------------------------------------------------------

_add(Constant(
    name="SWELL_SPREAD_EXPONENT_S",
    value=10.0,
    units="dimensionless (s in cos^2s(phi/2))",
    what="Directional spreading exponent for a wind-sea/swell spectrum.",
    module="scripts.directional_exposure_science",   # NOT WIRED -- research script only
    source="Longuet-Higgins et al. (1963) cos-2s model; Mitsuyasu et al. (1975)",
    method="field",
    sample="pitch-and-roll buoy observations",
    published_range=(5.0, 25.0),
    status=UNVALIDATED,
    debt_reason="",
    applies_to=(
        "*** NOT IMPLEMENTED IN THE SERVED CHAIN. *** Verified 2026-08-05: cos-2s appears ONLY in "
        "scripts/directional_exposure_science.py. The live chain uses surf_rating.swell_exposure "
        "and surf_transform._height_exposure_factor, neither of which is spectral. Registered here "
        "so the gap is VISIBLE rather than assumed-done. The science: a real sea is a SPECTRUM, so "
        "flux at delta-theta = 100 deg is ~0.013 of head-on versus our flat 0.100 quality floor -- "
        "the floor is GENEROUS and 37-deg-past spots are correctly floored."),
))

# --- breaker type (Iribarren / surf similarity) -------------------------------------------------

_add(Constant(
    name="IRIBARREN_SPILLING_PLUNGING",
    value=0.5,
    units="dimensionless (xi_0 = tan(beta) / sqrt(H0/L0))",
    what="Surf-similarity boundary between spilling and plunging breakers.",
    module="services.weather_pipeline.surf_transform",   # breaker_type(); gated RATING_BREAKER_TYPE
    source="Okazaki & Sunamura (1991), J. Coastal Research",
    method="laboratory",
    sample="150 wave-flume runs, slopes 1/20 to 1/0.5",
    published_range=(0.4, 0.6),
    status=IN_RANGE,
    applies_to=(
        "Uniformly inclined laboratory beaches, regular waves. Companion boundaries from the same "
        "study: plunging/collapsing xi_0 = 2.5, collapsing/surging xi_0 = 3.7. "
        "*** CONTESTED -- READ BEFORE ENABLING RATING_BREAKER_TYPE. *** Two independent studies "
        "find xi_0 is NOT a sufficient classifier: Moragues et al. (2020, JMSE, 1:10 slope) -- 'the "
        "Iribarren number was not sufficient to predict the expected type of wave breaker... except "
        "for spilling and early plunging, no biunivocal relationship'; Diaz-Carrasco et al. (2020, "
        "Coastal Eng.) -- 'there is not a biunivocal relationship between Ir and the type of "
        "breaker... not a sufficient similarity parameter'. So the breaker-type QUALITY factor is "
        "trustworthy only at the spilling/early-plunging end, which is the mushy end -- the "
        "opposite of the reef spots it was built for."),
))

_add(Constant(
    name="IRIBARREN_PLUNGING_SURGING",
    value=3.3,
    units="dimensionless (xi_0)",
    what="Surf-similarity boundary above which breaking is surging/collapsing (often a closeout).",
    module="services.weather_pipeline.surf_transform",   # breaker_type()
    source="Battjes (1974) classical boundary; Okazaki & Sunamura (1991) split it in two",
    method="laboratory",
    sample="Okazaki: 150 flume runs -> plunging/collapsing 2.5, collapsing/surging 3.7",
    published_range=(2.5, 3.7),
    status=IN_RANGE,
    applies_to=(
        "Our single 3.3 collapses Okazaki's TWO boundaries (2.5 and 3.7) into one, so a "
        "'collapsing' class is not represented at all. 3.3 sits inside their bracket, which is why "
        "this is IN_RANGE rather than debt. The same 'not biunivocal' caveat as "
        "IRIBARREN_SPILLING_PLUNGING applies."),
))

# The swell-train gate (surf_partitions.py). Registered 2026-09-28, when the split out of surf_transform.py
# turned their grandfather entries stale: both were placed in a MEASURED gap, so the debt was only the record.
_add(Constant(
    name="PARTITION_MIN_QUAD_FRAC",
    value=0.5,
    units="dimensionless (quadrature of the swell trains' Hs / the total Hs)",
    what="Below this share of the total height the swell trains do not represent the sea, and the "
         "height falls back to the total field instead of inflating a minority train.",
    module="services.weather_pipeline.surf_partitions",
    source="OURS. Review of 2026-07-30 (a lone cached swell_1 of 0.84 m against a 1.73 m total would have "
           "been scaled x2.06 into a clean 10.25 s sea that never existed); "
           "docs/research/AUDIT-2026-08-01-sota-architecture-and-zero-regression-upgrade-path.md section 2.7",
    method="model",
    sample="the measured deviations of the trains' quadrature from their own total (review 2026-07-30): the "
           "largest LEGITIMATE under-read is Bondi -22.3% (0.777 of the total), far above the 0.5 floor",
    published_range=None,
    status=DERIVED,
    applies_to="The served total Hs and its swell_1 / swell_2 / wind_waves partitions at one point and hour.",
))

_add(Constant(
    name="PARTITION_MAX_TP_RATIO",
    value=1.10,
    units="dimensionless (total peak period / the longest partition period)",
    what="Above this ratio the trains are missing a long swell the total's peak period comes from, so "
         "they do not represent the sea and the height falls back to the total field.",
    module="services.weather_pipeline.surf_partitions",
    source="OURS. Measured live 2026-07-31 (the ratio's natural gap), recorded beside the constant and in "
           "docs/research/AUDIT-2026-08-01-sota-architecture-and-zero-regression-upgrade-path.md section 2.7",
    method="model",
    sample="36 samples, 6 Florida sites x forecast hours 0/6/12/24/48/72, GFS: median ratio 0.999; the 7 above "
           "1.0 split at a gap near 1.08 -- 1.002 / 1.048 / 1.050 (rounding on a tie) vs 1.116 / 1.131 / "
           "1.171 / 1.330 (a total period no partition can produce); 1.10 admits the first three, rejects the four",
    published_range=None,
    status=DERIVED,
    applies_to="GFS-Wave partitions at 6 Florida sites; the gap has not been re-measured on EURO or ICON trains.",
))


# --- accessors ----------------------------------------------------------------------------------

def all_constants() -> Dict[str, Constant]:
    """The whole registry, keyed by name."""
    return dict(_REGISTRY)


def get(name: str) -> Constant:
    return _REGISTRY[name]


def value(name: str) -> float:
    return _REGISTRY[name].value


def in_published_range(name: str) -> Optional[bool]:
    """True/False, or None when the quantity has no published range."""
    c = _REGISTRY[name]
    if c.published_range is None:
        return None
    lo, hi = c.published_range
    return lo <= c.value <= hi


def out_of_range_names() -> Tuple[str, ...]:
    """Constants whose live value sits outside what their own source observed. This IS the debt
    list, and it is meant to be read -- see test_science_registry.py for the ratchet."""
    return tuple(sorted(n for n, c in _REGISTRY.items() if c.status == OUT_OF_RANGE))


def provenance(name: str) -> str:
    """One human-readable paragraph. Used by the weather sim to explain a number rather than
    merely emit it -- a number with no provenance is how GAMMA_MAX_STEEP survived."""
    c = _REGISTRY[name]
    rng = ("published range %.3f-%.3f" % c.published_range) if c.published_range else "no published range"
    line = ("%s = %g %s -- %s | source: %s (%s, %s) | %s | status: %s"
            % (c.name, c.value, c.units, c.what, c.source, c.method, c.sample, rng, c.status))
    if c.applies_to:
        line += " | measured on: %s" % c.applies_to
    if c.debt_reason:
        line += " | DEBT: %s" % c.debt_reason
    return line
