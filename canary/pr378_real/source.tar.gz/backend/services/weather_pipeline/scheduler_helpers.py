"""
Scheduler helper utilities extracted from scheduler.py for LOC compliance.
Contains mock data generators, environment detection, and the common
normalize-and-save loop used by all ingestion tasks.
"""
import asyncio
import gc
import logging
import math
import os
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)

# Pilot-region SELECTION moved to pilot_regions.py 2026-07-31 (LOC gate). Re-exported by NAME — not
# `import *` — so every existing `from ...scheduler_helpers import get_pilot_regions` keeps working
# and this list stays an explicit, greppable record of the module's public surface.
from services.weather_pipeline.pilot_regions import (      # noqa: E402,F401
    REGIONAL_CONFIGS,
    WORLDWIDE_COASTAL_REGIONS,
    _select_rotating_regions,
    last_run_by_region_for_lane,
    select_stale_first_regions,
    get_pilot_regions,
    is_flagship_pilot_region,
    flagship_pilot_days,
    get_all_pilot_regions,
    GFS_MARINE_EXTRA_REGIONS,
    get_gfs_marine_pilot_regions,
)


def get_env_flags() -> dict:
    """Returns environment detection flags used by all ingestion tasks."""
    import sys
    node_env = os.environ.get("NODE_ENV", "").lower()
    env = os.environ.get("ENV", "").lower()
    is_prod = os.environ.get("IS_PROD", "").lower()
    local_test_fixture = os.environ.get("LOCAL_TEST_FIXTURE", "").lower() == "true"
    
    is_pytest = "pytest" in sys.modules
    
    is_test = False
    if is_pytest:
        if not (node_env == "production" or env == "production" or is_prod == "true"):
            is_test = (
                os.environ.get("NODE_ENV") == "test" or
                local_test_fixture or
                os.environ.get("TESTING") == "1"
            )
    else:
        if local_test_fixture:
            is_test = True
        elif not (node_env == "production" or env == "production" or is_prod == "true"):
            is_test = (
                os.environ.get("NODE_ENV") == "test" or
                local_test_fixture or
                os.environ.get("TESTING") == "1"
            )
            
    return {
        "is_render": os.environ.get("RENDER") == "true",
        "is_test_env": is_test,
    }


def generate_mock_marine_results(om_provider, region: dict, resolution: float,
                                 include_swell_2: bool = True) -> list:
    """Generate mock marine raw results for test environments."""
    results = []
    lats, lons = om_provider.generate_grid_coords(region, resolution)
    base_time = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    forecast_days = int(os.environ.get("GFS_MARINE_FORECAST_DAYS", "8"))
    times = [
        (base_time + timedelta(hours=h)).strftime("%Y-%m-%dT%H:00:00Z")
        for h in range(0, forecast_days * 24)
    ]
    units = {
        "wave_height": "m", "wave_direction": "°", "wave_period": "s",
        "swell_wave_height": "m", "swell_wave_direction": "°", "swell_wave_period": "s",
        "wind_wave_height": "m", "wind_wave_direction": "°", "wind_wave_period": "s",
    }
    if include_swell_2:
        units.update({
            "secondary_swell_wave_height": "m",
            "secondary_swell_wave_direction": "°",
            "secondary_swell_wave_period": "s",
        })

    for lat, lon in zip(lats, lons):
        hourly = {
            "time": times,
            "wave_height": [1.2 + 0.4 * math.sin(lat) for _ in times],
            "wave_direction": [240.0 for _ in times],
            "wave_period": [10.0 for _ in times],
            "swell_wave_height": [0.8 + 0.3 * math.sin(lat) for _ in times],
            "swell_wave_direction": [110.0 for _ in times],
            "swell_wave_period": [8.0 for _ in times],
            "wind_wave_height": [0.5 + 0.2 * math.sin(lat) for _ in times],
            "wind_wave_direction": [100.0 for _ in times],
            "wind_wave_period": [5.0 for _ in times],
        }
        if include_swell_2:
            hourly.update({
                "secondary_swell_wave_height": [0.3 + 0.1 * math.sin(lat) for _ in times],
                "secondary_swell_wave_direction": [140.0 for _ in times],
                "secondary_swell_wave_period": [6.0 for _ in times],
            })
        results.append({
            "latitude": lat, "longitude": lon,
            "hourly_units": units.copy(),
            "hourly": hourly,
            "is_test_fixture": True,
        })
    return results


def generate_mock_icon_marine_results(om_provider, region: dict, resolution: float) -> list:
    """Generate mock ICON marine raw results (no swell_2)."""
    lats, lons = om_provider.generate_grid_coords(region, resolution)
    base_time = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    forecast_days = 7
    times = [
        (base_time + timedelta(hours=h)).strftime("%Y-%m-%dT%H:00:00Z")
        for h in range(0, forecast_days * 24)
    ]
    results = []
    for lat, lon in zip(lats, lons):
        results.append({
            "latitude": lat, "longitude": lon,
            "hourly_units": {
                "wave_height": "m", "wave_direction": "°", "wave_period": "s",
                "swell_wave_height": "m", "swell_wave_direction": "°", "swell_wave_period": "s",
                "wind_wave_height": "m", "wind_wave_direction": "°", "wind_wave_period": "s",
            },
            "hourly": {
                "time": times,
                "wave_height": [1.1 + 0.3 * math.sin(lat) for _ in times],
                "wave_direction": [245.0 for _ in times],
                "wave_period": [9.0 for _ in times],
                "swell_wave_height": [0.7 + 0.2 * math.sin(lat) for _ in times],
                "swell_wave_direction": [115.0 for _ in times],
                "swell_wave_period": [7.5 for _ in times],
                "wind_wave_height": [0.4 + 0.1 * math.sin(lat) for _ in times],
                "wind_wave_direction": [105.0 for _ in times],
                "wind_wave_period": [4.5 for _ in times],
            },
            "is_test_fixture": True,
        })
    return results


def generate_mock_wind_results(om_provider, region: dict, resolution: float,
                               speed_base: float = 8.5, dir_base: float = 120.0,
                               include_gusts: bool = False, gust_base: float = 12.0,
                               forecast_days: int = 2, is_test_fixture: bool = True) -> list:
    """Generate mock wind raw results for test environments using a high-fidelity model."""
    lats, lons = om_provider.generate_grid_coords(region, resolution)
    base_time = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    times = [
        (base_time + timedelta(hours=h)).strftime("%Y-%m-%dT%H:00:00Z")
        for h in range(0, forecast_days * 24)
    ]
    
    # Storm center parameters (moving storm in North Atlantic)
    storm_lat_start = 25.0
    storm_lon_start = -60.0
    
    results = []
    for lat, lon in zip(lats, lons):
        lat_rad = math.radians(lat)
        lon_rad = math.radians(lon)
        lat_deg = lat
        lon_deg = lon
        
        # Calculate base planetary wind parameters for this latitude
        if abs(lat_deg) < 30.0:
            planet_dir = 90.0 - 45.0 * (lat_deg / 30.0)
            planet_speed = 12.0 + 4.0 * math.cos(lat_rad * 3.0)
        elif abs(lat_deg) < 60.0:
            pct = (abs(lat_deg) - 30.0) / 30.0
            start_dir = 45.0 if lat_deg >= 0.0 else 135.0
            target_dir = 225.0 if lat_deg >= 0.0 else 315.0
            planet_dir = start_dir + (target_dir - start_dir) * pct
            planet_speed = 15.0 + 7.0 * math.sin(pct * math.pi)
        else:
            pct = (abs(lat_deg) - 60.0) / 30.0
            start_dir = 225.0 if lat_deg >= 0.0 else 315.0
            target_dir = 90.0 - 45.0 * (lat_deg / 90.0)
            planet_dir = start_dir + (target_dir - start_dir) * pct
            planet_speed = 8.0 + 4.0 * math.cos(pct * math.pi / 2.0)
            
        units = {"wind_speed_10m": "kn", "wind_direction_10m": "°"}
        wind_speeds = []
        wind_dirs = []
        wind_gusts = []
        
        for h in range(len(times)):
            t_factor = math.sin(h / 12.0)
            
            storm_lat = storm_lat_start + 1.5 * (h / 24.0)
            storm_lon = storm_lon_start + 4.0 * (h / 24.0)
            if storm_lon > 180.0:
                storm_lon -= 360.0
            
            dx = lon_deg - storm_lon
            if dx > 180.0:
                dx -= 360.0
            elif dx < -180.0:
                dx += 360.0
            dy = lat_deg - storm_lat
            dist = math.sqrt(dx*dx + dy*dy)
            
            storm_weight = math.exp(-dist / 12.0)
            is_nh = lat_deg >= 0
            spiral_inflow = math.radians(20.0)
            if is_nh:
                tangent_rad = math.atan2(dy, dx) + math.pi/2.0 + spiral_inflow
            else:
                tangent_rad = math.atan2(dy, dx) - math.pi/2.0 - spiral_inflow
            
            storm_dir = (math.degrees(tangent_rad)) % 360.0
            storm_speed = 45.0 * (dist / 2.5) * math.exp(-dist / 4.0)
            
            final_dir = (1.0 - storm_weight) * planet_dir + storm_weight * storm_dir
            final_dir = (final_dir + 15.0 * t_factor) % 360.0
            
            final_speed = (1.0 - storm_weight) * planet_speed + storm_weight * storm_speed
            final_speed = max(2.0, final_speed + 3.0 * t_factor)
            
            wind_speeds.append(round(final_speed, 2))
            wind_dirs.append(round(final_dir, 2))
            if include_gusts:
                wind_gusts.append(round(final_speed * 1.3 + 4.0 * t_factor, 2))
                
        hourly = {
            "time": times,
            "wind_speed_10m": wind_speeds,
            "wind_direction_10m": wind_dirs,
        }
        if include_gusts:
            units["wind_gusts_10m"] = "kn"
            hourly["wind_gusts_10m"] = wind_gusts
            
        results.append({
            "latitude": lat, "longitude": lon,
            "hourly_units": units,
            "hourly": hourly,
            "is_test_fixture": is_test_fixture,
        })
    return results


def generate_mock_pressure_results(om_provider, region: dict, resolution: float) -> list:
    """Generate mock pressure raw results for test environments."""
    lats, lons = om_provider.generate_grid_coords(region, resolution)
    base_time = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    times = [
        (base_time + timedelta(hours=h)).strftime("%Y-%m-%dT%H:00:00Z")
        for h in range(0, 24)
    ]
    results = []
    for lat, lon in zip(lats, lons):
        results.append({
            "latitude": lat, "longitude": lon,
            "hourly_units": {"pressure_msl": "hPa"},
            "hourly": {
                "time": times,
                "pressure_msl": [1013.2 + 2.5 * math.sin(lat) for _ in times],
            },
            "is_test_fixture": True,
        })
    return results


def generate_mock_copernicus_results(region: dict, resolution: float) -> list:
    """Generate mock Copernicus marine raw results for test environments."""
    from services.weather_pipeline.providers.open_meteo_provider import OpenMeteoProvider
    lats, lons = OpenMeteoProvider.generate_grid_coords(region, resolution)
    base_time = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    times = [
        (base_time + timedelta(hours=h)).strftime("%Y-%m-%dT%H:00:00Z")
        for h in range(0, 243, 3)
    ]
    results = []
    for lat, lon in zip(lats, lons):
        results.append({
            "latitude": lat, "longitude": lon,
            "generationtime_ms": 0, "utc_offset_seconds": 0,
            "timezone": "GMT", "timezone_abbreviation": "GMT",
            "elevation": 0, "__provider": "test-fixture",
            "hourly_units": {
                "time": "iso8601",
                "swell_wave_height": "m", "swell_wave_direction": "°", "swell_wave_period": "s",
                "secondary_swell_wave_height": "m", "secondary_swell_wave_direction": "°",
                "secondary_swell_wave_period": "s",
                "wind_wave_height": "m", "wind_wave_direction": "°", "wind_wave_period": "s",
                "wave_height": "m", "wave_direction": "°", "wave_period": "s",
            },
            "hourly": {
                "time": times,
                "swell_wave_height": [0.8 + 0.3 * math.sin(lat) for _ in times],
                "swell_wave_direction": [110.0 for _ in times],
                "swell_wave_period": [8.0 for _ in times],
                "secondary_swell_wave_height": [0.3 + 0.1 * math.sin(lat) for _ in times],
                "secondary_swell_wave_direction": [140.0 for _ in times],
                "secondary_swell_wave_period": [6.0 for _ in times],
                "wind_wave_height": [0.5 + 0.2 * math.sin(lat) for _ in times],
                "wind_wave_direction": [100.0 for _ in times],
                "wind_wave_period": [5.0 for _ in times],
                "wave_height": [1.0 + 0.3 * math.sin(lat) for _ in times],
                "wave_direction": [240.0 for _ in times],
                "wave_period": [10.0 for _ in times],
            },
            "is_test_fixture": True,
        })
    return results


async def normalize_and_save_loop(
    normalizer, store, results: list, model: str, provider: str,
    domain: str, layer: str, bbox: dict, resolution: float,
    run_time: datetime, region_id: Optional[str] = None,
    coverage_mode: Optional[str] = None,
    is_test_env: bool = False, step: int = 3,
    log_prefix: str = "[Pipeline Scheduler]",
    estimated_after_index: Optional[int] = None,
    estimate_basis: Optional[dict] = None
) -> int:
    """
    Common normalize-and-save loop used by all ingestion methods.
    Returns the number of successfully saved products.

    If estimated_after_index is set, products at or beyond that hourly index
    are tagged as is_estimated=True with the given estimate_basis.
    """
    first_pt = results[0]
    times = first_pt.get("hourly", {}).get("time", [])
    if not times:
        logger.error(f"{log_prefix} Payload missing hourly times array.")
        return 0

    products_to_save = []
    norm_kwargs = {
        "model": model, "provider": provider, "domain": domain, "layer": layer,
        "raw_results": results, "bbox": bbox, "resolution": resolution,
        "target_time": None, "run_time": run_time,
    }
    if region_id is not None:
        norm_kwargs["region_id"] = region_id
    if coverage_mode is not None:
        norm_kwargs["coverage_mode"] = coverage_mode

    for idx, time_str in enumerate(times):
        if idx % step != 0:
            continue
        try:
            # PARSE INSIDE the per-item guard (2026-07-20 bug-class sweep — the f9c5e59a
            # blast-radius shape, confirmed at all ~25 ingestion call sites): hourly.time is
            # unvalidated external JSON, and a degenerate entry here used to abort the loop
            # BEFORE save_products_batch — a completed multi-minute fetch's entire batch lost
            # instead of one timestep. Also: fromisoformat handles offset-suffixed ISO-8601
            # natively; the old blind Z-append turned a VALID '+00:00'-suffixed time into a
            # double-offset ValueError. Only bare-Z / naive strings need the shim.
            if time_str.endswith("Z"):
                target_dt = datetime.fromisoformat(time_str.replace("Z", "+00:00"))
            else:
                target_dt = datetime.fromisoformat(time_str)
                if target_dt.tzinfo is None:
                    target_dt = target_dt.replace(tzinfo=timezone.utc)
            norm_kwargs["target_time"] = target_dt

            product = await normalizer.normalize_async(**norm_kwargs)
            if product:
                # Security guard: reject test fixtures in non-test environments
                if not is_test_env and hasattr(product, 'is_test_fixture') and product.is_test_fixture:
                    logger.error(f"{log_prefix} Security violation: trying to save test fixture product in non-test environment.")
                    continue
                # Tag as estimated if beyond the native horizon
                if estimated_after_index is not None and idx >= estimated_after_index:
                    product.is_estimated = True
                    product.is_forecast_authoritative = False
                    product.estimate_basis = estimate_basis
                    if estimate_basis and isinstance(estimate_basis, dict) and "type" in estimate_basis:
                        product.source_dataset = estimate_basis["type"]
                elif estimated_after_index is None and estimate_basis is not None:
                    # NATIVE provenance basis (2026-07-04): a caller passing a basis WITHOUT any
                    # estimated_after_index horizon describes HOW native data was fetched/resampled
                    # (e.g. the CMEMS thin-band subset) WITHOUT flipping the estimated flags — real
                    # data must be labeled real. (Callers that DO pass a horizon keep the old
                    # contract exactly: hours before the horizon carry NO basis — ICON pressure's
                    # native <120h hours pin this in test_icon_pressure_global_ingestion.) Before
                    # this, the native Copernicus save loop passed estimated_after_index=0, stamping
                    # EVERY native CMEMS hour is_estimated=True (all 108 live EURO waves products
                    # were "_estimated"-named while /point proved the content native).
                    product.estimate_basis = estimate_basis
                
                products_to_save.append((product, resolution))
                await asyncio.sleep(0.01)
        except Exception as e:
            logger.error(
                f"{log_prefix} Normalization error for {model} {layer} at hour index {idx} "
                f"(time_str={time_str!r}): {e}"
            )

    success_count = 0
    if products_to_save:
        try:
            success_count = await asyncio.to_thread(store.save_products_batch, products_to_save)
        except Exception as e:
            logger.error(f"{log_prefix} Failed to save batch of products: {e}", exc_info=True)
        del products_to_save
        gc.collect()

    return success_count



def find_nearest_manifest_product(
    manifest, model: str, domain: str, layer: str, region_id: str,
    target_time: datetime, max_delta_hours: float = 3.0
):
    """
    Locates the product in manifest closest to target_time within max_delta_hours.
    Returns the ManifestProduct item or None if no product is close enough.
    """
    env = get_env_flags()
    candidates = [
        p for p in manifest.products
        if (
            p.model.upper() == model.upper()
            and p.domain.lower() == domain.lower()
            and p.layer.lower() == layer.lower()
            and p.region_id == region_id
        )
    ]
    if not candidates:
        return None

    best_candidate = min(candidates, key=lambda p: abs((p.valid_time_start - target_time).total_seconds()))
    delta_sec = abs((best_candidate.valid_time_start - target_time).total_seconds())
    if delta_sec <= max_delta_hours * 3600.0:
        return best_candidate
    return None


def euro_estimate_anchor_pool(products, region_id: str, layer: str, is_test_or_local: bool) -> list:
    """Anchor candidates for the EURO extended-estimates job: the NATIVE (non-estimated) EURO
    products of this region+layer — estimates extend FROM the native horizon, never from a prior
    estimate (compounding drift).

    REGRESSION NOTE (2026-07-05, the "EURO loses its last 4 days" outage): the global_coarse branch
    used to require `p.is_estimated` — written in the era when native CMEMS global products were
    MISLABELED estimated (pre-7b89eadf). Once provenance was fixed (native → is_estimated:false),
    the filter matched only leftover stale estimated tails; the first full re-ingestion after the
    07-03→07-05 cron outage pruned those, the pool went EMPTY, every layer skipped, and no
    241-336h products were built — EURO 404'd past ~240h and ICON's >168h blend (which needs the
    EURO component) died with it. Anchor on natives for EVERY region.
    """
    is_global = region_id in ("global_coarse", "global_mid")
    return [
        p for p in products
        if (
            p.model == "EURO"
            and p.domain == "marine"
            and p.layer == layer
            and p.region_id == region_id
            and (p.is_forecast_authoritative if (not is_global and not is_test_or_local) else True)
            and (not p.is_estimated or is_test_or_local)
        )
    ]


def _coerce_utc(dt):
    """Normalize a datetime-or-ISO-string to a tz-aware UTC datetime (None-safe). A product's
    run_time can arrive as a datetime or an ISO string depending on the store path, and mixing
    naive/aware datetimes raises on subtraction."""
    if dt is None:
        return None
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except Exception:
            return None
    if getattr(dt, "tzinfo", None) is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def euro_estimate_within_ceiling(target_time, run_time, anchor_time, native_limit, ceiling_hours=336.0):
    """True if an estimate valid at ``target_time`` is within the published EURO horizon (run + ceiling).

    THE TAIL-LOSS BUG (2026-07-07): the estimate loop clamped on ``native_limit + (target - anchor)``,
    i.e. it ASSUMES the native anchor sits at exactly ``native_limit`` (240h). But CMEMS native
    horizon varies run-to-run by data availability — on the 2026-07-07 run the native ended ~219h,
    so the anchor was ~21h short of 240h. The anchor-relative reading then OVER-counted every target
    by that shortfall and the 336h clamp fired ~a day early → the last ~day of the advertised 14-day
    EURO slider went BLANK (live: EURO waves cleared past ~315h). Measuring the ceiling from the RUN
    fills estimates to the true run+336h horizon regardless of native length. Falls back to the
    anchor-relative reading only when run_time is unknown (keeps the legacy contract exactly)."""
    run = _coerce_utc(run_time)
    tt = _coerce_utc(target_time)
    if run is not None and tt is not None:
        return (tt - run).total_seconds() / 3600.0 <= ceiling_hours
    at = _coerce_utc(anchor_time)
    hours_diff = (tt - at).total_seconds() / 3600.0 if (tt is not None and at is not None) else 0.0
    return native_limit + hours_diff <= ceiling_hours


async def ingest_euro_marine_extended_estimates_impl(scheduler) -> bool:
    """Implementation of ingest_euro_marine_extended_estimates delegated from scheduler.

    Builds the EURO marine 10->14d ESTIMATED extension (persistence + GFS-14d/ICON blend) so the heatmap/
    scrub does not clear past EURO's ~10d native horizon. Wired into the decoupled cron after the marine
    globals. Kill switch EURO_MARINE_EXTEND=0.
    """
    if os.environ.get("EURO_MARINE_EXTEND", "1") == "0":
        logger.info("[Pipeline Scheduler] EURO_MARINE_EXTEND=0 — skipping EURO marine extended estimates.")
        return False
    from services.weather_pipeline.estimator import (
        estimate_euro_grid, EURO_LIMIT_WAVES, EURO_LIMIT_COMPONENTS, EstimateContractError
    )
    env = get_env_flags()
    is_test_or_local = env.get("is_test_env", False) or not env.get("is_render", False)
    manifest = await asyncio.to_thread(scheduler.store.get_manifest)
    products_to_save = []
    
    regions_to_process = dict(REGIONAL_CONFIGS)
    regions_to_process["global_coarse"] = {
        "west": -180.0,
        "south": -80.0,
        "east": 180.0,
        "north": 85.0,
        "resolution": 10.0
    }
    # MID-RES mirror (2026-07-05): the z6-7 tier's `global_mid` products must carry the SAME 240→336h
    # estimated extension as global_coarse, or scrubbing past EURO's native horizon at zoom-out drops
    # back to the 10° lattice. This machinery is already region-parameterized (anchors/targets keyed on
    # region_id; estimate_euro_grid carries region_id + the anchor's resolution through) — adding the
    # region is a per-layer NO-OP until EURO global_mid native anchors exist (EURO mid ingest is
    # default-OFF), while GFS global_mid targets (14d) are already ingested.
    regions_to_process["global_mid"] = {
        "west": -180.0,
        "south": -80.0,
        "east": 180.0,
        "north": 85.0,
        "resolution": float(os.environ.get("EURO_MID_RES", os.environ.get("GFS_MID_RES", "2.0")))
    }
    
    for region_id, region in regions_to_process.items():
        logger.info(f"[Pipeline Scheduler] Processing region for estimates: {region_id}")
        layers = ["waves", "swell_1", "swell_2", "wind_waves"]
        
        for layer in layers:
            # 1. Find the last NATIVE EURO product (the anchor) — see euro_estimate_anchor_pool.
            euro_products = euro_estimate_anchor_pool(
                manifest.products, region_id, layer, is_test_or_local
            )
            if not euro_products:
                # INFO, not debug: an empty pool on global_coarse is exactly the silent-skip that
                # collapsed the EURO horizon to 10 days (2026-07-05) — keep it visible in cron logs.
                logger.info(f"[Pipeline Scheduler] No EURO marine {layer} anchor candidates for region {region_id}. Skipping layer.")
                continue
            
            # The anchor is the one with the maximum valid_time_start
            euro_anchor_item = max(euro_products, key=lambda p: p.valid_time_start)
            anchor_time = euro_anchor_item.valid_time_start
            logger.info(f"[Pipeline Scheduler] Found EURO marine {layer} anchor for {region_id} at {anchor_time.isoformat()}")
            
            # Load the full euro anchor product
            euro_anchor_product = await asyncio.to_thread(scheduler.store.load_product, euro_anchor_item.filename)
            if not euro_anchor_product:
                logger.warning(f"[Pipeline Scheduler] Failed to load EURO anchor product {euro_anchor_item.filename}. Skipping layer.")
                continue
            
            # 2. Find GFS anchor product near the anchor time (within 3h tolerance)
            gfs_anchor_item = find_nearest_manifest_product(
                manifest, "GFS", "marine", layer, region_id, anchor_time, max_delta_hours=3.0
            )
            if not gfs_anchor_item:
                logger.warning(f"[Pipeline Scheduler] No GFS anchor product found near {anchor_time.isoformat()} for {region_id} {layer}. Skipping layer.")
                continue
            
            gfs_anchor_product = await asyncio.to_thread(scheduler.store.load_product, gfs_anchor_item.filename)
            if not gfs_anchor_product:
                logger.warning(f"[Pipeline Scheduler] Failed to load GFS anchor product {gfs_anchor_item.filename}. Skipping layer.")
                continue
            
            # 3. Find ICON anchor product near the anchor time (within 3h tolerance, if layer != swell_2)
            icon_anchor_product = None
            icon_anchor_item = None
            if layer != "swell_2":
                icon_anchor_item = find_nearest_manifest_product(
                    manifest, "ICON", "marine", layer, region_id, anchor_time, max_delta_hours=3.0
                )
                if icon_anchor_item:
                    icon_anchor_product = await asyncio.to_thread(scheduler.store.load_product, icon_anchor_item.filename)
            
            native_limit = EURO_LIMIT_WAVES if layer == "waves" else EURO_LIMIT_COMPONENTS
            
            # 4. Find all GFS target products with valid_time > anchor_time
            gfs_targets = [
                p for p in manifest.products
                if (
                    p.model == "GFS"
                    and p.domain == "marine"
                    and p.layer == layer
                    and (p.region_id == region_id or (region_id == "global_coarse" and p.region_id in ("global_coarse", "global", None)))
                    and p.valid_time_start > anchor_time
                    and (not p.is_estimated or is_test_or_local)
                )
            ]
            # Sort targets chronologically
            gfs_targets.sort(key=lambda p: p.valid_time_start)
            
            # Ceiling measured from the RUN (run + 336h), robust to a short CMEMS native anchor —
            # a native ending shy of its nominal 240h used to truncate the estimate tail ~a day early
            # (see euro_estimate_within_ceiling). run_time lives on the loaded anchor product.
            euro_run_time = getattr(euro_anchor_product, "run_time", None)
            for gfs_target_item in gfs_targets:
                target_time = gfs_target_item.valid_time_start
                hours_diff = (target_time - anchor_time).total_seconds() / 3600.0
                target_hour = native_limit + hours_diff  # anchor-relative — keep for the blend decay

                # gfs_targets is sorted chronologically, so the first target past the run+336h ceiling
                # ends the run rather than generating unbounded estimates.
                if not euro_estimate_within_ceiling(target_time, euro_run_time, anchor_time, native_limit):
                    break

                # Load GFS target product
                gfs_target_product = await asyncio.to_thread(scheduler.store.load_product, gfs_target_item.filename)
                if not gfs_target_product:
                    continue
                
                # Load ICON target product (if layer != swell_2 and target_hour <= 168)
                icon_target_item = None
                icon_target_product = None
                is_icon_possible = (layer != "swell_2" and target_hour <= 168.0)
                
                if is_icon_possible and icon_anchor_product:
                    icon_target_item = find_nearest_manifest_product(
                        manifest, "ICON", "marine", layer, region_id, target_time, max_delta_hours=3.0
                    )
                    if icon_target_item:
                        icon_target_product = await asyncio.to_thread(scheduler.store.load_product, icon_target_item.filename)
                        if not icon_target_product:
                            logger.debug(f"[Pipeline Scheduler] Failed to load ICON target product {icon_target_item.filename}. Proceeding without ICON.")
                    else:
                        logger.debug(f"[Pipeline Scheduler] Missing ICON target product near {target_time.isoformat()}. Proceeding without ICON.")
                else:
                    if is_icon_possible and not icon_anchor_product:
                        logger.debug(f"[Pipeline Scheduler] Missing ICON anchor for target at {target_time.isoformat()}. Proceeding without ICON.")
                
                # Generate the estimate product grid
                logger.debug(f"[Pipeline Scheduler] Generating EURO marine {layer} estimate for {target_time.isoformat()} (offset: {target_hour}h)")
                try:
                    est_product = estimate_euro_grid(
                        target_hour=target_hour,
                        native_limit=native_limit,
                        active_layer=layer,
                        euro_anchor_product=euro_anchor_product,
                        gfs_target_product=gfs_target_product,
                        gfs_anchor_product=gfs_anchor_product,
                        icon_target_product=icon_target_product,
                        icon_anchor_product=icon_anchor_product,
                        euro_anchor_valid_time=euro_anchor_item.valid_time_start,
                        gfs_anchor_valid_time=gfs_anchor_item.valid_time_start,
                        icon_anchor_valid_time=icon_anchor_item.valid_time_start if (icon_anchor_item and icon_anchor_product) else None,
                        gfs_target_valid_time=gfs_target_item.valid_time_start,
                        icon_target_valid_time=icon_target_item.valid_time_start if (icon_target_item and icon_target_product) else None
                    )
                    
                    if est_product:
                        products_to_save.append((est_product, euro_anchor_item.resolution))
                except EstimateContractError as e:
                    logger.error(
                        f"[Pipeline Scheduler] Skipped invalid estimate for region={region_id}, layer={layer}, "
                        f"target_time={target_time.isoformat()} due to contract error: {e}"
                    )
                    continue
                except Exception as e:
                    # 2026-07-20 (run 29724899253): an UnboundLocalError out of estimate_euro_grid
                    # escaped this narrow catch and killed the WHOLE job — the FL/SoCal estimates
                    # already generated were never batch-saved (save runs after all regions) and
                    # global_coarse/global_mid never processed. One bad target must cost exactly
                    # one target.
                    logger.error(
                        f"[Pipeline Scheduler] Unexpected estimate failure for region={region_id}, layer={layer}, "
                        f"target_time={target_time.isoformat()}: {type(e).__name__}: {e}", exc_info=True
                    )
                    continue
                        
    total_saved = 0
    if products_to_save:
        try:
            total_saved = await asyncio.to_thread(scheduler.store.save_products_batch, products_to_save)
        except Exception as e:
            logger.error(f"[Pipeline Scheduler] Failed to save batch of estimated products: {e}", exc_info=True)
            
    logger.info(f"[Pipeline Scheduler] EURO Marine Extended Estimate Ingestion job completed. Saved {total_saved} estimated product files.")
    return total_saved > 0

