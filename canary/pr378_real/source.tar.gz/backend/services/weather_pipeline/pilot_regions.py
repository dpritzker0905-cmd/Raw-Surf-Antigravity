"""
pilot_regions.py — WHICH regions the marine + wind pilots ingest this cycle.

Extracted from scheduler_helpers.py 2026-07-31 (LOC gate) at the moment this logic became the
best-covered part of that file: the starvation arc added 46 focused tests, so the extraction is
verified by construction rather than by inspection. `scheduler_helpers` re-exports every name, so
existing `from ...scheduler_helpers import get_pilot_regions` imports keep working unchanged.

The whole point of this module is the SELECTION RULE, and the history is the reason it is one file:
a clock-derived rotation silently starved 2 of 8 regions for months (see get_pilot_regions).
"""
import os
from datetime import datetime, timezone

import logging

logger = logging.getLogger(__name__)


REGIONAL_CONFIGS = {
    "florida_east_coast": {
        "west": -85.0,
        "south": 24.0,
        "east": -79.0,
        "north": 31.0,
        "resolution": 0.25
    },
    "us_west_coast_socal": {
        "west": -125.0,
        "south": 30.0,
        "east": -115.0,
        "north": 38.0,
        "resolution": 0.25
    }
}

# Worldwide coastal surf regions (0.25°), refreshed ROUND-ROBIN across cron cycles (see get_pilot_regions)
# so worldwide coverage fits the fixed ~120min CI budget — ingesting every coast at 0.25° each cycle would
# blow it (marine pilot is ~5-15min PER region). The flagship REGIONAL_CONFIGS (FL, SoCal) ingest EVERY
# cycle (no regression); these rotate WORLDWIDE_REGIONS_PER_CYCLE at a time. Boxes hug the primary surf
# coasts. This is the worldwide half of the coastal-resolution gap (was FL+SoCal only).
WORLDWIDE_COASTAL_REGIONS = {
    "hawaii":                    {"west": -161.0, "south": 18.0,  "east": -154.0, "north": 23.0,  "resolution": 0.25},
    "iberia_west":               {"west": -11.0,  "south": 36.0,  "east": -6.0,   "north": 44.0,  "resolution": 0.25},
    "uk_ireland":                {"west": -11.0,  "south": 49.0,  "east": 1.0,    "north": 59.0,  "resolution": 0.25},
    "east_australia":            {"west": 150.0,  "south": -38.0, "east": 156.0,  "north": -25.0, "resolution": 0.25},
    "indonesia":                 {"west": 98.0,   "south": -11.0, "east": 120.0,  "north": 2.0,   "resolution": 0.25},
    "brazil_east":               {"west": -49.0,  "south": -27.0, "east": -34.0,  "north": -3.0,  "resolution": 0.25},
    "south_africa":              {"west": 17.0,   "south": -35.0, "east": 28.0,   "north": -31.0, "resolution": 0.25},
    "mexico_centralamerica_pac": {"west": -106.0, "south": 8.0,   "east": -84.0,  "north": 21.0,  "resolution": 0.25},
    # ── 2026-08-09 EXPANSION, PRICED BY CENSUS (MASTER-AUDIT-11.0's largest accuracy lever). The
    # SERVED catalogue held 1,773 spots and 979 (55.2%) had NO 0.25° box — their forcing was a 2°
    # or 10° global cell (repo's own tier delta: median 21% height change). Greedy densest-window
    # proposals over the UNCOVERED population ranked these four clusters top; together they move
    # 241 spots (24.6% of the uncovered mass) onto fine forcing. COST, measured not guessed:
    # pilots runs p50 82 / p90 124 min against a 200-min budget, a rotation slot is ~5-15 min, and
    # WORLDWIDE_REGIONS_PER_CYCLE rose 2→3 IN THE SAME COMMIT so the refresh cadence stays exactly
    # ceil(12/3)*8 h = 32 h — the bound the run-age census thresholds and the starvation test
    # assume. ⛔ Add a region WITHOUT raising the divisor and the cadence silently lengthens;
    # test_worldwide_count_and_per_cycle_keep_the_32h_cadence reads the workflow env and fails.
    # ★ The tie-break shipped first (3eeda053) so these fine tiles WIN their time ties against the
    # covering globals instead of losing to manifest order. Shared edges below are deliberate
    # abutments (31.0N with florida_east_coast; 37.5N between the two new US boxes; -6.0E with
    # iberia_west) — edge-touch is legal, interior overlap is test-banned.
    "us_southeast_midatlantic":  {"west": -82.0,  "south": 31.0,  "east": -74.4,  "north": 37.5,  "resolution": 0.25},  # 86 spots: Folly→Virginia Beach
    "azores":                    {"west": -29.8,  "south": 36.0,  "east": -24.0,  "north": 40.1,  "resolution": 0.25},  # 57 spots
    "us_northeast":              {"west": -76.1,  "south": 37.5,  "east": -69.0,  "north": 44.6,  "resolution": 0.25},  # 53 spots: NJ→Maine
    "france_biscay":             {"west": -6.0,   "south": 42.5,  "east": 1.0,    "north": 48.8,  "resolution": 0.25},  # 45 spots: Anglet→Brittany
}


def _select_rotating_regions(flagship: dict, worldwide_items: list, per_cycle: int, cycle_index: int) -> dict:
    """Flagship regions always + a rotating window of `per_cycle` worldwide regions (round-robin by cron
    cycle). Pure/deterministic for testing. Over ceil(N/per_cycle) cycles every worldwide region is
    refreshed, keeping per-cycle ingestion cost (and thus CI time) bounded."""
    regions = dict(flagship)
    n = len(worldwide_items)
    if per_cycle > 0 and n > 0:
        start = (cycle_index * per_cycle) % n
        for i in range(min(per_cycle, n)):
            rid, rcfg = worldwide_items[(start + i) % n]
            regions[rid] = rcfg
    return regions


def last_run_by_region_for_lane(manifest, model: str, domain: str, region_ids) -> dict:
    """Newest product run_time per region for ONE (model, domain) lane. Pure; missing region -> absent.

    ⚠️ LANE-SCOPED ON PURPOSE. Aggregating run_time across ALL lanes destroys the signal: ICON/EURO
    marine use get_all_pilot_regions() (every region, every cycle), so a whole-manifest "newest per
    region" reads ~5h fresh EVERYWHERE and would rank GFS marine's 18.6-day-old uk_ireland as current.
    The aggregate hides exactly the defect this selects against.
    """
    wanted = set(region_ids)
    out: dict = {}
    for p in (getattr(manifest, "products", None) or []):
        rid = getattr(p, "region_id", None)
        if rid not in wanted:
            continue
        if str(getattr(p, "model", "")).upper() != model.upper():
            continue
        if str(getattr(p, "domain", "")).lower() != domain.lower():
            continue
        rt = getattr(p, "run_time", None)
        if not isinstance(rt, datetime):
            continue
        rt = rt if rt.tzinfo else rt.replace(tzinfo=timezone.utc)
        if rid not in out or rt > out[rid]:
            out[rid] = rt
    return out


def select_stale_first_regions(flagship: dict, worldwide_items: list, per_cycle: int,
                               last_run: dict, cycle_index: int) -> dict:
    """Flagship always + the `per_cycle` worldwide regions that have gone LONGEST without ingestion.

    Replaces the clock-derived round-robin, which starved regions (see get_pilot_regions). Pure.
    A region with NO recorded run sorts first (never ingested = maximal need). Ties break on the
    round-robin position for this cycle, so a cold start still rotates instead of pinning the first
    two regions forever.

    ★ This is the coverage-class remedy: selection is accountable to what was actually covered, so a
    missed turn moves a region to the FRONT of the queue instead of losing it silently. It cannot be
    desynchronised by cron period, job duration, or CI drift — none of those are inputs.
    """
    regions = dict(flagship)
    n = len(worldwide_items)
    if per_cycle <= 0 or n == 0:
        return regions
    order = {rid: i for i, (rid, _) in enumerate(worldwide_items)}
    start = (cycle_index * per_cycle) % n
    # Round-robin distance from this cycle's start — the deterministic tie-break.
    rr = {rid: (order[rid] - start) % n for rid, _ in worldwide_items}
    epoch = datetime(1970, 1, 1, tzinfo=timezone.utc)
    ranked = sorted(worldwide_items, key=lambda kv: (last_run.get(kv[0]) or epoch, rr[kv[0]]))
    for rid, rcfg in ranked[:min(per_cycle, n)]:
        regions[rid] = rcfg
    return regions


def get_pilot_regions(store=None, model: str = None, domain: str = None) -> dict:
    """Regions the marine + wind PILOTS ingest THIS cron cycle: the flagship REGIONAL_CONFIGS (always) plus
    a slice of WORLDWIDE_COASTAL_REGIONS so worldwide coastal 0.25° coverage is achieved within the
    fixed CI budget. Env: WORLDWIDE_COASTAL=0 reverts to flagship-only; WORLDWIDE_REGIONS_PER_CYCLE (default
    1) tunes how many worldwide regions per cycle (raise once CI headroom is confirmed). Test env returns
    flagship-only so deterministic ingestion tests are unaffected.

    ⛔ THE CLOCK ROTATION STARVED REGIONS (measured 2026-07-31, live manifest). `cycle_index` quantises
    wall-clock into 3-HOUR buckets, but the ONLY lane that consumes it is forecast-ingest-pilots.yml,
    which fires 3x/day at 8-HOUR intervals (forecast-ingest.yml runs INGEST_PILOTS=skip). 24h is a
    common multiple of 3h and 8h, so `cycle_index % 4` takes only THREE of its four values every day
    and one adjacent PAIR of regions is never selected at all. Simulated over 30 days of the real cron:
    exactly 2 of 8 regions score ZERO hits, and WHICH two depends only on how many minutes into the job
    the lane happens to run (+0 min starves hawaii+iberia_west; +180 min starves uk_ireland+
    east_australia). Job duration drifts, so the starved pair moves and starvation is intermittent —
    live consequence: GFS marine uk_ireland and east_australia at run age 447.5 h (18.6 DAYS) against a
    12 h design intent, holding 1 and 3 products respectively.
    ★ test_rotation_covers_every_worldwide_region_over_cycles passed throughout: it feeds CONSECUTIVE
      cycle indices, which production never delivers. The function was a correct round-robin over a
      counter it does not receive.
    ⇒ Default is now STALE-FIRST (select_stale_first_regions), which reads what was actually ingested
      instead of guessing from the clock. Kill switch: PILOT_REGION_STALE_FIRST=0 restores the rotation.
      Any failure to read the manifest also falls back to it — a health heuristic must never be able to
      stop ingestion.
    """
    from services.weather_pipeline.copernicus_validator import is_test_environment
    if os.environ.get("WORLDWIDE_COASTAL", "1") == "0" or is_test_environment():
        return dict(REGIONAL_CONFIGS)
    per_cycle = max(0, int(os.environ.get("WORLDWIDE_REGIONS_PER_CYCLE", "1")))
    cycle_index = int(datetime.now(timezone.utc).timestamp() // (3 * 3600))
    ww_items = list(WORLDWIDE_COASTAL_REGIONS.items())

    if store is not None and model and domain and os.environ.get("PILOT_REGION_STALE_FIRST", "1") != "0":
        try:
            last_run = last_run_by_region_for_lane(
                store.get_manifest(), model, domain, WORLDWIDE_COASTAL_REGIONS.keys())
            picked = select_stale_first_regions(
                REGIONAL_CONFIGS, ww_items, per_cycle, last_run, cycle_index)
            now = datetime.now(timezone.utc)
            ages = {r: (round((now - last_run[r]).total_seconds() / 3600.0, 1) if r in last_run else None)
                    for r in picked if r not in REGIONAL_CONFIGS}
            logger.info(f"[Pilot regions] {model}/{domain} stale-first picked {ages} "
                        f"(age_h; None = never ingested)")
            return picked
        except Exception as e:
            logger.warning(f"[Pilot regions] stale-first unavailable for {model}/{domain} "
                           f"({e!r}); falling back to the clock rotation.")
    return _select_rotating_regions(REGIONAL_CONFIGS, ww_items, per_cycle, cycle_index)


def is_flagship_pilot_region(region_id: str) -> bool:
    """A FLAGSHIP pilot region (REGIONAL_CONFIGS = FL / SoCal) ingests EVERY cron cycle, so it can
    afford the full native forecast horizon; the rotating WORLDWIDE regions stay shorter to hold the
    ~165-min CI budget. Used by the flagship-first horizon selection (2026-07-15)."""
    return region_id in REGIONAL_CONFIGS


def flagship_pilot_days(region_id: str, flagship_days: int, worldwide_days: int) -> int:
    """Flagship-first forecast horizon (2026-07-15, the '14-day state-of-the-art fine pilots' arc):
    the ever-present flagship coasts carry the long native horizon; the rotating worldwide regions
    stay at the shorter budget horizon so the CI stays green. Pure — flagship_days if the region is a
    flagship, else worldwide_days."""
    return flagship_days if is_flagship_pilot_region(region_id) else worldwide_days


# ── F-08 STAGE A (audit 14.1, 2026-09-25): GFS-MARINE-ONLY coverage expansion ──────────────────
# Census on the live catalogue (1,773 spots): 732 (41.3%) sit outside every 0.25 deg box above, so
# their marine scrub is either the live Open-Meteo series (GFS_ICON_SERIES_FASTPATH) or a 2 deg
# global cell. These are the four densest greedy 10x8 deg windows over that uncovered set
# (audit/weather-simulation-14.1/F08-COVERAGE-PROPOSAL.md), re-measured on the live list: +186 spots.
# ⭐ KEPT OUT OF WORLDWIDE_COASTAL_REGIONS ON PURPOSE. That dict also feeds the ICON/EURO marine
#   pilots (get_all_pilot_regions) and the rotation, so adding here would triple the product cost
#   and stretch the 32 h cadence. The GFS pass is a single whole-globe NOAA download sliced per box,
#   so these cost only normalize/save + manifest rows (~220 products each) -- the binding constraint
#   is Render RSS (proposal §3), which is why Stage A is four boxes and must be measured before B.
# A4's west edge is trimmed -85 -> -84 so it ABUTS mexico_centralamerica_pac instead of overlapping
# it; the trim loses no uncovered spot (29 either way).
# Kill switch: GFS_MARINE_EXTRA_REGIONS=0.
GFS_MARINE_EXTRA_REGIONS = {
    "canaries_madeira_morocco": {"west": -19.0, "south": 26.0, "east": -9.0,  "north": 34.0, "resolution": 0.25},  # 64 spots
    "caribbean_pr_dr":          {"west": -71.0, "south": 12.0, "east": -61.0, "north": 20.0, "resolution": 0.25},  # 55 spots
    "srilanka_maldives":        {"west": 72.0,  "south": 2.0,  "east": 82.0,  "north": 10.0, "resolution": 0.25},  # 38 spots
    "centralamerica_caribbean": {"west": -84.0, "south": 3.0,  "east": -75.0, "north": 11.0, "resolution": 0.25},  # 29 spots
}


# ── F-08 STAGE B, BOX 1 (2026-09-29): the US Pacific Northwest + Northern California, BUILT DARK ────────────────
# MEASURED FIRST (same_model_parity_probe, 21:26Z, n=240 at 56 buoys): the 2-deg global_mid tier reads +0.097 m
# HIGH against the same model (38% of our whole squared gap to Open-Meteo's GFS-Wave), and its worst buoys are the
# ones no 0.25-deg box covers: 46244 Humboldt +0.50 m (ours 2.39 vs 1.90), 46211 Grays Harbor +0.12, 46243 Clatsop
# Spit +0.07, 46206 La Perouse +0.03. us_west_coast_socal stops at 38N, so NorCal, Oregon and Washington (23 active
# spots) are served from a 2-deg block whose energy mean pulls in offshore seas.
# COST, priced against F-08's gate: a GFS-only box is sliced from the same whole-globe download (~220 products);
# Render memory held 55-65% of 2 GB over 2026-09-27..29 (7-day chart), Stage A's four boxes cost ~55 MB.
# It abuts us_west_coast_socal at 38.0N (edge-touch is legal; interior overlap is test-banned).
# DARK: GFS_MARINE_STAGE_B (default "0"); flip in forecast-ingest-pilots.yml AND forecast-ingest.yml together.
GFS_MARINE_STAGE_B_REGIONS = {
    "us_pacific_northwest": {"west": -128.0, "south": 38.0, "east": -122.0, "north": 49.0, "resolution": 0.25},  # 23 spots
}


def stage_b_enabled() -> bool:
    return os.environ.get("GFS_MARINE_STAGE_B", "0") == "1"


def get_gfs_marine_pilot_regions() -> dict:
    """Regions for the GFS marine multi-bbox pass ONLY: everything get_all_pilot_regions() returns plus
    GFS_MARINE_EXTRA_REGIONS (F-08 Stage A). ICON/EURO marine and the wind pilots keep calling
    get_all_pilot_regions()/get_pilot_regions() and never see the extras. Same gates as the parent:
    WORLDWIDE_COASTAL=0 / test env -> flagship-only; GFS_MARINE_EXTRA_REGIONS=0 drops only the extras."""
    regions = get_all_pilot_regions()
    if len(regions) == len(REGIONAL_CONFIGS):      # flagship-only (test env or WORLDWIDE_COASTAL=0)
        return regions
    stage_b = GFS_MARINE_STAGE_B_REGIONS if stage_b_enabled() else {}
    if os.environ.get("GFS_MARINE_EXTRA_REGIONS", "1") == "0":
        return {**regions, **stage_b}
    return {**regions, **GFS_MARINE_EXTRA_REGIONS, **stage_b}


def get_all_pilot_regions() -> dict:
    """Flagship + ALL worldwide coastal regions — NO rotation (2026-07-13, multi-bbox arc): for the
    single-download-pass fetchers (GWAM/ECMWF wave stream), extra regions cost only in-memory
    sampling + product saves, not downloads, so EVERY region refreshes EVERY cycle instead of every
    ~4 cycles. The rotation (get_pilot_regions) remains for per-region-download lanes (GFS/NOAA
    byte-range, wind pilots). Same gates: WORLDWIDE_COASTAL=0 / test env -> flagship-only."""
    from services.weather_pipeline.copernicus_validator import is_test_environment
    if os.environ.get("WORLDWIDE_COASTAL", "1") == "0" or is_test_environment():
        return dict(REGIONAL_CONFIGS)
    return {**REGIONAL_CONFIGS, **WORLDWIDE_COASTAL_REGIONS}

