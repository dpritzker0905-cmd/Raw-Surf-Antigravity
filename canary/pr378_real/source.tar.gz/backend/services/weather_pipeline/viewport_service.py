import os
import asyncio
import logging
import math
import gc
import weakref
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any, List

from fastapi import HTTPException
from services.weather_pipeline.store import ProductStore
from services.weather_pipeline.dynamic_index import DynamicProductIndex
from services.weather_pipeline.normalizer import WeatherNormalizer
from services.weather_pipeline.providers.open_meteo_provider import OpenMeteoProvider
from services.weather_pipeline.schemas import NormalizedProduct
from services.weather_pipeline.route_helpers import (
    parse_bbox, clamp_and_normalize_bbox,
    choose_adaptive_resolution, build_dynamic_cache_key, filter_grid_to_bbox,
    is_bbox_covered_by, get_snapped_bbox
)
from services.weather_pipeline.viewport_helper import _is_oversized_grid, extend_icon_wind_to_14d
# Upstream fetch + normalize/persist blocks split to viewport_upstream.py (2026-07-10, LOC gate);
# the shared in-flight context (locks/shields/futures — db94a7c3) stays in this file.
from services.weather_pipeline.viewport_upstream import fetch_upstream_raw, normalize_and_persist_layers

logger = logging.getLogger(__name__)


# Wind gates split to wind_gates.py (2026-07-10, LOC gate); re-imported so import sites/tests are unchanged.
from services.weather_pipeline.wind_gates import (  # noqa: F401
    wind_global_parity_resolution, wind_horizon_fail_fast
)
# Native-upstream background recovery for failed wind dynamic-lane fetches (2026-07-19, queue #5).
from services.weather_pipeline.wind_native_recovery import maybe_spawn_native_wind_recovery
# Bounded wind background build (WIND_BG_BUILD_BOUNDED, default off): see wind_bg_build.py.
from services.weather_pipeline.wind_bg_build import keeps_task, wind_bg_bounded


class FetchContext:
    """
    Context for in-flight dynamic viewport requests to deduplicate and share
    raw fetched data and hour-specific processing results.
    """
    def __init__(self):
        self.raw_fetch_future = asyncio.Future()
        self.raw_list = None
        self.hour_futures: Dict[datetime, asyncio.Future] = {}

class ViewportService:
    """
    Service responsible for managing dynamic viewport bounding-box weather queries.
    Handles caching, concurrent request deduplication, coordinate generation,
    Open-Meteo fetching, and normalization.
    """

    IN_FLIGHT_REQUESTS: Dict[str, FetchContext] = {}
    IN_FLIGHT_LOCK = asyncio.Lock()

    ACTIVE_BG_TASKS: Dict[str, asyncio.Task] = {}
    # The context each slot's task is serving, weakly: the raw 16-day list must not outlive its task.
    ACTIVE_BG_CONTEXTS: Dict[str, "weakref.ref[FetchContext]"] = {}
    # Tasks a newer box replaced in the slot but did not cancel (WIND_BG_BUILD_BOUNDED: a request waits on them).
    # asyncio holds tasks weakly, so the set is what keeps them alive until they finish.
    KEPT_BG_TASKS: set = set()

    ACTIVE_REVALIDATIONS = set()

    NEGATIVE_CACHE: Dict[str, float] = {}

    async def _reap_shared_context(self, request_dedup_key: str, context: "FetchContext") -> None:
        """Drop a context whose shared future got CANCELLED (BaseException — the `except Exception`
        ladders never catch it; poisoned every later request = the 2026-07-10 naked-500 storm)."""
        async with self.IN_FLIGHT_LOCK:
            if self.IN_FLIGHT_REQUESTS.get(request_dedup_key) is context:
                self.IN_FLIGHT_REQUESTS.pop(request_dedup_key, None)
        logger.warning(f"[Dynamic Viewport] Reaped cancelled shared context for {request_dedup_key} (self-heal).")

    async def _register_hour_waiter(
        self, request_dedup_key: str, context: "FetchContext", target_dt: datetime
    ) -> Optional[asyncio.Future]:
        """The future a sharing waiter awaits for its hour, or None when `context` is no longer the
        live IN_FLIGHT_REQUESTS entry. Every retirement path (background-task finally, fetcher error
        branches, _reap_shared_context) pops the key, then fails only the futures that existed — so a
        future registered on a retired context is never resolved and its waiter (an SWR revalidation
        holding the reval semaphore and a queue slot) hangs forever: the 2026-10-08 "2-degree wind at
        every zoom". None sends the caller down its existing self-heal path instead."""
        async with self.IN_FLIGHT_LOCK:
            if self.IN_FLIGHT_REQUESTS.get(request_dedup_key) is not context:
                return None
            fut = context.hour_futures.get(target_dt)
            if fut is None:
                fut = asyncio.Future()
                context.hour_futures[target_dt] = fut
            return fut

    def __init__(
        self,
        store: Optional[ProductStore] = None,
        dynamic_index: Optional[DynamicProductIndex] = None,
        provider: Optional[OpenMeteoProvider] = None,
        normalizer: Optional[WeatherNormalizer] = None
    ):
        self._store = store
        self._dynamic_index = dynamic_index
        self.provider = provider or OpenMeteoProvider()
        self.normalizer = normalizer or WeatherNormalizer()

    @property
    def store(self) -> ProductStore:
        if self._store is not None:
            return self._store
        import routes.weather
        return routes.weather.store

    @property
    def dynamic_index(self) -> DynamicProductIndex:
        if self._dynamic_index is not None:
            return self._dynamic_index
        import routes.weather
        return routes.weather.dynamic_index

    def is_viewport_enabled(
        self,
        model: str,
        domain: str,
        layer: str,
        use_manifest_product: bool,
        bbox: Optional[str] = None,
        target_dt: Optional[datetime] = None
    ) -> bool:
        """
        Determines if dynamic viewport bounds fetching is enabled for the model/layer combination.
        """
        from services.weather_pipeline.viewport_helper import is_viewport_enabled_helper
        return is_viewport_enabled_helper(model, domain, layer, use_manifest_product, bbox, target_dt)

    async def get_cached_dynamic_product(
        self,
        model: str,
        domain: str,
        layer: str,
        target_dt: datetime,
        bbox_str: str,
        background_tasks=None,
    ) -> Optional[NormalizedProduct]:
        """`background_tasks`: the caller's, for a stale hit's refresh (see reval_queue.schedule_revalidation)."""
        from services.weather_pipeline.viewport_helper import get_cached_dynamic_product_helper
        return await get_cached_dynamic_product_helper(
            service=self,
            model=model,
            domain=domain,
            layer=layer,
            target_dt=target_dt,
            bbox_str=bbox_str,
            background_tasks=background_tasks,
        )

    async def fetch_viewport_grid_upstream(
        self,
        model: str,
        domain: str,
        layer: str,
        valid_time_str: str,
        target_dt: datetime,
        bbox_str: str
    ) -> NormalizedProduct:
        """
        Step 4 & 5: Fetches viewport grid from upstream Open-Meteo, handling negative caching,
        in-flight request deduplication, and conformed stale fallback if upstream fails.
        """
        req_w, req_s, req_e, req_n = parse_bbox(bbox_str)
        t_sz = 1.0 if model.upper() == "GFS" else 2.0
        west, south, east, north = clamp_and_normalize_bbox(
            math.floor(req_w / t_sz) * t_sz,
            math.floor(req_s / t_sz) * t_sz,
            math.ceil(req_e / t_sz) * t_sz,
            math.ceil(req_n / t_sz) * t_sz
        )
        span_lng = (east - west) if west <= east else ((180.0 - west) + (east + 180.0))
        span_lat = abs(north - south)

        is_global_view = (span_lng > 180.0 or span_lat > 90.0)
        if is_global_view:
            west, south, east, north = -180.0, -80.0, 180.0, 85.0
            span_lng = 360.0
            span_lat = 165.0
        coverage_scope = "global_coarse" if is_global_view else "viewport"

        target_pts = 200.0 if domain.lower() == "marine" else 400.0
        resolution = choose_adaptive_resolution(span_lng, span_lat, target_pts)
        resolution = wind_global_parity_resolution(resolution, is_global_view, domain)

        time_str = target_dt.strftime("%Y%m%dT%H%M%SZ")
        bbox_key_str = f"{west:.2f}_{south:.2f}_{east:.2f}_{north:.2f}"
        cache_key = build_dynamic_cache_key(model, domain, layer, target_dt, west, south, east, north)
        viewport_filename = f"{cache_key}.json"

        now_ts = datetime.now(timezone.utc).timestamp()
        if cache_key in self.NEGATIVE_CACHE:
            expire_ts = self.NEGATIVE_CACHE[cache_key]
            if now_ts < expire_ts:
                logger.warning(f"[Dynamic Viewport] Negative cache hit for {cache_key}. Attempting stale fallback before rejecting.")
                # Wind fine lane: the open-meteo failure that registered this negative-cache entry
                # blocks the WHOLE window — recover the bbox from the native upstream in the
                # background (dedup/cooldown inside makes repeat hits free).
                native_recovery_spawned = maybe_spawn_native_wind_recovery(
                    self, model=model, domain=domain, layer=layer, target_dt=target_dt,
                    west=west, south=south, east=east, north=north, resolution=resolution,
                    bbox_str=bbox_str, bbox_key_str=bbox_key_str, coverage_scope=coverage_scope,
                )
                fallback_product = await self._find_any_cached_product(model, domain, layer, target_dt, bbox_str)
                if fallback_product:
                    logger.info(f"[Dynamic Viewport] Fallback (Negative Cache Hit): Found previous cached product {fallback_product.product_id} for stale return")
                    fallback_product.cache_hit = "stale_cache_hit"
                    fallback_product.requested_bbox_original = bbox_str
                    fallback_product.query_bbox = f"{west:.4f},{south:.4f},{east:.4f},{north:.4f}"
                    fallback_product.requested_bbox = bbox_str
                    fallback_product.is_dynamic_viewport_product = True
                    fallback_product.stale = True
                    # R11-07 (2026-08-09): this path fires inside the failure COOLDOWN window; the
                    # original failure's class is not retained by the negative cache, so say THAT
                    # honestly instead of asserting rate limiting (which was often false).
                    fallback_product.staleReason = "upstream_cooldown"
                    fallback_product.fallbackReason = "upstream_cooldown"
                    fallback_product.partial_coverage = False

                    if domain.lower() != "wind":
                        fallback_product = filter_grid_to_bbox(fallback_product, get_snapped_bbox(bbox_str, model))
                    served_bbox = f"{fallback_product.grid.bounds.west:.4f},{fallback_product.grid.bounds.south:.4f},{fallback_product.grid.bounds.east:.4f},{fallback_product.grid.bounds.north:.4f}"
                    fallback_product.served_bbox = served_bbox

                    if fallback_product.grid:
                        fallback_product.grid.diagnostics = {
                            "requested_bbox": bbox_str,
                            "served_bbox": served_bbox,
                            "coverage_scope": fallback_product.coverage_scope or coverage_scope,
                            "source_product_ids": [fallback_product.product_id],
                            "cache_hit": "stale_cache_hit",
                            "provider": fallback_product.provider,
                            "model": model,
                            "domain": domain,
                            "layer": layer,
                            "valid_time": target_dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
                            "nonzeroCount": fallback_product.grid.diagnostics.get("nonzeroCount", 0) if fallback_product.grid.diagnostics else 0,
                            "vectorCount": len(fallback_product.grid.vectors) if fallback_product.grid.vectors else 0,
                            "vectors_length": len(fallback_product.grid.vectors) if fallback_product.grid.vectors else 0,
                            "gridMode": "rectangular",
                            "renderable": len(fallback_product.grid.vectors) > 0 and any(v.speed > 0 for v in fallback_product.grid.vectors),
                            "stale": True,
                            "staleReason": "upstream_cooldown",
                            "fallbackReason": "upstream_cooldown",
                            "partial_coverage": False,
                            "native_recovery": "spawned" if native_recovery_spawned else "none"
                        }
                    return fallback_product

                raise HTTPException(
                    status_code=503,
                    detail="Upstream weather API is temporarily unavailable (cached rate limit block)."
                )

        days_diff = (target_dt - datetime.now(timezone.utc)).days + 2
        forecast_days = max(2, min(16, days_diff))

        if domain.lower() == "wind":
            if model.upper() == "ICON":
                forecast_days = 5
            elif model.upper() == "EURO":
                forecast_days = 10
            else:
                forecast_days = 16
            # Fail fast (clean 404) on targets beyond what the fetch below can cover — see helper.
            wind_horizon_fail_fast(model, target_dt, forecast_days)
        else:
            if domain.lower() == "marine":
                if model.upper() == "ICON":
                    forecast_days = min(forecast_days, 7)
                elif model.upper() == "EURO":
                    forecast_days = min(forecast_days, 12)
                else:
                    forecast_days = min(forecast_days, 16)

        is_conjoined = model.upper() in ("GFS", "ICON") and layer.lower() in ("waves", "swell_1", "swell_2", "wind_waves")
        dedup_layer = "all_marine" if is_conjoined else layer
        request_dedup_key = f"{model.lower()}_{domain.lower()}_{dedup_layer.lower()}_{bbox_key_str}_{forecast_days}"
        context = None
        is_fetcher = False

        async with self.IN_FLIGHT_LOCK:
            if request_dedup_key in self.IN_FLIGHT_REQUESTS:
                context = self.IN_FLIGHT_REQUESTS[request_dedup_key]
                is_fetcher = False
            else:
                context = FetchContext()
                self.IN_FLIGHT_REQUESTS[request_dedup_key] = context
                is_fetcher = True

        if not is_fetcher:
            logger.info(f"[Dynamic Viewport] Sharing in-flight request for {request_dedup_key}")
            try:
                # shield(): a cancelled WAITER must not cancel the SHARED future (see _reap_shared_context)
                await asyncio.shield(context.raw_fetch_future)

                my_cache_key = build_dynamic_cache_key(model, domain, layer, target_dt, west, south, east, north)
                my_viewport_filename = f"{my_cache_key}.json"

                loaded_product = await asyncio.to_thread(self.store.load_product, my_viewport_filename)
                if not loaded_product:
                    # None = the context retired before we registered: nobody would resolve a new
                    # future, so re-check disk and fall through to the self-heal fetch below.
                    hour_fut = await self._register_hour_waiter(request_dedup_key, context, target_dt)
                    if hour_fut is not None:
                        await asyncio.shield(hour_fut)
                    loaded_product = await asyncio.to_thread(self.store.load_product, my_viewport_filename)

                if loaded_product and _is_oversized_grid(loaded_product):
                    logger.warning(
                        f"[Dynamic Viewport] Waiter loaded cached product {my_viewport_filename} "
                        f"but it was oversized ({len(loaded_product.grid.vectors)} vectors). Treating as cache miss to self-heal."
                    )
                    loaded_product = None

                if loaded_product:
                    loaded_product.cache_hit = "cache_hit"  # Shared from fetcher
                    loaded_product.requested_bbox_original = bbox_str
                    loaded_product.query_bbox = f"{west:.4f},{south:.4f},{east:.4f},{north:.4f}"
                    loaded_product.partial_coverage = False
                    loaded_product.stale = False
                    if domain.lower() != "wind":
                        loaded_product = filter_grid_to_bbox(loaded_product, get_snapped_bbox(bbox_str, model))
                    if loaded_product.grid and loaded_product.grid.bounds:
                        loaded_product.served_bbox = f"{loaded_product.grid.bounds.west:.4f},{loaded_product.grid.bounds.south:.4f},{loaded_product.grid.bounds.east:.4f},{loaded_product.grid.bounds.north:.4f}"
                    return loaded_product
                else:
                    logger.warning(f"[Dynamic Viewport] Waiter awoke but target product was not in cache: {my_viewport_filename}. Proceeding to self-heal and fetch.")
            except asyncio.CancelledError:
                task = asyncio.current_task()
                if task is not None and task.cancelling() > 0:
                    raise  # OUR request was cancelled (client gone) — propagate normally
                await self._reap_shared_context(request_dedup_key, context)  # shared state dead → self-heal below
            except Exception as e:
                logger.warning(f"[Dynamic Viewport] Shared in-flight fetch failed or raised exception: {e}. Proceeding to self-heal and fetch.")

            async with self.IN_FLIGHT_LOCK:
                if request_dedup_key in self.IN_FLIGHT_REQUESTS:
                    context = self.IN_FLIGHT_REQUESTS[request_dedup_key]
                    is_fetcher = False
                else:
                    context = FetchContext()
                    self.IN_FLIGHT_REQUESTS[request_dedup_key] = context
                    is_fetcher = True

            if not is_fetcher:
                logger.info(f"[Dynamic Viewport] Waiter sharing newly spawned self-heal fetcher for {request_dedup_key}")
                try:
                    await asyncio.shield(context.raw_fetch_future)
                    my_cache_key = build_dynamic_cache_key(model, domain, layer, target_dt, west, south, east, north)
                    my_viewport_filename = f"{my_cache_key}.json"

                    loaded_product = await asyncio.to_thread(self.store.load_product, my_viewport_filename)
                    if not loaded_product:
                        hour_fut = await self._register_hour_waiter(request_dedup_key, context, target_dt)
                        if hour_fut is not None:   # None = retired context (see the helper)
                            await asyncio.shield(hour_fut)
                        loaded_product = await asyncio.to_thread(self.store.load_product, my_viewport_filename)

                    if loaded_product and _is_oversized_grid(loaded_product):
                        logger.warning(
                            f"[Dynamic Viewport] Waiter self-heal loaded cached product {my_viewport_filename} "
                            f"but it was oversized ({len(loaded_product.grid.vectors)} vectors). Treating as cache miss."
                        )
                        loaded_product = None

                    if loaded_product:
                        loaded_product.cache_hit = "cache_hit"
                        loaded_product.requested_bbox_original = bbox_str
                        loaded_product.query_bbox = f"{west:.4f},{south:.4f},{east:.4f},{north:.4f}"
                        loaded_product.partial_coverage = False
                        loaded_product.stale = False
                        if domain.lower() != "wind":
                            loaded_product = filter_grid_to_bbox(loaded_product, get_snapped_bbox(bbox_str, model))
                        if loaded_product.grid and loaded_product.grid.bounds:
                            loaded_product.served_bbox = f"{loaded_product.grid.bounds.west:.4f},{loaded_product.grid.bounds.south:.4f},{loaded_product.grid.bounds.east:.4f},{loaded_product.grid.bounds.north:.4f}"
                        return loaded_product
                except asyncio.CancelledError:
                    task = asyncio.current_task()
                    if task is not None and task.cancelling() > 0:
                        raise
                    await self._reap_shared_context(request_dedup_key, context)
                except Exception as inner_e:
                    logger.error(f"[Dynamic Viewport] Waiter self-heal retry failed: {inner_e}")

                fallback_product = await self._find_any_cached_product(model, domain, layer, target_dt, bbox_str)
                if fallback_product:
                    logger.info(f"[Dynamic Viewport] Fallback (Self-Heal Waiter Failure): Found cached product {fallback_product.product_id}")
                    fallback_product.cache_hit = "stale_cache_hit"
                    fallback_product.requested_bbox_original = bbox_str
                    fallback_product.query_bbox = f"{west:.4f},{south:.4f},{east:.4f},{north:.4f}"
                    fallback_product.requested_bbox = bbox_str
                    fallback_product.is_dynamic_viewport_product = True
                    fallback_product.stale = True
                    fallback_product.staleReason = "upstream_request_failed"
                    fallback_product.partial_coverage = False
                    if domain.lower() != "wind":
                        fallback_product = filter_grid_to_bbox(fallback_product, get_snapped_bbox(bbox_str, model))
                    if fallback_product.grid and fallback_product.grid.bounds:
                        fallback_product.served_bbox = f"{fallback_product.grid.bounds.west:.4f},{fallback_product.grid.bounds.south:.4f},{fallback_product.grid.bounds.east:.4f},{fallback_product.grid.bounds.north:.4f}"
                    return fallback_product

                raise HTTPException(status_code=504, detail="Upstream weather request failed (shared self-heal).")

        try:
            raw_data, resolution, coord_count, bbox_dict = await fetch_upstream_raw(
                service=self, model=model, domain=domain, layer=layer,
                valid_time_str=valid_time_str,
                west=west, south=south, east=east, north=north,
                resolution=resolution, is_global_view=is_global_view,
                forecast_days=forecast_days
            )

            if not raw_data:
                logger.error(f"[Dynamic Viewport] Upstream fetch returned empty data.")
                raise Exception("Upstream fetch returned empty data.")

            raw_list = raw_data if isinstance(raw_data, list) else [raw_data]

            if model.upper() == "ICON" and domain.lower() == "wind":
                logger.info("[Dynamic Viewport] Dynamically extending ICON wind raw results to 14 days (336 hours) via loop extrapolation.")
                extend_icon_wind_to_14d(raw_list)

            first_point = raw_list[0]
            hourly = first_point.get("hourly", {})
            times = hourly.get("time", [])

            if not times:
                logger.error(f"[Dynamic Viewport] Upstream fetch returned no time array.")
                raise Exception("Upstream fetch returned no time array.")

            target_idx = WeatherNormalizer.find_closest_time_index(times, target_dt)
            if target_idx is None:
                logger.error(f"[Dynamic Viewport] target_dt {target_dt} is not covered by the fetched times.")
                raise Exception(f"target_dt {target_dt} is not covered by the fetched times.")

            context.raw_list = raw_list
            async with self.IN_FLIGHT_LOCK:
                if not context.raw_fetch_future.done():
                    context.raw_fetch_future.set_result(True)

            target_t_str = times[target_idx]
            target_t_str_with_z = target_t_str if target_t_str.endswith("Z") else target_t_str + "Z"
            target_dt_actual = datetime.fromisoformat(target_t_str_with_z.replace("Z", "+00:00"))

            target_normalized_product = await normalize_and_persist_layers(
                service=self, model=model, domain=domain, layer=layer,
                raw_list=raw_list, bbox_dict=bbox_dict, resolution=resolution,
                target_dt_actual=target_dt_actual, target_idx=target_idx,
                west=west, south=south, east=east, north=north,
                bbox_str=bbox_str, bbox_key_str=bbox_key_str,
                coverage_scope=coverage_scope, coord_count=coord_count
            )

            async with self.IN_FLIGHT_LOCK:
                for d in (target_dt, target_dt_actual):
                    fut = context.hour_futures.get(d)
                    if fut and not fut.done():
                        fut.set_result(True)

            bg_key = f"{model.lower()}_{domain.lower()}"
            old_task = self.ACTIVE_BG_TASKS.get(bg_key)
            if old_task and not old_task.done():
                if wind_bg_bounded(domain) and keeps_task(self.ACTIVE_BG_TASKS, self.ACTIVE_BG_CONTEXTS, bg_key):
                    # Cancelling it fails the hour a request is still waiting on, and that request then
                    # refetches the old box and cancels THIS box's task in turn.
                    logger.info(f"[Dynamic Viewport] Keeping background task for {bg_key}: a request is waiting on it")
                    self.KEPT_BG_TASKS.add(old_task)
                    old_task.add_done_callback(self.KEPT_BG_TASKS.discard)
                else:
                    logger.info(f"[Dynamic Viewport] Canceling stale background task for {bg_key}")
                    old_task.cancel()

            from services.weather_pipeline.viewport_helper import bg_process_remaining_hours_helper
            task = asyncio.create_task(bg_process_remaining_hours_helper(
                service=self,
                context=context,
                request_dedup_key=request_dedup_key,
                model=model,
                domain=domain,
                layer=layer,
                bbox_dict=bbox_dict,
                resolution=resolution,
                west=west,
                south=south,
                east=east,
                north=north,
                times=times,
                target_idx=target_idx,
                bbox_str=bbox_str,
                coverage_scope=coverage_scope,
                coord_count=coord_count,
                bbox_key_str=bbox_key_str
            ))
            self.ACTIVE_BG_TASKS[bg_key] = task
            self.ACTIVE_BG_CONTEXTS[bg_key] = weakref.ref(context)

            # A full collection walks the whole serve heap (0.42 s measured) and this one runs BEFORE the fetcher
            # returns its hour: the bounded build leaves the full pass to the task's own `finally`.
            if wind_bg_bounded(domain):
                gc.collect(1)
            else:
                gc.collect()
            if target_normalized_product and _is_oversized_grid(target_normalized_product):
                raise ValueError(
                    f"Freshly normalized product {target_normalized_product.product_id} is oversized: "
                    f"{len(target_normalized_product.grid.vectors)} vectors"
                )

            if target_normalized_product.coverage_scope == "global_coarse" or domain.lower() == "wind":
                return target_normalized_product
            cropped_product = filter_grid_to_bbox(target_normalized_product, get_snapped_bbox(bbox_str, model))
            if cropped_product.grid and cropped_product.grid.bounds:
                cropped_product.served_bbox = f"{cropped_product.grid.bounds.west:.4f},{cropped_product.grid.bounds.south:.4f},{cropped_product.grid.bounds.east:.4f},{cropped_product.grid.bounds.north:.4f}"
            return cropped_product

        except asyncio.CancelledError:
            # FETCHER cancelled: CancelledError is a BaseException — the Exception cleanup below never
            # ran, stranding the context (2026-07-10 500s). Resolve shared futures with a NORMAL
            # exception (waiters self-heal), drop the context, propagate our cancellation.
            async with self.IN_FLIGHT_LOCK:
                ctx = self.IN_FLIGHT_REQUESTS.pop(request_dedup_key, None)
            if ctx is not None:
                cancel_exc = HTTPException(status_code=504, detail="upstream_fetch_cancelled")
                for fut in [ctx.raw_fetch_future, *ctx.hour_futures.values()]:
                    if not fut.done():
                        fut.set_exception(cancel_exc)
                        try:
                            fut.exception()
                        except Exception:
                            pass
            raise
        except Exception as e:
            async with self.IN_FLIGHT_LOCK:
                ctx = self.IN_FLIGHT_REQUESTS.pop(request_dedup_key, None)
            if ctx is not None:
                for fut in [ctx.raw_fetch_future, *ctx.hour_futures.values()]:
                    if not fut.done():
                        fut.set_exception(e)
                        try:
                            fut.exception()
                        except Exception:
                            pass

            logger.warning(f"[Dynamic Viewport] Upstream fetch failed for {model} {layer}: {e}")

            err_cls, err_str = e.__class__.__name__.lower(), str(e).lower()
            is_cancelled = isinstance(e, asyncio.CancelledError) or any(x in err_cls or x in err_str for x in ("cancel", "abort", "disconnect"))
            native_recovery_spawned = False
            is_429 = any(x in err_str for x in ("429", "rate limit", "too many requests"))
            # R11-07 (2026-08-09): staleReason used to hardcode "upstream_rate_limited" for EVERY
            # failure class, so timeouts, 5xx and decode errors all read as rate limiting in the
            # client diagnostics — chronic incident misattribution. Classify once, serve the truth.
            if is_429:
                stale_reason = "upstream_rate_limited"
            elif "timeout" in err_cls or "timed out" in err_str or "timeout" in err_str:
                stale_reason = "upstream_timeout"
            elif any(x in err_str for x in ("500", "502", "503", "504", "bad gateway", "unavailable")):
                stale_reason = "upstream_error"
            else:
                stale_reason = f"upstream_failed:{e.__class__.__name__}"
            if not is_cancelled:
                neg_ttl = 120 if is_429 else 60
                self.NEGATIVE_CACHE[cache_key] = datetime.now(timezone.utc).timestamp() + neg_ttl
                logger.info(f"[Dynamic Viewport] Registered negative cache key for {neg_ttl}s: {cache_key}")
                # Wind fine lane: recover this bbox from the native upstream in the background
                # while the request degrades to the instant stale/coarse fallback below.
                native_recovery_spawned = maybe_spawn_native_wind_recovery(
                    self, model=model, domain=domain, layer=layer, target_dt=target_dt,
                    west=west, south=south, east=east, north=north, resolution=resolution,
                    bbox_str=bbox_str, bbox_key_str=bbox_key_str, coverage_scope=coverage_scope,
                )
            else:
                logger.info(f"[Dynamic Viewport] Request cancelled or aborted ({e}). Skipping negative cache registration.")

            fallback_product = await self._find_any_cached_product(model, domain, layer, target_dt, bbox_str)
            if fallback_product:
                logger.info(f"[Dynamic Viewport] Fallback: Found previous cached product {fallback_product.product_id} for stale return")
                fallback_product.cache_hit = "stale_cache_hit"
                fallback_product.requested_bbox_original = bbox_str
                fallback_product.query_bbox = f"{west:.4f},{south:.4f},{east:.4f},{north:.4f}"
                fallback_product.requested_bbox = bbox_str
                fallback_product.is_dynamic_viewport_product = True
                fallback_product.stale = True
                fallback_product.staleReason = stale_reason
                fallback_product.fallbackReason = stale_reason
                fallback_product.partial_coverage = False

                if domain.lower() != "wind":
                    fallback_product = filter_grid_to_bbox(fallback_product, get_snapped_bbox(bbox_str, model))
                served_bbox = f"{fallback_product.grid.bounds.west:.4f},{fallback_product.grid.bounds.south:.4f},{fallback_product.grid.bounds.east:.4f},{fallback_product.grid.bounds.north:.4f}"
                fallback_product.served_bbox = served_bbox

                if fallback_product.grid:
                    fallback_product.grid.diagnostics = {
                        "requested_bbox": bbox_str,
                        "served_bbox": served_bbox,
                        "coverage_scope": fallback_product.coverage_scope or coverage_scope,
                        "source_product_ids": [fallback_product.product_id],
                        "cache_hit": "stale_cache_hit",
                        "provider": fallback_product.provider,  # Keep real provider name
                        "model": model,
                        "domain": domain,
                        "layer": layer,
                        "valid_time": target_dt.strftime("%Y-%m-%dT%H:%M:%SZ"),
                        "nonzeroCount": fallback_product.grid.diagnostics.get("nonzeroCount", 0) if fallback_product.grid.diagnostics else 0,
                        "vectorCount": len(fallback_product.grid.vectors) if fallback_product.grid.vectors else 0,
                        "vectors_length": len(fallback_product.grid.vectors) if fallback_product.grid.vectors else 0,
                        "gridMode": "rectangular",
                        "renderable": len(fallback_product.grid.vectors) > 0 and any(v.speed > 0 for v in fallback_product.grid.vectors),
                        "stale": True,
                        "staleReason": stale_reason,
                        "fallbackReason": stale_reason,
                        "partial_coverage": False,
                        "native_recovery": "spawned" if native_recovery_spawned else "none"
                    }
                return fallback_product

            if isinstance(e, HTTPException):
                raise e
            raise HTTPException(status_code=504, detail=f"Viewport fetch failed: {str(e)}")

    async def fetch_viewport_grid(
        self,
        model: str,
        domain: str,
        layer: str,
        valid_time_str: str,
        target_dt: datetime,
        bbox_str: str,
        force_refresh: bool = False
    ) -> NormalizedProduct:
        if not force_refresh:
            cached = await self.get_cached_dynamic_product(model, domain, layer, target_dt, bbox_str)
            if cached:
                return cached
        return await self.fetch_viewport_grid_upstream(model, domain, layer, valid_time_str, target_dt, bbox_str)

    async def _revalidate_fetch(
        self,
        model: str,
        domain: str,
        layer: str,
        valid_time_str: str,
        target_dt: datetime,
        bbox_str: str,
        reval_key: str
    ):
        """Asynchronously refetches a viewport grid and updates cache without throwing errors to response.

        SERIALIZED (2026-07-05, the 18:40Z Render OOM while panning with the mid-tier SWR live): the
        per-key ACTIVE_REVALIDATIONS dedup does NOT bound CONCURRENCY across keys — a pan/scrub spawns
        several revalidations (different hours/layers/bboxes), each a full upstream fetch + normalize,
        and the 512MB 1-CPU serve box OOMs. A class-level semaphore (MARINE_REVAL_CONCURRENCY, default
        1) serializes them: the serve path stays instant (previews), sharpening queues instead of
        stampeding."""
        if not hasattr(type(self), "_REVAL_SEMAPHORE"):
            type(self)._REVAL_SEMAPHORE = asyncio.Semaphore(
                max(1, int(os.environ.get("MARINE_REVAL_CONCURRENCY", "1")))
            )
        # BOUNDED (2026-10-08): a revalidation that never returns held the semaphore and its queue
        # slot forever, so the mid tier stopped scheduling sharpens on that instance (the orphaned
        # hour-waiter — see _register_hour_waiter). The bound covers the fetch, not the queue wait.
        reval_timeout_s = float(os.environ.get("VIEWPORT_REVAL_TIMEOUT_S", "90"))
        try:
            async with type(self)._REVAL_SEMAPHORE:
                await asyncio.wait_for(
                    self.fetch_viewport_grid(
                        model=model, domain=domain, layer=layer,
                        valid_time_str=valid_time_str, target_dt=target_dt,
                        bbox_str=bbox_str, force_refresh=True
                    ),
                    timeout=reval_timeout_s,
                )
            logger.info(f"[Dynamic Viewport] SWR background revalidation succeeded for {reval_key}")
        except Exception as e:
            logger.warning(f"[Dynamic Viewport] SWR background revalidation failed for {reval_key}: {e}")
        finally:
            self.ACTIVE_REVALIDATIONS.discard(reval_key)

    async def _find_any_cached_product(
        self,
        model: str,
        domain: str,
        layer: str,
        target_dt: datetime,
        bbox_str: Optional[str] = None,
        require_coverage: bool = False
    ) -> Optional[NormalizedProduct]:
        """Searches dynamic index and manifest for any product matching model/layer and target time, choosing the closest.

        ``require_coverage`` forwards to find_any_cached_product_helper — set True only for the Step 3.7
        instant-preview so a non-wide viewport gets a COVERING tile (kills the zoom-out clamp); the
        rate-limit / self-heal callers leave it False to keep serving any overlapping stale tile."""
        from services.weather_pipeline.viewport_helper import find_any_cached_product_helper
        return await find_any_cached_product_helper(
            model=model,
            domain=domain,
            layer=layer,
            target_dt=target_dt,
            dynamic_index=self.dynamic_index,
            store=self.store,
            bbox_str=bbox_str,
            require_coverage=require_coverage
        )
