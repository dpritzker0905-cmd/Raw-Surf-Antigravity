import os
import asyncio
import logging
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Any, Optional
from services.weather_pipeline.store import ProductStore
from services.weather_pipeline.providers.open_meteo_provider import OpenMeteoProvider
from services.weather_pipeline.providers.copernicus_provider import CopernicusProvider
from services.weather_pipeline.normalizer import WeatherNormalizer
from services.weather_pipeline.scheduler_helpers import (
    get_env_flags,
    generate_mock_marine_results,
    generate_mock_icon_marine_results,
    generate_mock_wind_results,
    generate_mock_pressure_results,
    generate_mock_copernicus_results,
    normalize_and_save_loop,
    REGIONAL_CONFIGS,
    get_pilot_regions,
    find_nearest_manifest_product,
)

logger = logging.getLogger(__name__)


class WeatherPipelineScheduler:
    """
    Orchestrates the background scheduled updates for the backend weather products.
    Enforces configurable regions and standard refresh cadences.
    """

    def __init__(self, store: Optional[ProductStore] = None):
        self.store = store or ProductStore()
        self.om_provider = OpenMeteoProvider()
        self.cop_provider = CopernicusProvider()
        self.normalizer = WeatherNormalizer()
        # Cross-job handoff (2026-07-22): ingest_gfs_marine_global stashes its NOAA-direct GFS coarse grid here
        # so ingest_euro_marine_global reuses it for the enclosed-sea/Antarctic GFS-fill without a 429-prone
        # open-meteo re-fetch (that re-fetch stranded the fill in run 29922098897).
        self._gfs_coarse_marine_cache = None

    def _get_resolution(self, region: dict, is_render: bool) -> float:
        return region["resolution"]

    async def _fetch_or_mock(self, model: str, domain: str, layer: str,
                             region: dict, resolution: float, forecast_days: int,
                             is_test_env: bool, mock_fn, region_id: str = "",
                             batch_size: Optional[int] = None) -> Optional[list]:
        """Fetch grid from provider, falling back to mock data in test environments."""
        try:
            raw_data = await self.om_provider.fetch_grid(
                model=model, domain=domain, layer=layer,
                bbox=region, resolution=resolution, forecast_days=forecast_days,
                batch_size=batch_size
            )
        except Exception as e:
            logger.error(f"[Pipeline Scheduler] Exception during fetch: {e}")
            raw_data = None

        if raw_data:
            return raw_data if isinstance(raw_data, list) else [raw_data]

        if is_test_env:
            logger.warning(f"[Pipeline Scheduler] {model} {domain}/{layer} fetch failed for {region_id or 'default'}. Injecting mock data...")
            return mock_fn()

        logger.error(f"[Pipeline Scheduler] {model} {domain}/{layer} fetch failed for {region_id or 'default'}. Skipping.")
        return None

    async def _cleanup_and_pause(self, results, pause: float = 1.0):
        """Delete results and pause between region iterations."""
        import gc
        del results
        gc.collect()
        await asyncio.sleep(pause)

    async def ingest_gfs_marine_pilot(self) -> bool:
        """
        Stage 2 / 6H.2 Pilot: Ingests GFS waves grid forecast for all configured regions.
        Fetches 48 hours of forecasts in 3-hour increments for waves, swell_1, swell_2, and wind_waves.
        """
        logger.info("[Pipeline Scheduler] Starting GFS Marine Ingestion job for all regions...")
        env = get_env_flags()
        run_time = datetime.now(timezone.utc)
        total_saved = 0

        # The regional pilot was the LAST GFS-marine path still on open-meteo. On the decoupled GitHub
        # runner open-meteo is unreachable/rate-limited, so every region's all_marine fetch failed and the
        # manifest shipped ZERO regional (0.25°) products — the coastal-resolution regression (Cape Canaveral
        # read the 10° global-coarse: 2.7ft vs the truer 1.9ft). Mirror ingest_gfs_marine_global's NOAA-direct
        # PRIMARY here: the same fetch_gfs_marine_global_coarse is bbox+resolution-parameterized, so a regional
        # 0.25° western-hemisphere fetch is just a smaller bbox (lon wrap handled in noaa_gfs_wave_fetcher).
        # Provider stays 'open-meteo' (manifest byte-identical, source_dataset='ncep_gfswave025'); open-meteo
        # remains the fallback. Kill switch: GFS_MARINE_NOAA_DIRECT=0.
        noaa_direct = os.environ.get("GFS_MARINE_NOAA_DIRECT", "1") != "0"

        from services.weather_pipeline.scheduler_helpers import (
            flagship_pilot_days, get_gfs_marine_pilot_regions)
        from services.weather_pipeline.marine_mid_res_ingestion import (
            _GLOBAL_REGION, _save_marine_regional, gfs_mid_folds_into_pilot,
            gfs_mid_forecast_days, gfs_mid_resolution, save_gfs_marine_global_mid)

        def _layers_for(region_id: str) -> list:
            # Swell 2 is not requested for SoCal
            return ["waves", "swell_1", "wind_waves"] if region_id == "us_west_coast_socal" \
                else ["waves", "swell_1", "swell_2", "wind_waves"]

        # ══ MULTI-BBOX single-download-pass: ALL regions for ONE region's download cost ══
        # THE ROTATION WAS RATIONING REDUNDANCY. NOAA's byte-range selects a GRIB *message*, not a
        # region, and a message is the whole global 0.25° field, so the bbox never touches the wire —
        # measured 2026-07-31 on the 12Z cycle, byte-identical payloads for a 609-point and a
        # 2,009-point box. Rationing that duplication by rotation left uk_ireland and east_australia
        # on an 18.7-day-old run, and the SERVE path then degraded silently: uk_ireland fell through
        # to the 2° global_mid tile, east_australia had no tile at all and answered
        # `source: backend_direct_point` — a LIVE per-request upstream fetch on a box with three melt
        # incidents. A missing tile does not merely coarsen; it moves cost onto the request path.
        # Grouped BY HORIZON so the flagship-first contract (flagship 14d, worldwide short) survives
        # exactly: one pass per distinct horizon, not one pass per region.
        # Kill switch: MARINE_PILOT_MULTI_BBOX=0 -> the per-region rotation path below.
        if noaa_direct and os.environ.get("MARINE_PILOT_MULTI_BBOX", "1") != "0":
            # + GFS_MARINE_EXTRA_REGIONS (F-08 Stage A): GFS-only boxes, free in this pass because the
            # download is the whole globe either way. The per-region rotation fallback below does NOT
            # carry them -- it downloads per region, which is exactly the cost the extras must not add.
            regions_all = get_gfs_marine_pilot_regions()
            by_horizon = {}
            for rid, rcfg in regions_all.items():
                days = flagship_pilot_days(
                    rid,
                    int(os.environ.get("GFS_MARINE_FLAGSHIP_FORECAST_DAYS", "14")),
                    int(os.environ.get("GFS_MARINE_FORECAST_DAYS", "8")),
                )
                by_horizon.setdefault(days, {})[rid] = rcfg

            # ══ FOLD THE 2° global_mid TILE INTO THIS SAME PASS (2026-08-02) ══
            # global_mid used to run as its own job and download the IDENTICAL f000-f336 set that
            # this pass already pulls — measured in run 30748383857: the mid job 12:43-13:13 and the
            # flagship 14d pass 14:05-14:31 fetched the same ~790 MB, 26 min apart, in one run. The
            # bbox never touches the wire (a byte-range selects a whole-globe GRIB *message*), so the
            # ONLY thing that kept them apart was one resolution per pass — now lifted.
            # ★ It joins BY HORIZON, not unconditionally: `by_horizon` already groups a pass per
            # distinct forecast length, so global_mid rides the flagship group only while both are
            # 14 d. Let those horizons diverge and it forms its OWN group — same cost as before, and
            # the mid tile's horizon is never silently changed to the flagship's.
            fold_mid = gfs_mid_folds_into_pilot()
            mid_res = gfs_mid_resolution()
            mid_days = gfs_mid_forecast_days(env["is_test_env"])
            if fold_mid:
                by_horizon.setdefault(mid_days, {})["global_mid"] = dict(_GLOBAL_REGION)

            mid_saved = 0
            multi_saved = 0
            for days, group in sorted(by_horizon.items()):
                # ONLY global_mid departs from this pass's 0.25° default. Every other region is left
                # off the map so it keeps the scalar — their payloads, and their tiles, stay
                # byte-identical to before the fold.
                res_map = {"global_mid": mid_res} if "global_mid" in group else None
                multi = None
                try:
                    from services.noaa_marine_service import fetch_gfs_marine_regions
                    multi = await fetch_gfs_marine_regions(group, 0.25, days, resolutions=res_map)
                except Exception as _me:
                    logger.error(f"[Pipeline Scheduler] GFS-Wave multi-region fetch errored "
                                 f"({days}d, {len(group)} regions): {_me}")
                if not multi:
                    logger.warning(f"[Pipeline Scheduler] GFS-Wave multi-region unavailable for the "
                                   f"{days}d horizon ({len(group)} regions).")
                    continue
                logger.info(f"[Pipeline Scheduler] GFS-Wave multi-region OK: {len(multi)} regions "
                            f"in one {days}d pass.")
                for region_id, results in multi.items():
                    region = group.get(region_id)
                    if not region or not results:
                        continue
                    # NOAA GFS-Wave is natively 3-hourly -> step=1 keeps every step.
                    if region_id == "global_mid":
                        # global_tile coverage, 4 layers, prune + grid size climatology — the SAME
                        # save the standalone job runs, not a regional_tile lookalike.
                        mid_saved += await save_gfs_marine_global_mid(
                            self, env, run_time, results, mid_res, 1)
                    else:
                        multi_saved += await _save_marine_regional(
                            self, env, run_time, "GFS", _layers_for(region_id),
                            region_id, region, results, 1, "GFS")
                    await self._cleanup_and_pause(results, 0)

            # ⛔ THE FOLD MAY ONLY SAVE TIME — IT MAY NEVER LOSE THE TILE. The shared pass can come
            # back empty (upstream hiccup, a cycle still publishing, the soft deadline refusing a
            # stub), and unlike the old arrangement there is no separate job left to cover for it.
            # So fall back to the standalone impl, which brings its own fetch AND its open-meteo
            # fallback. Worst case that is exactly today's two downloads; best case it never runs.
            if fold_mid and mid_saved == 0:
                logger.warning("[Pipeline Scheduler] global_mid produced nothing from the shared "
                               "pass; running the standalone mid job as a fallback.")
                from services.weather_pipeline.marine_mid_res_ingestion import (
                    ingest_gfs_marine_global_mid_impl)
                try:
                    await ingest_gfs_marine_global_mid_impl(self)
                except Exception as _fe:
                    logger.error(f"[Pipeline Scheduler] standalone global_mid fallback failed: {_fe}")
            # `mid_saved` is deliberately NOT folded into `multi_saved`: a healthy mid tile must not
            # mask a REGIONAL failure and skip the per-region rotation fallback below.
            if multi_saved > 0:
                logger.info(f"[Pipeline Scheduler] GFS Marine Pilot (multi) done! "
                            f"Saved {multi_saved} products.")
                return True
            logger.warning("[Pipeline Scheduler] GFS-Wave multi-region yielded nothing; "
                           "falling back to the per-region rotation path.")

        # ══ FALLBACK: per-region (rotation-selected — starvation-prone, see above) ══
        for region_id, region in get_pilot_regions(self.store, "GFS", "marine").items():
            resolution = self._get_resolution(region, env["is_render"])
            logger.info(f"[Pipeline Scheduler] Ingesting GFS Marine for region: {region_id}")

            # FLAGSHIP-FIRST HORIZON (2026-07-15, the 14-day state-of-the-art fine-pilot arc): the
            # ever-present flagship coasts (FL/SoCal) carry the full native GFS-Wave horizon (14d;
            # NOAA gfswave025 ceiling is 16d), while the rotating WORLDWIDE regions stay at the shorter
            # budget horizon so the ~165-min CI stays green. Envs: GFS_MARINE_FLAGSHIP_FORECAST_DAYS
            # (default 14) / GFS_MARINE_FORECAST_DAYS (default 8, the worldwide horizon).
            from services.weather_pipeline.scheduler_helpers import flagship_pilot_days
            env_forecast_days = flagship_pilot_days(
                region_id,
                int(os.environ.get("GFS_MARINE_FLAGSHIP_FORECAST_DAYS", "14")),
                int(os.environ.get("GFS_MARINE_FORECAST_DAYS", "8")),
            )

            # ══ PRIMARY: native GFS-Wave direct from NOAA (regional 0.25°, off open-meteo) ══
            results = None
            from_noaa = False
            if noaa_direct:
                try:
                    from services.noaa_marine_service import fetch_gfs_marine_global_coarse
                    results = await fetch_gfs_marine_global_coarse(region, resolution, env_forecast_days)
                    if results:
                        from_noaa = True
                        logger.info(f"[Pipeline Scheduler] GFS-Wave NOAA-direct OK for {region_id}: "
                                    f"{len(results)} points (off open-meteo).")
                except Exception as _ne:
                    logger.error(f"[Pipeline Scheduler] GFS-Wave NOAA-direct fetch errored for {region_id}: {_ne}")

            if not results:
                if noaa_direct:
                    logger.warning(f"[Pipeline Scheduler] GFS-Wave NOAA-direct unavailable for {region_id}; "
                                   "falling back to open-meteo.")
                results = await self._fetch_or_mock(
                    "GFS", "marine", "all_marine", region, resolution, env_forecast_days,
                    env["is_test_env"],
                    lambda r=region, res=resolution: generate_mock_marine_results(self.om_provider, r, res),
                    region_id
                )
            if not results:
                continue

            # NOAA GFS-Wave is natively 3-hourly (step=1 keeps every step); open-meteo all_marine is hourly
            # (step=3 -> 3-hourly products). Same 3-hourly product cadence either way.
            total_saved += await _save_marine_regional(
                self, env, run_time, "GFS", _layers_for(region_id),
                region_id, region, results, 1 if from_noaa else 3, "GFS")
            await self._cleanup_and_pause(results)

        logger.info(f"[Pipeline Scheduler] GFS Marine Ingestion Job done! Saved {total_saved} total conformed product files.")
        return total_saved > 0

    async def ingest_gfs_wind_pilot(self) -> bool:
        """Stage 3A/6H.1: Ingests GFS wind grid forecast for all configured regions."""
        from services.weather_pipeline.wind_ingestion import ingest_gfs_wind_pilot_impl
        return await ingest_gfs_wind_pilot_impl(self)

    async def ingest_gfs_wind_global(self) -> bool:
        """Ingests GFS wind grid forecast globally at a coarse resolution."""
        from services.weather_pipeline.wind_ingestion import ingest_gfs_wind_global_impl
        return await ingest_gfs_wind_global_impl(self)

    async def ingest_gfs_wind_global_mid(self) -> bool:
        """MID-RES (~2°) global GFS wind — the wind sibling of the marine mid tier. Delegates to
        wind_ingestion (LOC ceiling). Kill switch: GFS_WIND_MID_RES_INGEST=0."""
        from services.weather_pipeline.wind_mid_res_ingestion import ingest_gfs_wind_global_mid_impl
        return await ingest_gfs_wind_global_mid_impl(self)

    async def ingest_icon_wind_global_mid(self) -> bool:
        """MID-RES (~2°) global ICON wind (native DWD only). Kill: ICON_WIND_MID_RES_INGEST=0."""
        from services.weather_pipeline.wind_mid_res_ingestion import ingest_icon_wind_global_mid_impl
        return await ingest_icon_wind_global_mid_impl(self)

    async def ingest_euro_wind_global_mid(self) -> bool:
        """MID-RES (~2°) global EURO wind (native ECMWF only). Kill: EURO_WIND_MID_RES_INGEST=0."""
        from services.weather_pipeline.wind_mid_res_ingestion import ingest_euro_wind_global_mid_impl
        return await ingest_euro_wind_global_mid_impl(self)

    async def ingest_gfs_marine_global(self) -> bool:
        """
        Ingests GFS waves grid forecast globally at a coarse resolution.
        Fetches 14 days of forecasts in 3-hour increments for waves, swell_1, swell_2, and wind_waves.
        """
        logger.info("[Pipeline Scheduler] Starting GFS Marine Global Coarse Ingestion job...")
        env = get_env_flags()
        run_time = datetime.now(timezone.utc)
        total_saved = 0

        global_region = {
            "west": -180.0,
            "south": -80.0,
            "east": 180.0,
            "north": 85.0
        }
        resolution = 10.0

        forecast_days = int(os.environ.get("GFS_GLOBAL_FORECAST_DAYS", "2" if env["is_test_env"] else "14"))

        # ══ PRIMARY: native GFS-Wave direct from NOAA (AWS Open Data, byte-range GRIB2) ══
        # Moves GFS marine OFF open-meteo (frees the whole open-meteo daily budget so ICON marine can keep
        # its 3-hourly cadence) using the SAME ncep_gfswave025 model. Low-strain (~tens of MB peak), slow
        # (~5-15 min, background only — see noaa_gfs_wave_fetcher.py). Provider stays 'open-meteo' in the
        # save loop below so the manifest (source_dataset='ncep_gfswave025') is BYTE-IDENTICAL to the
        # open-meteo path — zero regression. NOAA unavailable/failed -> falls through to the existing
        # open-meteo fetch. Kill switch: GFS_MARINE_NOAA_DIRECT=0.
        noaa_direct = os.environ.get("GFS_MARINE_NOAA_DIRECT", "1") != "0"
        results = None
        from_noaa = False
        if noaa_direct:
            try:
                from services.noaa_marine_service import fetch_gfs_marine_global_coarse
                results = await fetch_gfs_marine_global_coarse(global_region, resolution, forecast_days)
                if results:
                    from_noaa = True
                    logger.info(f"[Pipeline Scheduler] GFS-Wave NOAA-direct OK: {len(results)} points (off open-meteo).")
            except Exception as _ne:
                logger.error(f"[Pipeline Scheduler] GFS-Wave NOAA-direct fetch errored: {_ne}")

        if not results:
            if noaa_direct:
                logger.warning("[Pipeline Scheduler] GFS-Wave NOAA-direct unavailable; falling back to open-meteo.")
            results = await self._fetch_or_mock(
                "GFS", "marine", "all_marine", global_region, resolution, forecast_days,
                env["is_test_env"],
                lambda: generate_mock_marine_results(self.om_provider, global_region, resolution),
                "global_coarse"
            )
        if not results:
            logger.error("[Pipeline Scheduler] GFS marine global_coarse fetch failed. Skipping.")
            self._gfs_coarse_marine_cache = None
            return False

        # Stash for the EURO enclosed-sea/Antarctic GFS-fill (next job, same process, coarse_axis-aligned).
        # `del results` in _cleanup_and_pause below drops only the local name; this ref survives (EURO clears it).
        self._gfs_coarse_marine_cache = results if results else None

        # NOAA GFS-Wave is natively 3-hourly (step=1 keeps every step); open-meteo all_marine is hourly
        # (step=3 -> 3-hourly products). Same 3-hourly product cadence either way.
        save_step = 1 if from_noaa else 3
        layers = ["waves", "swell_1", "swell_2", "wind_waves"]
        for layer in layers:
            count = await normalize_and_save_loop(
                self.normalizer, self.store, results,
                model="GFS", provider="open-meteo", domain="marine", layer=layer,
                bbox=global_region, resolution=resolution, run_time=run_time,
                region_id="global_coarse", coverage_mode="global_tile",
                is_test_env=env["is_test_env"], step=save_step,
                log_prefix=f"[Pipeline Scheduler] GFS {layer} global_coarse"
            )
            logger.info(f"[Pipeline Scheduler] Ingested {count} GFS {layer} global coarse grid files.")
            total_saved += count
            if count > 0:
                self.store.prune_superseded_products("GFS", "marine", layer, "global_coarse", run_time)

        await self._cleanup_and_pause(results, 0)
        return total_saved > 0

    async def ingest_gfs_marine_global_mid(self) -> bool:
        """MID-RES (z6-7 tier) global GFS/NOAA waves. Delegates to marine_mid_res_ingestion (keeps this
        file under the 800-LOC ceiling). Kill switch: GFS_MARINE_MID_RES_INGEST=0."""
        from services.weather_pipeline.marine_mid_res_ingestion import ingest_gfs_marine_global_mid_impl
        return await ingest_gfs_marine_global_mid_impl(self)

    async def ingest_copernicus_island_regions(self) -> bool:
        """
        The 0.083 deg (~9.2 km) CMEMS wave field for the 20 island regions where a 0.25 deg grid
        cannot resolve windward from lee. One CMEMS bbox subset per region, ~13 s each (measured:
        latency is per CALL, not per cell), ~4.6 MB/frame total.

        Writes products only — no serving tier reads region_id `island_*` yet, so this is inert for
        viewports until one does. Products must exist BEFORE the serving tier can be gated on their
        residency, which is why ingest lands first.
        """
        from services.weather_pipeline.copernicus_island_ingestion import ingest_copernicus_island_regions_impl
        return await ingest_copernicus_island_regions_impl(self)

    async def ingest_euro_marine_global(self) -> bool:
        """Ingests EURO waves grid forecast globally at a coarse resolution (10°, 'global_coarse').
        Delegates to euro_marine_coarse_ingestion (keeps this file under the 800-LOC ceiling)."""
        from services.weather_pipeline.euro_marine_coarse_ingestion import ingest_euro_marine_global_impl
        return await ingest_euro_marine_global_impl(self)

    async def ingest_euro_wind_global(self) -> bool:
        """Ingests EURO wind grid forecast globally at a coarse resolution."""
        from services.weather_pipeline.wind_ingestion import ingest_euro_wind_global_impl
        return await ingest_euro_wind_global_impl(self)

    async def ingest_icon_wind_global(self) -> bool:
        """Ingests ICON wind grid forecast globally at a coarse resolution."""
        from services.weather_pipeline.wind_ingestion import ingest_icon_wind_global_impl
        return await ingest_icon_wind_global_impl(self)

    async def ingest_gfs_pressure_pilot(self) -> bool:
        """Stage 6D Pilot: Ingests GFS pressure grid forecast for Florida/East Coast."""
        from services.weather_pipeline.pressure_ingestion import ingest_gfs_pressure_pilot_impl
        return await ingest_gfs_pressure_pilot_impl(self)

    async def ingest_icon_pressure_pilot(self) -> bool:
        """Stage 6E Pilot: Ingests ICON pressure grid forecast for Florida/East Coast."""
        from services.weather_pipeline.pressure_ingestion import ingest_icon_pressure_pilot_impl
        return await ingest_icon_pressure_pilot_impl(self)

    async def ingest_euro_pressure_pilot(self) -> bool:
        """Stage 6E Pilot: Ingests EURO pressure grid forecast for Florida/East Coast."""
        from services.weather_pipeline.pressure_ingestion import ingest_euro_pressure_pilot_impl
        return await ingest_euro_pressure_pilot_impl(self)

    async def ingest_icon_marine_global(self) -> bool:
        """
        Ingests ICON waves grid forecast globally at a coarse resolution.
        Fetches 7 days of forecasts in 3-hour increments for waves, swell_1, and wind_waves.
        Swell 2 is unsupported and will not be ingested.
        """
        logger.info("[Pipeline Scheduler] Starting ICON Marine Global Coarse Ingestion job...")
        env = get_env_flags()
        run_time = datetime.now(timezone.utc)
        total_saved = 0

        global_region = {
            "west": -180.0,
            "south": -80.0,
            "east": 180.0,
            "north": 85.0
        }
        resolution = 10.0

        forecast_days = int(os.environ.get("ICON_GLOBAL_FORECAST_DAYS", "2" if env["is_test_env"] else "7"))

        # ══ PRIMARY: native ICON/GWAM marine direct from DWD opendata (bz2 GRIB2) ══
        # Moves ICON marine OFF open-meteo (frees its budget) using the SAME gwam model. Low-strain
        # (many small files, one at a time), slow (~5-10 min, background only — see dwd_gwam_fetcher.py).
        # Provider stays 'open-meteo' in the save loop below so the manifest (source_dataset='dwd_gwam')
        # is BYTE-IDENTICAL to the open-meteo path — zero regression. DWD unavailable/failed -> falls
        # through to the existing open-meteo fetch. Kill switch: ICON_MARINE_DWD_DIRECT=0.
        dwd_direct = os.environ.get("ICON_MARINE_DWD_DIRECT", "1") != "0"
        results = None
        from_dwd = False
        if dwd_direct:
            try:
                from services.dwd_marine_service import fetch_icon_marine_global_coarse
                results = await fetch_icon_marine_global_coarse(global_region, resolution, forecast_days)
                if results:
                    from_dwd = True
                    logger.info(f"[Pipeline Scheduler] ICON marine DWD-direct OK: {len(results)} points (off open-meteo).")
            except Exception as _de:
                logger.error(f"[Pipeline Scheduler] ICON marine DWD-direct fetch errored: {_de}")

        if not results:
            if dwd_direct:
                logger.warning("[Pipeline Scheduler] ICON marine DWD-direct unavailable; falling back to open-meteo.")
            results = await self._fetch_or_mock(
                "ICON", "marine", "all_marine", global_region, resolution, forecast_days,
                env["is_test_env"],
                lambda: generate_mock_icon_marine_results(self.om_provider, global_region, resolution),
                "global_coarse"
            )
        if not results:
            logger.error("[Pipeline Scheduler] ICON marine global_coarse fetch failed. Skipping.")
            return False

        # DWD GWAM is natively 3-hourly (step=1); open-meteo all_marine is hourly (step=3 -> 3-hourly).
        save_step = 1 if from_dwd else 3
        layers = ["waves", "swell_1", "wind_waves"]
        for layer in layers:
            count = await normalize_and_save_loop(
                self.normalizer, self.store, results,
                model="ICON", provider="open-meteo", domain="marine", layer=layer,
                bbox=global_region, resolution=resolution, run_time=run_time,
                region_id="global_coarse", coverage_mode="global_tile",
                is_test_env=env["is_test_env"], step=save_step,
                log_prefix=f"[Pipeline Scheduler] ICON {layer} global_coarse"
            )
            logger.info(f"[Pipeline Scheduler] Ingested {count} ICON {layer} global coarse grid files.")
            total_saved += count
            if count > 0:
                self.store.prune_superseded_products("ICON", "marine", layer, "global_coarse", run_time)

        await self._cleanup_and_pause(results, 0)
        return total_saved > 0

    async def ingest_icon_marine_global_mid(self) -> bool:
        """MID-RES (z6-7 tier) global ICON/DWD waves. Delegates to marine_mid_res_ingestion (keeps this
        file under the 800-LOC ceiling). Kill switch: ICON_MARINE_MID_RES_INGEST=0."""
        from services.weather_pipeline.marine_mid_res_ingestion import ingest_icon_marine_global_mid_impl
        return await ingest_icon_marine_global_mid_impl(self)

    async def ingest_euro_marine_global_mid(self) -> bool:
        """MID-RES (z6-7 tier) global EURO/Copernicus waves. Delegates to marine_mid_res_ingestion.
        ⚠️ 2nd ~15-30min CMEMS fetch/cycle — DEFAULT-OFF (EURO_MARINE_MID_RES_INGEST at registration)."""
        from services.weather_pipeline.marine_mid_res_ingestion import ingest_euro_marine_global_mid_impl
        return await ingest_euro_marine_global_mid_impl(self)

    async def ingest_euro_marine_pilot(self) -> bool:
        """EURO 0.25° regional pilot via the free ECMWF wave stream (NO CMEMS) — the EURO rating-band
        resolution fix (2026-07-13). Delegates to marine_mid_res_ingestion (800-LOC ceiling).
        Kill: EURO_MARINE_PILOT_INGEST=0 at the registration site."""
        from services.weather_pipeline.marine_mid_res_ingestion import ingest_euro_marine_pilot_impl
        return await ingest_euro_marine_pilot_impl(self)

    async def ingest_gfs_pressure_global(self) -> bool:
        """Ingests GFS pressure grid forecast globally at a coarse resolution."""
        from services.weather_pipeline.pressure_ingestion import ingest_gfs_pressure_global_impl
        return await ingest_gfs_pressure_global_impl(self)

    async def ingest_icon_pressure_global(self) -> bool:
        """Ingests ICON pressure grid forecast globally at a coarse resolution."""
        from services.weather_pipeline.pressure_ingestion import ingest_icon_pressure_global_impl
        return await ingest_icon_pressure_global_impl(self)

    async def ingest_euro_pressure_global(self) -> bool:
        """Ingests EURO pressure grid forecast globally at a coarse resolution."""
        from services.weather_pipeline.pressure_ingestion import ingest_euro_pressure_global_impl
        return await ingest_euro_pressure_global_impl(self)

    async def ingest_copernicus_regional(self) -> bool:
        """
        Stage 4 Ingestion: Scheduled fetch of Copernicus regional wave component layers for all configured regions.
        """
        logger.info("[Pipeline Scheduler] Starting Copernicus Regional Ingestion job...")
        import os
        env = get_env_flags()
        layers = ["waves", "swell_1", "swell_2", "wind_waves"]
        run_time = datetime.now(timezone.utc)
        total_success = 0

        has_credentials = bool(
            os.environ.get("COPERNICUSMARINE_SERVICE_USERNAME") and
            os.environ.get("COPERNICUSMARINE_SERVICE_PASSWORD")
        )

        for region_id, region in REGIONAL_CONFIGS.items():
            logger.info(f"[Pipeline Scheduler] Ingesting Copernicus Regional for region: {region_id}")
            
            # Swell 2 is not requested for SoCal
            region_layers = ["waves", "swell_1", "wind_waves"] if region_id == "us_west_coast_socal" \
                else layers

            for layer in region_layers:
                results = None
                res_to_save = 0.5
                provider_name = "copernicus"

                if has_credentials:
                    results = await self.cop_provider.fetch_grid(
                        layer=layer, bbox=region, resolution=0.5,
                        forecast_days=int(os.environ.get("COPERNICUS_FORECAST_DAYS", "10"))
                    )
                    if results:
                        results = results if isinstance(results, list) else [results]

                if not results:
                    if env["is_test_env"]:
                        logger.info(f"[Pipeline Scheduler] Test environment active. Generating isolated mock Copernicus test fixture for {region_id}...")
                        mock_res = 1.5
                        res_to_save = mock_res
                        provider_name = "test-fixture"
                        results = generate_mock_copernicus_results(region, mock_res)
                    else:
                        logger.error(f"[Pipeline Scheduler] Copernicus Ingestion: failed to fetch grid for region: {region_id}, layer: {layer}. Skipping.")
                        continue

                count = await normalize_and_save_loop(
                    self.normalizer, self.store, results,
                    model="EURO", provider=provider_name, domain="marine", layer=layer,
                    bbox=region, resolution=res_to_save, run_time=run_time,
                    region_id=region_id, coverage_mode="regional_tile",
                    is_test_env=env["is_test_env"],
                    step=1,  # Save all frames, not just every 3rd
                    log_prefix=f"[Pipeline Scheduler] Copernicus {layer} {region_id}"
                )
                total_success += count
                if count > 0:
                    self.store.prune_superseded_products("EURO", "marine", layer, region_id, run_time)
                await self._cleanup_and_pause(results, 0)

        logger.info(f"[Pipeline Scheduler] Copernicus Ingestion Job completed! Saved {total_success} product files.")
        return total_success > 0

    async def ingest_icon_marine_pilot(self) -> bool:
        """ICON 0.25° regional pilot — MULTI-BBOX-FIRST since 2026-07-13 (one GWAM pass samples
        flagship + ALL worldwide regions; per-region flagship fallback). Delegates to
        marine_mid_res_ingestion (800-LOC ceiling). Kill: ICON_MARINE_PILOT_INGEST=0."""
        from services.weather_pipeline.marine_mid_res_ingestion import ingest_icon_marine_pilot_impl
        return await ingest_icon_marine_pilot_impl(self)

    async def ingest_icon_wind_pilot(self) -> bool:
        """Stage 5C/6H.1: Ingests ICON wind grid forecast for all configured regions."""
        from services.weather_pipeline.wind_ingestion import ingest_icon_wind_pilot_impl
        return await ingest_icon_wind_pilot_impl(self)

    async def ingest_euro_wind_pilot(self) -> bool:
        """Stage 5D/6H.1: Ingests EURO wind grid forecast for all configured regions."""
        from services.weather_pipeline.wind_ingestion import ingest_euro_wind_pilot_impl
        return await ingest_euro_wind_pilot_impl(self)

    async def ingest_euro_marine_extended_estimates(self) -> bool:
        """
        Stage 6I.2: Precomputes and saves EURO Marine extended estimate grids.
        Delegated to scheduler_helpers.py to satisfy the 800 LOC limit.
        """
        from services.weather_pipeline.scheduler_helpers import ingest_euro_marine_extended_estimates_impl
        return await ingest_euro_marine_extended_estimates_impl(self)

    async def ingest_icon_marine_extended_estimates(self) -> bool:
        """
        Stage 6I.3: Precomputes ICON marine 168->336h estimates (persistence + GFS trend) so the
        client's 3-fetch-per-far-hour blend demotes to fallback. See icon_marine_extension.py.
        """
        from services.weather_pipeline.icon_marine_extension import ingest_icon_marine_extended_estimates_impl
        return await ingest_icon_marine_extended_estimates_impl(self)

    async def ingest_lattice_inband_fill(self) -> bool:
        """
        Stage 6I.4: Interpolates the missing 3-hourly frames where a source's native cadence is
        coarser than the scrub lattice (ECMWF open-data is 6-hourly past +144h — the "blank day"
        family). Compute-only, store-fed. See lattice_fill.py.
        """
        from services.weather_pipeline.lattice_fill import fill_inband_lattice_gaps_impl
        return await fill_inband_lattice_gaps_impl(self)

