"""sim_forecast.py — the app's OWN active forecast at a coordinate, for callers outside the API.

WHY THIS EXISTS
---------------
Until 2026-07-27 the weather simulation MCP could only answer `get_weather_forecast` for THREE
hand-tuned spots; every one of the other 1544 catalog spots returned `forecast: null`, because that
server stored no forecast and did no network I/O. A forecast tool that cannot forecast 99.8% of the
catalog is not a sandbox limitation, it is the missing feature.

The app already serves exactly this at `/api/weather/point`, sampled from the same cached product
grid the heatmaps use, so an out-of-process caller ASKS IT rather than modelling a second forecast.

THE MAPPING IS COPIED FROM `spot_ratings.rate_one_spot`
------------------------------------------------------
That function is the production consumer of the same endpoint, so mirroring it is what keeps a
second caller from drifting into a private interpretation of the same payload:

    swell height  <- marine point.speed      OFFSHORE Hs in metres, NOT the breaking height
    period        <- marine point.period
    swell dir     <- marine point.direction
    wind knots    <- wind point.speed        this endpoint reports wind in KNOTS
    wind dir      <- wind point.direction

`surf_height_m` on the marine response is the BREAKING height the app itself serves. It is returned
in the provenance so a caller computing its own can report PARITY instead of hiding a divergence —
that divergence is the defect `cf2efb48` was written to end.

CONTRACT
  * Never raises. A forecast is an ENRICHMENT: the app being unreachable must degrade the answer,
    never break the caller.
  * Both legs are required. With marine but no wind the vector would have to invent a wind, and an
    invented wind is exactly how a blown-out day reads clean.
  * Kill: SIM_LIVE_FORECAST=0 disables the lane entirely.
"""
import json
import logging
import math
import os
import threading
import time
import urllib.error
import urllib.parse
# `urllib.request` pulls `ssl`, whose `_ssl` C extension must load on the MAIN thread. Importing a
# C extension inside a worker thread is what deadlocked the sim MCP server's first tool call on
# 2026-07-27 (see `weather_sim_mcp._warm_hot_path`). Imported HERE, never inside a function.
import urllib.request
from collections import OrderedDict
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

BASE_URL = os.environ.get(
    "SIM_FORECAST_BASE_URL", "https://raw-surf-antigravity.onrender.com").rstrip("/")
MODEL = os.environ.get("SIM_FORECAST_MODEL", "GFS")

# ⚠️ A LIVE-DATA ENRICHMENT MUST NEVER DOMINATE THE RESPONSE TIME.
# This was 30 s, and measured 2026-07-27 against an unreachable app that made `get_surf_spots` block
# 42.2 s and `get_weather_forecast` 42.1 s — past the point where an MCP client reports a TIMEOUT
# instead of an answer. The sim then looks broken while being merely patient. The host is a free
# Render instance that cold-starts in ~50 s, so "slow" is a NORMAL state here, not an exceptional
# one. 8 s is longer than a warm request needs (0.5-1.1 s measured) and short enough that two of
# them still fit inside any sane client budget.
from services.weather_pipeline.config_env import env_float, env_int
TIMEOUT_S = env_float("SIM_FORECAST_TIMEOUT_S", 8.0, lo=0.5)

# After a failure, stop dialling for a while. Without this every tool call re-pays the full timeout
# — the same pile-up the 429 circuit breaker was added for on 2026-07-24. `get_weather_forecast`
# makes TWO requests, so an unbreakered outage costs double.
DOWN_COOLDOWN_S = env_float("SIM_FORECAST_COOLDOWN_S", 60.0, lo=0.0)
_down_until = 0.0


def _is_down() -> bool:
    return time.monotonic() < _down_until


def _mark_down() -> None:
    global _down_until
    _down_until = time.monotonic() + DOWN_COOLDOWN_S


def _mark_up() -> None:
    global _down_until
    _down_until = 0.0

# Keyed by (lat, lng, valid_time), the valid_time being the top of the hour. A what-if sweep hits
# one spot repeatedly and must not re-fetch.
# ⚠️ Entries do NOT expire on their own as the hour turns — the KEY changes, so a stale entry merely
# becomes unreachable and is never freed. A server sweeping the 1818-spot catalogue hour after hour
# would grow this without bound. `_remember` is what keeps that true.
#
# ★ IT USED TO KEEP EXACTLY ONE HOUR, dropping every other hour on each store. That bounded it, but
# it made a TIME SERIES the one access pattern the cache actively defeats: each frame evicted the
# previous one, so walking forward through hours re-fetched every step AND re-fetched all of them
# again on a second pass. Measured 2026-07-30 at Mavericks, 16 frames at a 3-h step: 19.8 s cold,
# and a second identical pass still cost 6.2 s having cached nothing reusable. `valid_time` is what
# makes these tools a FORECAST rather than a nowcast, so the series is the point, not an edge case.
#
# Bounded FIFO instead: insertion-ordered, oldest evicted first (NOT an LRU — a read does not
# refresh position; saying so because a comment in this repo once claimed LRU for a FIFO and cost a
# session to disprove). Fetching a series forward in time therefore evicts the past hours first,
# which is exactly the right order. ~1 KB an entry, so the default cap is well under a megabyte.
_FORECAST_CACHE_MAX = env_int("SIM_FORECAST_CACHE_MAX", 256, lo=1)
# ⚠️ A TTL IS NOW LOAD-BEARING AND WAS NOT BEFORE. Wiping every other hour on each store gave
# freshness by accident: nothing could outlive the hour it was fetched in. Holding many hours means
# an entry for a FUTURE hour would otherwise survive the next ingest and serve a forecast from a
# superseded model run — the provenance block would even stamp it with the old `run_time`, which is
# worse than a miss because it looks authoritative. Core ingest is every 4 h; an hour is well inside
# that and a forecast does not meaningfully move within one.
_FORECAST_CACHE_TTL_S = env_float("SIM_FORECAST_CACHE_TTL_S", 3600.0, lo=0.0)

# ⛔⛔ A FAILURE IS NOT AN ANSWER, AND IT MUST NOT LIVE AS LONG AS ONE (2026-08-03).
# `fetch_live_forecast` builds `(None, {"reason": ...})` when a leg is missing and memoizes it like
# any other result. `(None, reason)` is a perfectly good cached object, so ONE transient timeout
# removed a spot/hour for the FULL 3600 s positive TTL — 60x the DOWN_COOLDOWN_S breaker that caused
# it. MASTER AUDIT 1.0 §2b priced that blast radius as a 60 s window and offered "the breaker cools
# down" as the reason it self-heals; with the failure cached it does not, and that remedy was wrong
# by 60x. (§2b measured the consequence: the breaker drops the TAIL of a nearest-first candidate
# list, and at Jeffreys Bay the two FARTHEST candidates are ranks 1 and 2 by quality.)
# ⭐⭐ AND THE BREAKER CANNOT BE TRUSTED AS THE BACKSTOP: inside a two-leg forecast the FAILING leg
# calls `_mark_down()` and the HEALTHY leg then calls `_mark_up()`, so the lane reads UP while the
# cache holds the absence — health says up, the answer says missing. That is why this is a short
# NEGATIVE TTL rather than "never cache a failure": the cache is still what stops a 12-spot scan
# re-paying an 8 s timeout twelve times, and the breaker is not a reliable substitute for it.
# Kill: SIM_FORECAST_NEG_TTL_S=3600 restores the pre-2026-08-03 behaviour exactly.
NEGATIVE_CACHE_TTL_S = env_float("SIM_FORECAST_NEG_TTL_S", DOWN_COOLDOWN_S, lo=0.0)
_FORECAST_CACHE: "OrderedDict[Any, Any]" = OrderedDict()


def _is_negative(out: Any) -> bool:
    """A cached `(baseline, provenance)` whose baseline leg is absent — i.e. a recorded failure."""
    return isinstance(out, tuple) and len(out) == 2 and out[0] is None


def _remember(key: Any, out: Any) -> None:
    """Store an answer, stamped with the TTL its KIND earns — see the warning above."""
    ttl = NEGATIVE_CACHE_TTL_S if _is_negative(out) else _FORECAST_CACHE_TTL_S
    _FORECAST_CACHE[key] = (time.monotonic(), out, ttl)
    _FORECAST_CACHE.move_to_end(key)
    while len(_FORECAST_CACHE) > max(1, _FORECAST_CACHE_MAX):
        _FORECAST_CACHE.popitem(last=False)


def _recall(key: Any):
    """The cached answer for this key, or None when absent or expired. Drops what it expires, so a
    coordinate that is asked about once and never again cannot pin an entry forever.

    ⚠️ The TTL is stored PER ENTRY rather than read from the module constant at recall time, so an
    entry is judged by the policy in force when it was written — an operator raising
    SIM_FORECAST_NEG_TTL_S mid-incident cannot retroactively extend absences already banked."""
    hit = _FORECAST_CACHE.get(key)
    if hit is None:
        return None
    stamped_at, out, ttl = hit
    if time.monotonic() - stamped_at > ttl:
        del _FORECAST_CACHE[key]
        return None
    return out


# ── THE CATALOGUE, from the app rather than a local snapshot ─────────────────────────────────
# The sim read its spot list from `dev.db`, a SQLite snapshot that has drifted from production.
# Measured 2026-07-27, the drift is not cosmetic — it is wrong COORDINATES:
#     Bethune Beach          dev.db 28.998,-80.926   production 28.950892,-80.83899  (~7 km)
#     New Smyrna Beach Inlet dev.db is_active=1      production is_active=false (inland duplicate)
#     row counts             dev.db 1547 active      production 1515 active
# Bethune's dev.db coordinate is the exact one the owner caught by eye and the one production was
# corrected away from. Every geometry lookup, and now every live forecast sample, would be taken at
# a point 7 km from the spot — and reported with full confidence. A stale catalogue is worse than a
# missing one once the forecast is real.
# Kill: SIM_LIVE_CATALOG=0 falls back to dev.db exactly as before.
_CATALOG_CACHE: Dict[str, Any] = {}


def fetch_catalog() -> Optional[list]:
    """The app's active spot catalogue, or None. Never raises; cached for the process.

    Uses the PUBLIC `/api/surf-spots`, which returns every active spot with coordinates (1515 as of
    2026-07-27) and needs no credentials — the same reason the forecast lane asks the app instead of
    modelling one."""
    if os.environ.get("SIM_LIVE_CATALOG", "1") == "0":
        return None
    if "spots" in _CATALOG_CACHE:
        return _CATALOG_CACHE["spots"]
    if _is_down():
        return None                      # fail FAST while the app is known unreachable
    try:
        req = urllib.request.Request(f"{BASE_URL}/api/surf-spots",
                                     headers={"User-Agent": "raw-surf-weather-sim"})
        with urllib.request.urlopen(req, timeout=TIMEOUT_S) as resp:
            rows = json.loads(resp.read().decode("utf-8"))
        # `best_tide` (W-30): the spot's tide prior, which `tide_fit` grades the served tide against.
        # Dropped here until 2026-09-30, so every catalogue spot reached the sim with no prior and the
        # served tide could never move a score: the fix was inert on every real spot.
        spots = [{"id": r.get("id"), "name": r.get("name"), "region": r.get("region"),
                  "latitude": float(r["latitude"]), "longitude": float(r["longitude"]),
                  "best_tide": r.get("best_tide")}
                 for r in rows
                 if r.get("is_active") and r.get("latitude") is not None
                 and r.get("longitude") is not None]
        if not spots:
            logger.warning("live catalogue returned no usable spots; falling back")
            return None
        _CATALOG_CACHE["spots"] = spots
        _mark_up()
        return spots
    except Exception as e:
        _mark_down()
        logger.warning(f"live catalogue fetch failed ({e}); falling back to the local snapshot "
                       f"and pausing live lookups for {DOWN_COOLDOWN_S:g}s.")
        return None


def prefetch_catalog_async() -> Optional[threading.Thread]:
    """Warm the catalogue OFF the request path, at server start.

    The first tool call would otherwise pay the whole round trip — and on a cold Render instance
    that is the difference between an answer and a client-side timeout. Done in a daemon thread so
    a slow or dead app delays NOTHING: the tool simply falls back until the warm-up lands.
    ⚠️ Safe to run off the main thread only because `urllib`/`ssl` are imported at MODULE scope
    above — a C-extension import inside a worker thread is what deadlocked this server once already.
    """
    if os.environ.get("SIM_LIVE_CATALOG", "1") == "0":
        return None
    t = threading.Thread(target=fetch_catalog, name="sim-catalog-prefetch", daemon=True)
    t.start()
    return t


def current_valid_time() -> str:
    """The forecast hour to sample: the current UTC hour, top of the hour."""
    return datetime.now(timezone.utc).replace(
        minute=0, second=0, microsecond=0).strftime("%Y-%m-%dT%H:%M:%SZ")


def fetch_point(domain: str, layer: str, lat: float, lng: float,
                valid_time: str) -> Optional[Dict[str, Any]]:
    """One `/api/weather/point` sample, or None. Never raises."""
    qs = urllib.parse.urlencode({
        "model": MODEL, "domain": domain, "layer": layer,
        "lat": lat, "lng": lng, "valid_time": valid_time})
    url = f"{BASE_URL}/api/weather/point?{qs}"
    try:
        with urllib.request.urlopen(url, timeout=TIMEOUT_S) as resp:
            out = json.loads(resp.read().decode("utf-8"))
        _mark_up()
        return out
    except Exception as e:
        _mark_down()
        logger.warning(f"live forecast {domain}/{layer} at ({lat},{lng}) failed: {e}")
        return None


def _sane_partitions(raw):
    """Network partitions validated + coerced to the engine's shape, or None.

    The engine's partition guards (`h <= 0` in dominant_swell_period / effective_swell_exposure /
    sea_cleanliness) assume NUMERIC h/tp and raise TypeError on a JSON string — fail-closed
    per item here so a malformed train from a skewed server is dropped, never propagated. NaN is
    rejected the same way (it passes both `not x` and `x <= 0`). An unknown `kind` degrades to
    'swell' (the neutral reading: only 'windsea' is penalized)."""
    if not isinstance(raw, list):
        return None
    out = []
    for p in raw:
        if not isinstance(p, dict):
            continue
        try:
            h, tp = float(p.get("h")), float(p.get("tp"))
        except (TypeError, ValueError):
            continue
        if h != h or tp != tp or h <= 0 or tp <= 0:
            continue
        d = p.get("dir")
        try:
            d = float(d) if d is not None else None
        except (TypeError, ValueError):
            d = None
        if d is not None and d != d:
            d = None
        out.append({"h": h, "tp": tp, "dir": d,
                    "kind": "windsea" if p.get("kind") == "windsea" else "swell"})
    return out or None


def _sane_reference(raw) -> Optional[float]:
    """A remote `reference_size_m` validated at the trust boundary, or None.

    ⚠️ NaN IS THE DANGEROUS INPUT, NOT A NEGATIVE ONE. `surf_rating.size_score` guards with
    `reference_size_m is None or reference_size_m <= _HMIN_RIDEABLE_M`, and **NaN passes BOTH** —
    it is not None and every comparison against it is False — so it flows into `ref` and the whole
    score comes back NaN, which `score_to_level` reads as the TOP bucket ('epic'). A blown-out day
    would render as the best surf of the year. That is the recorded partitions landmine, one field
    over. A JSON string is the other shape: it raises TypeError out of the comparison and would
    cost the caller its entire tool answer.
    ⇒ coerce and range-check HERE, at the one entry point, exactly as `_sane_partitions` does
    (which likewise `float()`s its inputs, so a numeric string COERCES rather than being refused —
    the danger was a string reaching the engine, and coercion is what prevents it).

    ⚠️ `math.isfinite`, NOT `v != v`. My first version tested self-inequality alone and **the guard
    for this let `inf` straight through** — `inf != inf` is False and `inf <= 0` is False, so it
    passes both, and its failure mode is the MIRROR of NaN's: it drives `size_score` to 0.0, so
    every sea reads flat instead of epic. Caught by its own test before shipping.
    """
    try:
        v = float(raw)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(v) or v <= 0.0:
        return None
    # Non-physical upper bound, deliberately far above the climatology's own [0.4, 4.0] clamp so it
    # can never second-guess a legitimate reference — 20 m is a 65 ft TYPICAL day. This only catches
    # garbage from a skewed server, where the effect would be to make every real swell read flat.
    if v > 20.0:
        return None
    return v


def served_reference(provenance: Optional[Dict[str, Any]]) -> Optional[float]:
    """The size reference THE APP ITSELF USED at this coordinate, off the response the sim already
    fetched — or None when the app sent none.

    ★★★ THIS IS WHY IT EXISTS: the sim used to learn which size curve production was on by reading
    `RATING_LOCAL_SIZE` **out of its own process env**, a variable with no causal connection to
    production whatsoever. Measured live 2026-08-01 on the owner's own MCP server, whose config
    carries no env at all: Mavericks sim **54.6 `fair`** vs served **31.9 `poor_fair`** — delta
    **+22.7 with a LEVEL difference** — for a reason that had nothing to do with the code.
    ⇒ the recorded trap, verbatim: *a flag has a value PER LANE; read the SERVED PAYLOAD, not this
    process's env.* A served reference is production's own answer to the question the flag asks,
    OBSERVED rather than assumed, and it arrives on the same response, same run, same coordinate as
    the sea it grades — so the sim MIRRORS the composition instead of re-deriving it (CLAUDE.md).

    ⚠️ None is NOT "production is on the global curve" and must never suppress the local lookup.
    It is ambiguous between that and "this coordinate has no climatology", and in the second case
    the glyph still grades on the spot's own blob. Both readings agree on the same action: fall
    through to the caller's existing flag+blob path, which is the pre-2026-08-01 behaviour exactly.
    """
    return _sane_reference((provenance or {}).get("served_reference_size_m"))


def baseline_partitions(baseline: Optional[Dict[str, Any]],
                        resolved: Optional[Dict[str, Any]] = None):
    """The baseline's swell trains — IF they still describe the sea being rated, else None.

    Partitions describe the FORECAST sea (the live lane carries the trains the server's own height
    ran on). A what-if that changes any swell field is rating a DIFFERENT sea, so they must be
    dropped; a wind-only what-if keeps them, because the trains already in the water do not change
    when the local wind is hypothesized differently. The test is VALUE equality, not
    omitted-ness — a caller who types the forecast's own numbers back is still rating the
    forecast sea. Lives HERE beside the baseline producer (weather_sim_mcp is at the 800-line
    ratchet); the MCP module aliases it."""
    parts = (baseline or {}).get("partitions")
    if not parts:
        return None
    if resolved is None:
        return parts
    for k in ("swell_height_m", "swell_period_sec", "swell_direction_deg"):
        try:
            if abs(float(baseline[k]) - float(resolved[k])) > 1e-9:
                return None
        except (KeyError, TypeError, ValueError):
            return None
    return parts


def peek_live_forecast(lat: float, lng: float, valid_time: Optional[str] = None
                       ) -> Optional[Tuple[Optional[Dict[str, float]], Dict[str, Any]]]:
    """The cached forecast for this coordinate/hour, or None. NEVER dials.

    ★ Exists so a caller can enrich an answer with the real forecast when it is already in hand,
    WITHOUT taking on a network dependency it did not previously have. `simulate_weather_change`
    used to make zero requests; putting an unconditional fetch on that path is precisely the
    regression `576dcbdd` fixed (measured 42.2 s of blocking, past where an MCP client reports a
    TIMEOUT rather than an answer). A cache peek costs nothing and is a hit on the common flow,
    because asking for the forecast and then asking a what-if about it share this key."""
    if os.environ.get("SIM_LIVE_FORECAST", "1") == "0":
        return None
    key = (round(float(lat), 4), round(float(lng), 4), valid_time or current_valid_time())
    if os.environ.get("SIM_STRICT_INPUTS", "0") == "1":
        key += ("strict_inputs",)
    return _recall(key)



def _validated_baseline(marine_point, wind_point):
    """Validate measured inputs once; an unknown field must never become a measured zero."""
    fields = (
        (marine_point, "speed", "swell_height_m"),
        (marine_point, "period", "swell_period_sec"),
        (marine_point, "direction", "swell_direction_deg"),
        (wind_point, "speed", "wind_speed_knots"),
        (wind_point, "direction", "wind_direction_deg"),
    )
    baseline = {}
    for point, field, key in fields:
        raw = point.get(field)
        if isinstance(raw, bool) or not isinstance(raw, (int, float, str)):
            return None, f"missing or invalid {key}"
        try:
            value = float(raw)
        except (ValueError, TypeError, OverflowError):
            return None, f"missing or invalid {key}"
        if not math.isfinite(value) or value < 0 or ("direction" in key and value > 360):
            return None, f"missing or invalid {key}"
        baseline[key] = value
    if baseline["swell_height_m"] > 0 and baseline["swell_period_sec"] == 0:
        return None, "missing or invalid swell_period_sec for nonzero swell"
    return baseline, None


def fetch_live_forecast(lat: float, lng: float, valid_time: Optional[str] = None
                        ) -> Tuple[Optional[Dict[str, float]], Dict[str, Any]]:
    """The app's forecast at a coordinate, for `valid_time` or the current hour.

    Returns (baseline | None, provenance). The provenance always explains itself — on failure it
    carries a `reason`, so a caller can say WHY it has no forecast instead of returning a bare null.

    ⚠️ `valid_time` is what makes this a FORECAST rather than a nowcast. Measured 2026-07-28, the
    app serves authoritative frames out to at least +168 h at this coordinate, so "is tomorrow
    morning better?" — the question a surfer actually asks — is answerable and was not being asked.
    """
    if os.environ.get("SIM_LIVE_FORECAST", "1") == "0":
        return None, {"reason": "disabled (SIM_LIVE_FORECAST=0)"}
    valid_time = valid_time or current_valid_time()
    strict_inputs = os.environ.get("SIM_STRICT_INPUTS", "0") == "1"
    key = (round(float(lat), 4), round(float(lng), 4), valid_time)
    if strict_inputs:
        key += ("strict_inputs",)
    cached = _recall(key)
    if cached is not None:
        return cached
    if _is_down():
        # NOT cached: the app is down now, not wrong about this coordinate.
        return None, {"reason": "the app is not reachable right now", "valid_time": valid_time}

    marine = fetch_point("marine", "waves", lat, lng, valid_time)
    wind = fetch_point("wind", "wind", lat, lng, valid_time)
    mp = (marine or {}).get("point") or {}
    wp = (wind or {}).get("point") or {}
    if strict_inputs:
        mp = mp if isinstance(mp, dict) else {}
        wp = wp if isinstance(wp, dict) else {}
    identities = {}
    for domain, response in (("marine", marine), ("wind", wind)):
        response = response or {}
        identities[domain] = {
            "requested_valid_time": valid_time,
            **{field: response.get(field) for field in (
                "served_valid_time", "frame_offset_hours", "model_run_time", "run_time",
                "product_id", "is_estimated", "is_stale", "source", "is_forecast_authoritative")},
        }
    marine_time = identities["marine"]["served_valid_time"]
    wind_time = identities["wind"]["served_valid_time"]
    alignment = "unknown" if not marine_time or not wind_time else (
        "aligned" if marine_time == wind_time else "mixed")
    missing = [name for name, ok in (("marine", mp.get("speed") is not None),
                                     ("wind", wp.get("speed") is not None)) if not ok]
    baseline, invalid_reason = _validated_baseline(mp, wp) if strict_inputs else (None, None)
    if missing or invalid_reason:
        reason = f"no {' and '.join(missing)} data at this coordinate" if missing else invalid_reason
        out = (None, {"reason": reason,
                      "valid_time": valid_time, "model": MODEL,
                      "product_identity": identities, "time_alignment": alignment})
    else:
        if not strict_inputs:
            baseline = {
                "swell_height_m": float(mp["speed"]),
                "swell_period_sec": float(mp.get("period") or 0.0),
                "swell_direction_deg": float(mp.get("direction") or 0.0),
                "wind_speed_knots": float(wp["speed"]),
                "wind_direction_deg": float(wp.get("direction") or 0.0),
            }
        # The reconciled swell/windsea trains the SERVER's own height ran on (response.partitions;
        # present only when the serve side runs SURF_PARTITIONS=1). Carried so the sim grades the
        # SAME sea state the app served — the sim itself adds no fetches and no flag of its own.
        # Consumers iterate the fixed 5-key vocabulary above, so an extra key is additive.
        # ⚠️ TRUST BOUNDARY: this is json.loads of a REMOTE deploy, so item shapes are validated
        # and coerced HERE, at the one entry point — a version-skewed server sending h as a string
        # would otherwise raise TypeError out of `rating_score` and cost the caller its whole
        # tool answer (the engine's `h <= 0` guards are not str-safe).
        _parts = _sane_partitions((marine or {}).get("partitions"))
        if _parts:
            baseline["partitions"] = _parts
        out = (baseline, {
            "model": MODEL,
            "valid_time": marine.get("valid_time") or valid_time,
            "run_time": marine.get("run_time"),
            # ⚠️ WIND HAS ITS OWN RUN, always. The two domains are ingested by different jobs and
            # shared a run at 0 of 4 spots measured 2026-07-31 (Mavericks 07:27 vs 08:10, Bells
            # Beach 04:07 vs 14:44). Carrying only the marine one left half the score's inputs
            # unattributable, which is exactly the gap that made a sim↔glyph divergence need a live
            # re-compute to explain.
            "wind_run_time": (wind or {}).get("run_time"),
            "product_identity": identities,
            "time_alignment": alignment,
            "product_id": marine.get("product_id"),
            "is_forecast_authoritative": marine.get("is_forecast_authoritative"),
            "served_surf_height_m": marine.get("surf_height_m"),
            # WHICH SIZE CURVE THE APP GRADED THIS COORDINATE ON — the other half of parity, and
            # the one the sim was guessing. It sits beside `served_surf_height_m` because it is the
            # same kind of fact: not the sea, but what the app DID with it. Absent (older deploy,
            # RATING_LOCAL_SIZE off, or no climatology here) -> None -> the caller's existing path.
            # Validated at this boundary for the reason the partitions block states: this is
            # json.loads of a REMOTE deploy. See `_sane_reference` — NaN is the shape that hurts.
            "served_reference_size_m": _sane_reference(marine.get("reference_size_m")),
            "url": BASE_URL,
        })
    _remember(key, out)
    return out
