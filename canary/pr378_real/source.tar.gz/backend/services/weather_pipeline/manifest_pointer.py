"""S2 (2026-07-11): run-keyed manifest + Postgres pointer CAS.

Supabase Storage has no If-Match/ETag preconditions, so `manifest.json` is a hot mutable
object with last-writer-wins semantics (the audit #28 clobber family) and must be served
with max-age 0 + cache-busting (the f8c0c6b2 scar) — uncacheable on every edge, for every
user, on the hottest route.

This module flips that architecture without touching the legacy lane:

  writer (designated only):  upload immutable `manifests/manifest-g<generation>.json`
                             → CAS-advance the single pointer row in Postgres
                             (UPDATE ... WHERE generation = expected)
  reader:                    resolve pointer → GET the immutable run-keyed object
                             (plain GET, CDN-cacheable — no cache-busting needed)
                             → fall back to legacy `manifest.json` on ANY failure

The legacy `manifest.json` keeps being written and remains the fallback, so the lane is
transition-safe in both directions. If the pointer table does not exist yet (migration
pending), the first REST error disables the lane for the process and everything behaves
exactly as before.

Kill switch: MANIFEST_POINTER=0 disables both the publish and the read path.
MANIFEST_IMMUTABLE_PUBLICATION=1 uses unique create-only copies, acknowledged uploads
and bounded age/generation retention; default off preserves the legacy writer.
"""

import os
import json
import logging
import sys
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

POINTER_TABLE = "weather_manifest_pointer"
KEEP_RUN_KEYED = 5  # ring of retained run-keyed manifests (readers mid-GET stay safe)

_disabled_for_process = False
_disable_lock = threading.Lock()
_cas_answer = threading.local()
AMBIGUOUS_404_ERROR_EVERY = 5   # one-step lane: a 404 that does not say the table is gone is logged at ERROR 1st, 6th, 11th ... time
_ambiguous_404s = 0
_suppressed = threading.local()


@contextmanager
def publish_run_keyed_suppressed():
    """On THIS thread, publish_run_keyed is a no-op for the duration of the block.

    manifest_publish_step commits a merged snapshot through the pointer itself and only then PUTs the same bytes to the
    legacy manifest.json (the readers' fallback). That PUT ends in publish_run_keyed, which would read the pointer
    again and publish a second generation, from a fresh read, with bytes that never saw the head it moved to."""
    previous = getattr(_suppressed, "active", False)
    _suppressed.active = True
    try:
        yield
    finally:
        _suppressed.active = previous


def pointer_enabled() -> bool:
    if os.environ.get("MANIFEST_POINTER", "1") == "0":
        return False
    return not _disabled_for_process


def last_cas_answer() -> str:
    """How the last cas_advance on THIS thread ended: "won"; "lost" (HTTP 200 and no row: the precondition missed, so the swap
    certainly did not apply); or "unknown" (a timeout, a 5xx, anything else: it MAY have applied and only its answer was lost)."""
    return getattr(_cas_answer, "value", "unknown")


def _disable_for_process(reason: str, loud: bool = False):
    global _disabled_for_process
    with _disable_lock:
        if not _disabled_for_process:
            _disabled_for_process = True
            logger.warning(f"[Manifest Pointer] Lane disabled for this process: {reason} "
                           f"(legacy manifest.json path continues unaffected)")
            if loud:
                # Pointer-first readers resolve the pointer and never look at manifest.json: everything this process registers from
                # here on is invisible to them. A GitHub annotation, because a warning in a log nobody reads is how that goes unseen.
                sys.stdout.write(f"::error::[Manifest Pointer] pointer table missing ({reason}): this process's later manifest "
                                 f"registrations reach manifest.json only, and pointer-first readers will NOT see them\n")
                sys.stdout.flush()


def one_step_lane_active() -> bool:
    """Is the one-step lane ACTUALLY the lane in this process? The single predicate: `manifest_publish_step.one_step_active()` is this.

    The flag on is not enough. With MANIFEST_IMMUTABLE_PUBLICATION=1 (that lane owns the commit), MANIFEST_MERGE_ON_UPLOAD=0 (merging
    off), the pointer lane latched off, or a box that is not the designated writer, every publisher in the process is on TODAY'S
    path and must see today's behaviour, 404 standard included."""
    if os.environ.get("MANIFEST_PUBLISH_ONE_STEP", "0") != "1":
        return False
    if os.environ.get("MANIFEST_IMMUTABLE_PUBLICATION", "0") == "1":
        return False
    if os.environ.get("MANIFEST_MERGE_ON_UPLOAD", "1") == "0":
        return False
    if not pointer_enabled():
        return False
    from services.weather_pipeline import store
    return store._l2_pipeline_writes_allowed()


def _table_missing(resp) -> bool:
    """Does this answer to a pointer-table request mean the table is GONE (so the lane may latch off for the process)?

    Flag off: the old standard, untouched: any 404, or a 400 carrying 42P01.
    One-step lane: only an answer that SAYS so: a JSON body with Postgres' `42P01` or PostgREST's `relation "..." does not exist`
    message, status 400 or 404 (the same standard `_definite_miss` applies to objects). Anything else is not evidence: a PostgREST
    schema-cache miss (PGRST205), a proxy's 404 page, an empty 404 all happen to a healthy deployment, and latching on them
    turned one transient read into the lossy old path for the rest of the process. Those are retried like any 5xx."""
    if not one_step_lane_active():
        return resp.status_code == 404 or (resp.status_code == 400 and "42P01" in resp.text)
    if resp.status_code not in (400, 404):
        return False
    try:
        body = resp.json()
    except ValueError:
        return False
    if not isinstance(body, dict):
        return False
    message = body.get("message")
    return body.get("code") == "42P01" or (isinstance(message, str) and message.startswith("relation ") and message.endswith(" does not exist"))


def _note_ambiguous_404(what: str, resp):
    """One-step lane: a 404 that is NOT a definite table-missing answer. Counted; ERROR the first time and every Nth after."""
    global _ambiguous_404s
    _ambiguous_404s += 1
    level = logging.ERROR if _ambiguous_404s % AMBIGUOUS_404_ERROR_EVERY == 1 else logging.WARNING
    logger.log(level, f"[Manifest Pointer] {what}: HTTP 404 that does not say the pointer table is gone ({resp.text[:200]!r}); "
                      f"treated as transient (#{_ambiguous_404s}); the lane is NOT disabled")


def _rest_base_and_headers() -> Tuple[Optional[str], Optional[dict]]:
    base = os.environ.get("SUPABASE_URL", "").rstrip("/")
    key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY") or os.environ.get("SUPABASE_KEY", "")
    if not base or not key:
        return None, None
    return base, {
        "Authorization": f"Bearer {key}",
        "apikey": key,
        "Content-Type": "application/json",
    }


def run_keyed_manifest_key(generation: int) -> str:
    return f"manifests/manifest-g{generation:012d}.json"


def read_pointer(timeout: float = 8) -> Optional[dict]:
    """Resolve the current pointer row. Never raises; None on any failure. `timeout`: the one-step exit flush passes what is left of its budget."""
    if not pointer_enabled():
        return None
    base, headers = _rest_base_and_headers()
    if not base:
        return None
    try:
        import requests
        resp = requests.get(
            f"{base}/rest/v1/{POINTER_TABLE}?id=eq.1&select=generation,manifest_key,run_id,written_by,updated_at",
            headers=headers, timeout=timeout,
        )
        if _table_missing(resp):
            _disable_for_process(f"pointer table missing (HTTP {resp.status_code}) — migration not applied yet",
                                 loud=one_step_lane_active())
            return None
        if resp.status_code == 404 and one_step_lane_active():
            _note_ambiguous_404("read", resp)
            return None
        if resp.status_code != 200:
            logger.warning(f"[Manifest Pointer] read HTTP {resp.status_code}: {resp.text[:200]}")
            return None
        rows = resp.json()
        return rows[0] if rows else None
    except Exception as e:
        logger.warning(f"[Manifest Pointer] read failed: {e}")
        return None


def _insert_initial(manifest_key: str, run_id: Optional[str], written_by: str) -> bool:
    base, headers = _rest_base_and_headers()
    if not base:
        return False
    try:
        import requests
        resp = requests.post(
            f"{base}/rest/v1/{POINTER_TABLE}",
            headers={**headers, "Prefer": "return=minimal"},
            data=json.dumps({
                "id": 1, "generation": 1, "manifest_key": manifest_key,
                "run_id": run_id, "written_by": written_by,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }),
            timeout=8,
        )
        return resp.status_code in (200, 201)
    except Exception as e:
        logger.warning(f"[Manifest Pointer] initial insert failed: {e}")
        return False


def cas_advance(expected_generation: int, manifest_key: str, run_id: Optional[str], written_by: str,
                expected_key: Optional[str] = None, timeout: float = 8) -> bool:
    """Compare-and-swap the pointer forward. True only if OUR row landed.

    `expected_key` (manifest_publish_step): also require the row to still NAME that object, not just carry that generation
    NUMBER. A pointer restored to an older generation and advanced again by another writer reuses numbers, and a swap on the
    number alone would win with bytes merged against a different head (ABA). None = the generation alone, as every other caller."""
    _cas_answer.value = "unknown"
    base, headers = _rest_base_and_headers()
    if not base:
        return False
    try:
        import requests
        from urllib.parse import quote
        key_filter = f"&manifest_key=eq.{quote(expected_key, safe='')}" if expected_key is not None else ""
        resp = requests.patch(
            f"{base}/rest/v1/{POINTER_TABLE}?id=eq.1&generation=eq.{expected_generation}{key_filter}",
            headers={**headers, "Prefer": "return=representation"},
            data=json.dumps({
                "generation": expected_generation + 1,
                "manifest_key": manifest_key,
                "run_id": run_id,
                "written_by": written_by,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }),
            timeout=timeout,
        )
        if _table_missing(resp):
            _disable_for_process(f"pointer table missing (HTTP {resp.status_code}) — migration not applied yet",
                                 loud=one_step_lane_active())
            return False
        if resp.status_code == 404 and one_step_lane_active():
            _note_ambiguous_404("swap", resp)
            return False
        if resp.status_code not in (200, 201):
            logger.warning(f"[Manifest Pointer] CAS HTTP {resp.status_code}: {resp.text[:200]}")
            return False
        rows = resp.json()
        _cas_answer.value = "won" if rows else "lost"
        return bool(rows)  # empty list = precondition lost (another writer advanced first)
    except Exception as e:
        logger.warning(f"[Manifest Pointer] CAS failed: {e}")
        return False


def publish_run_keyed(store, manifest_bytes: bytes, upload_fn, delete_fn) -> Optional[str]:
    """Publish an immutable run-keyed manifest copy and CAS-advance the pointer.

    Called ONLY from the successful legacy `manifest.json` upload path (which is behind the
    designated-writer gate, so non-designated boxes can never reach this). `upload_fn` /
    `delete_fn` are the store's L2 REST helpers — `manifests/...` is a namespaced key, so it
    passes the gate by construction and receives immutable cache headers (not the manifest.json
    max-age 0 special case).

    Returns the published key, or None (lane disabled / CAS lost / any failure).
    Never raises: the legacy lane must be unaffected by ANY failure here.
    """
    if getattr(_suppressed, "active", False):
        return None  # manifest_publish_step already committed these bytes through the pointer
    if not pointer_enabled():
        return None
    if os.environ.get("MANIFEST_IMMUTABLE_PUBLICATION", "0") == "1":
        from services.weather_pipeline.manifest_immutable import publish_immutable
        return publish_immutable(manifest_bytes, upload_fn)
    try:
        current = read_pointer()
        run_id = os.environ.get("GITHUB_RUN_ID")
        from services.weather_pipeline.store import _l2_writer_identity
        written_by = _l2_writer_identity()

        if current is None:
            if not pointer_enabled():  # read_pointer may have just disabled the lane (no table)
                return None
            key = run_keyed_manifest_key(1)
            upload_fn(key, manifest_bytes)
            if _insert_initial(key, run_id, written_by):
                logger.info(f"[Manifest Pointer] initialized → {key}")
                return key
            # Insert lost a race — re-read and fall through to CAS on the next publish.
            return None

        gen = int(current.get("generation", 0))
        key = run_keyed_manifest_key(gen + 1)
        upload_fn(key, manifest_bytes)  # immutable object FIRST, pointer flip = the commit point
        if not cas_advance(gen, key, run_id, written_by):
            # Lost the race (or table vanished). Another designated writer advanced — their
            # snapshot wins, ours lingers unreferenced until the retention sweep below runs
            # from the winner's later publishes. GH's serial concurrency group makes this rare.
            logger.warning(f"[Manifest Pointer] CAS lost at generation {gen} — {key} left unreferenced")
            return None

        # Retention ring: best-effort prune of the copy KEEP_RUN_KEYED generations back.
        old_gen = gen + 1 - KEEP_RUN_KEYED
        if old_gen > 0:
            try:
                delete_fn(run_keyed_manifest_key(old_gen))
            except Exception:
                pass
        logger.info(f"[Manifest Pointer] advanced g{gen}→g{gen + 1} → {key}")
        return key
    except Exception as e:
        logger.warning(f"[Manifest Pointer] publish failed (legacy lane unaffected): {e}")
        return None


class _Missing:
    """What `fetch_manifest_object` answers when Storage says, definitely, that the object does not exist."""

    def __bool__(self):
        return False

    def __repr__(self):
        return "MISSING"


MISSING = _Missing()


def _definite_miss(resp) -> bool:
    """True only when Storage says THIS OBJECT is not there (l2_retry.is_missing_object, plus a plain 404 carrying Supabase's own
    `not_found` body). A proxy's 404 page, a missing bucket and a bad key are not."""
    from services.weather_pipeline.l2_retry import is_missing_object
    if is_missing_object(resp):
        return True
    if resp.status_code != 404:
        return False
    try:
        body = resp.json()
    except ValueError:
        return False
    return isinstance(body, dict) and body.get("error") == "not_found"


def fetch_manifest_object(key: str, timeout: float = 30):
    """GET one run-keyed manifest object by the key the pointer row names (plain GET, immutable object).

    The one-step publisher reads the head BY KEY, so the bytes it merges are the bytes of the generation it will
    compare-and-swap from, never a second read that could belong to a later generation. Never raises. Answers the bytes;
    MISSING when Storage definitely has no such object (the head was never written, or was deleted); None on anything else
    (a 5xx, a 429, a timeout: transient, the caller retries)."""
    if not key:
        return None
    base, headers = _rest_base_and_headers()
    if not base:
        return None
    try:
        import requests
        from services.weather_pipeline.store import WEATHER_BUCKET
        resp = requests.get(f"{base}/storage/v1/object/{WEATHER_BUCKET}/{key}", headers=headers, timeout=timeout)
        if resp.status_code != 200:
            logger.warning(f"[Manifest Pointer] manifest object GET {key} -> HTTP {resp.status_code}")
            return MISSING if _definite_miss(resp) else None
        return resp.content
    except Exception as e:
        logger.warning(f"[Manifest Pointer] manifest object fetch failed for {key}: {e}")
        return None


def fetch_pointed_manifest() -> Optional[bytes]:
    """Reader: resolve the pointer and GET the immutable run-keyed manifest.

    Plain GET — run-keyed objects never mutate, so any CDN edge copy is correct by
    construction (the whole point of S2). None on any failure → caller falls back to the
    legacy cache-busted manifest.json path.
    """
    if not pointer_enabled():
        return None
    ptr = read_pointer()
    if not ptr or not ptr.get("manifest_key"):
        return None
    base, headers = _rest_base_and_headers()
    if not base:
        return None
    try:
        import requests
        from services.weather_pipeline.store import WEATHER_BUCKET
        resp = requests.get(
            f"{base}/storage/v1/object/{WEATHER_BUCKET}/{ptr['manifest_key']}",
            headers=headers, timeout=30,
        )
        if resp.status_code != 200:
            logger.warning(f"[Manifest Pointer] pointed manifest GET {ptr['manifest_key']} → HTTP {resp.status_code}")
            return None
        logger.info(f"[Manifest Pointer] manifest served from {ptr['manifest_key']} (g{ptr.get('generation')}, by {ptr.get('written_by')})")
        return resp.content
    except Exception as e:
        logger.warning(f"[Manifest Pointer] pointed manifest fetch failed: {e}")
        return None
