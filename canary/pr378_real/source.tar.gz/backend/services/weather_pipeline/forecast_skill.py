"""Forecast skill ledger — our accuracy at LEAD TIME, against reality and against a competitor.

WHY (owner, 2026-07-30): "test against reality and other surf forecast apps' data, to measure if
we're very wrong or near — we are trying to be more accurate than the competition." T+0 residuals
(the calibration loop) cannot answer that: the product a surfer judges is "will Thursday be good",
which is the +24/+48/+72h forecast. Per-lead skill is how the industry scores itself, and like the
residual archive it is unrecoverable — a forecast not recorded when it was made can never be
scored. So every calibration run:

  1. LEDGERS the forecasts being made NOW for +24/+48/+72h at every mapped buoy — ours (the same
     resolver the product serves from) and a competitor lane (Open-Meteo marine, one batched
     multi-coordinate call) — into `calibration/skill/pending.json`.
  2. SCORES pending rows whose target hour has arrived against THIS run's fresh buoy observations
     (truth), appending to monthly `calibration/skill/scored-YYYY-MM.json` segments (append-only,
     deduplicated, never pruned — same contract as the residual history).

The dedupe key keeps the EARLIEST forecast per (source, buoy, target, lead-bucket) — the honest
lead. Summary: per source x lead MAE/bias with n and n_buoys, so "are we near?" is a number, not
an impression. Kill switch FORECAST_SKILL=0; every failure is swallowed (the calibration loop is
never at risk). Rows are ~120 B; pending is capped, scored history is segmented by month to September and by
UTC day from October (skill_scored_archive.py: the monthly object hit Storage's 50 MiB limit).
"""
import json
import logging
import math
import os
import urllib.request
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

from services.weather_pipeline import skill_scored_archive as archive_keys

logger = logging.getLogger(__name__)

SKILL_PENDING_L2_KEY = "calibration/skill/pending.json"
SKILL_SCORED_PREFIX = archive_keys.SCORED_PREFIX    # where scored rows live: see skill_scored_archive.py
LEADS_H = (24, 48, 72)
SCORE_JOIN_TOLERANCE_S = 90 * 60      # obs within 1.5h of the target hour scores it
PENDING_EXPIRY_H = 96                  # unmatched past-target rows drop (buoy gap)
# ⭐ SIZED FROM DEMAND, ARITHMETIC SHOWN (2026-08-08) — the last number here was a guess that killed
# the instrument. Steady-state pending = buoys x lanes x runs/day x Σ(lead_h/24)
# = 60 x 4 x 12 x (1+2+3) = 17,280 rows (simulated at production shape: 17,280 exactly, 2.05 MB
# compact). The old 10,000 sat UNDER demand from the 08-03 model fan-out onward, and with the old
# keep-latest eviction that read as scored=0 in production from 08-04T12:36Z — the platform's only
# lead-time accuracy number, dead for four days (MASTER-AUDIT-11.0 §3.1). 30,000 holds today's
# demand plus two more compare models (6 lanes -> 25,920) and bounds the object at ~3.6 MB; if it
# ever binds, that is itself a pathology signal, and `merge_pending`'s keep-earliest order confines
# the damage to the farthest lead instead of zeroing all three.
# ⬆ 30,000 -> 54,000 (2026-09-30 audit). It BOUND: production's armed lanes are ours, ICON, EURO, the CONSENSUS
# shadow (armed 2026-09-29), Open-Meteo marine, the Open-Meteo same-model control and persistence = 7, i.e.
# 59 buoys x 7 x 12 runs/day x 6 lead-days = 29,736 rows of demand; the live report read pending_kept 29,477 of
# 30,000. The headroom test counted only the code-default lanes (5) and missed both. Two switch-added lanes are
# queued behind it: GFS_RAW (added automatically by the CONSENSUS_SERVE flip) and GFS_SCALAR, which would have
# started evicting every lane's +72 h rows. 9 lanes x 60 x 72 = 38,880; x1.3 = 50,544 <= 54,000 (~6.5 MB object,
# read and written only in the Actions lanes).
PENDING_MAX_ENTRIES = 54000
OM_MARINE = "https://marine-api.open-meteo.com/v1/marine"

SOURCE_OURS = "raw_surf"
SOURCE_OM = "open_meteo_marine"
# ⭐⭐⭐ THE SAME-MODEL CONTROL (2026-08-10). `SOURCE_OM` above requests the marine endpoint with NO
# `models=` parameter, so it serves Open-Meteo's `best_match` — their best available wave model per
# coordinate, typically MFWAM 0.08 deg or ECMWF WAM. Our primary lane is GFS (WAVEWATCH III,
# 0.25 deg). Measured PAIRED 2026-08-10 it beat us at every lead (0.157/0.174/0.188 vs our
# 0.221/0.258/0.263, we win ~37%) and that number CANNOT distinguish the two explanations:
#     (a) MODEL CHOICE  — their best-of-breed beats our single GFS lane, pipeline fine
#     (b) OUR CHAIN     — resolution / interpolation at the buoy / time alignment, a real defect
# Those imply completely different work, so the ledger must not be asked to guess between them.
# This lane pins `models=gfs_wave`: the SAME model as ours, fetched by someone else. Then
#     OM-GFS ~= ours  ⇒ (a), and the question becomes which model to serve
#     OM-GFS  > ours  ⇒ (b), and the gap is inside our chain
# ⚠️ AND IT FIXES A DEFECT IN THE BASELINE ITSELF: `best_match` is a LABEL, not a data source.
# Open-Meteo may change which model backs it, per coordinate and over time, and the response
# carries no `model` field to tell us — so today's competitor row and next month's may be different
# models under one name. A pinned lane is the only one of the two whose identity is stable enough to
# carry a TREND. Same class as `provider:"open-meteo"` being a dispatch key, one level out.
# Kill: FORECAST_SKILL_OM_CONTROL=0.
# ⚠️ THE MODEL ID IS `ncep_gfswave025`, VERIFIED AGAINST THE LIVE API, NOT GUESSED. My first guess
# was `gfs_wave` and Open-Meteo answers that with an ERROR OBJECT ("Cannot initialize MultiDomains
# from invalid..."), which `json.load` parses happily and which has no `hourly` key — so the lane
# would have produced ZERO ROWS FOREVER AND SAID NOTHING. That is why `_om_payload_error` below
# exists: a wrong model name must fail LOUDLY, because a silent empty lane is indistinguishable
# from "the control agrees with us", which is the exact conclusion this lane is here to test.
# Live probe, same coordinate: ncep_gfswave025 / gwam / meteofrance_wave / best_match all return
# 24 non-null hours; `gfs_wave` and `gfswave` error; `ecmwf_wam025` returns 24 NULLS (coverage).
# ★ `ncep_gfswave025` is also the exact `source_dataset` string our own GFS lane stamps, so this is
# demonstrably the same model, not merely a similarly-named one.
SOURCE_OM_GFS = "open_meteo:ncep_gfswave025"
OM_CONTROL_MODEL = "ncep_gfswave025"
# ⭐ THE PERSISTENCE BASELINE (2026-08-09, MASTER-AUDIT-11.0 Phase 0). "Tomorrow = today" is the
# reference every operational centre scores against: a model that cannot beat persistence at a lead
# is not adding value at that lead, and WITHOUT this row the ledger's only reference is a
# competitor lane — which tells you who is better, never whether either is earning its keep.
# Zero extra requests: the forecast IS the buoy's current observation from the report the ledger
# already receives. Kill: FORECAST_SKILL_PERSISTENCE=0.
SOURCE_PERSISTENCE = "persistence"

# ⭐⭐⭐ SCORE EVERY MODEL WE COULD SERVE, NOT JUST THE ONE WE DO (2026-08-03).
# The ledger scored only `BUOY_CALIBRATION_MODEL` (default GFS) — which is also `/spot-ratings`'
# default — against Open-Meteo's best-match blend. Reading the archive for the first time, PAIRED on
# (buoy, target hour, lead) over 3,852 cells: ours MAE 0.304 m vs theirs 0.199 m, we win 35-43% of
# cells, at 42 of 59 buoys, with ~zero bias on BOTH sides. Scatter, not an offset a constant fixes.
# ★ Then the obvious question nobody had asked: is that a RAW-SURF gap or a GFS gap? Measured live
#   at 60 buoys, one hour, same coordinates and valid_time, 100% paired
#   (`scripts/model_skill_census.py`):
#       GFS  MAE 0.388   ICON MAE 0.324   EURO MAE 0.223   (EURO closest at 29 of 60 buoys)
#   and EURO wins EVERY observed-height band, worst for GFS on flat water (0.616 vs 0.263 — over-
#   reading a calm day is the app inventing surf). EURO lands on Open-Meteo's own number, which is
#   what you would expect if both are ECMWF.
# ⇒ The default-model decision is worth far more than any rating-constant tuning, and it must NOT be
#   made on one hour. This makes the ledger accumulate per-model skill continuously so the decision
#   is evidence, not a snapshot.
# ⚠️ COST, priced as a multiple (rule 21): each extra model is one more `calibrate_spots` per lead,
#   so the default here is 3x the ledger's resolve work. It runs in the CALIBRATION lane (GitHub
#   Actions: forecast-ingest.yml / precompute.yml), NOT on the 1-CPU serve box with the melt history.
#   Kill with FORECAST_SKILL_COMPARE_MODELS='' (empty restores the exact previous behaviour).
# ⚠️ ADDITIVE ON PURPOSE: the primary model keeps the bare `raw_surf` source so the existing archive
#   stays one continuous series. Comparison models get `raw_surf:MODEL`, so nothing already scored
#   changes meaning — a source rename would have silently split the history at today's date.
COMPARE_MODELS_DEFAULT = "ICON,EURO"


def compare_models(primary: str) -> List[str]:
    """Extra models to ledger beside `primary`, from FORECAST_SKILL_COMPARE_MODELS. Never includes
    the primary (that would double-count it under two source names)."""
    raw = os.environ.get("FORECAST_SKILL_COMPARE_MODELS", COMPARE_MODELS_DEFAULT)
    out = []
    for m in (raw or "").split(","):
        m = m.strip().upper()
        if m and m != (primary or "").strip().upper() and m not in out:
            out.append(m)
    # THE CONSENSUS SHADOW LANE (2026-09-29, D-009): the switch that builds the shadow product also grades it,
    # so the ledger scores `raw_surf:CONSENSUS` on the same buoys, hours and leads as every member.
    from services.weather_pipeline.consensus_ingest import CONSENSUS_MODEL, enabled as consensus_enabled
    if consensus_enabled() and CONSENSUS_MODEL not in out and CONSENSUS_MODEL != (primary or "").strip().upper():
        out.append(CONSENSUS_MODEL)
    # THE RAW GFS BASELINE while the consensus is SERVED (consensus_serve, D-009): the primary lane then scores the
    # served consensus, so raw GFS keeps its own lane, resolved under serve_raw().
    if os.environ.get("CONSENSUS_SERVE", "0") == "1" and (primary or "").strip().upper() == "GFS":
        out.append(GFS_RAW)
    # THE SCALAR-HEIGHT SHADOW (2026-09-30 audit): while SAMPLER_SCALAR_HEIGHT is dark, SAMPLER_SCALAR_LEDGER grades
    # the served GFS product sampled with a SCALAR height (sampler.force_scalar_height) on the same buoys, hours and
    # leads as the served lane, so the flip is decided on paired buoy truth. Once the switch serves, the primary lane
    # IS the scalar answer and the shadow would count it twice, so it retires itself.
    if (os.environ.get("SAMPLER_SCALAR_LEDGER", "0") == "1" and os.environ.get("SAMPLER_SCALAR_HEIGHT", "0") != "1"
            and (primary or "").strip().upper() == "GFS"):
        out.append(GFS_SCALAR)
    return out


GFS_RAW = "GFS_RAW"
GFS_SCALAR = "GFS_SCALAR"


def source_for(model: str, primary: str) -> str:
    """`raw_surf` for the model we actually serve, `raw_surf:MODEL` for a comparison lane."""
    return SOURCE_OURS if (model or "").upper() == (primary or "").upper() else f"{SOURCE_OURS}:{model.upper()}"


def _parse_iso(v):
    if not v:
        return None
    try:
        dt = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def _lead_bucket(lead_h: float) -> int:
    return int(round(lead_h / 24.0))


def dedupe_key(row) -> tuple:
    return (row.get("source"), row.get("buoy_id"), row.get("target_time"),
            _lead_bucket(row.get("lead_h") or 0))


def rows_from_calibration_report(report, target_time: str, lead_h: float,
                                 source: str = SOURCE_OURS) -> List[dict]:
    """Our model's forecast rows for one target hour, from a calibrate_spots report resolved AT
    that hour. One row per distinct buoy; buoy obs fields in the report are ignored (they are
    today's sea, not the target's).

    ``source`` defaults to `raw_surf` so every existing caller is byte-identical; a comparison lane
    passes `raw_surf:MODEL` (see `source_for`)."""
    rows, seen = [], set()
    for entry in (report or {}).get("spots") or []:
        bid = entry.get("buoy_id")
        res = entry.get("residual") or {}
        hs = res.get("model_hs_m")
        if bid is None or bid in seen or hs in (None, 0.0):
            continue
        seen.add(bid)
        # WHICH product, frame and cycle answered (skill_attribution): the paired gap to the same-model
        # control can only be split by what the row records. Absent keys = unknown, never guessed.
        from services.weather_pipeline.skill_attribution import serving_provenance
        served = entry.get("served") or {}
        row = {"source": source, "buoy_id": bid, "target_time": target_time,
               "lead_h": round(lead_h, 1), "hs_m": hs, "tp_s": res.get("model_tp_s"),
               **serving_provenance(served.get("product"), served.get("cycle"), target_time, lead_h)}
        if res.get("model_dir_deg") is not None:    # S8 (skill_direction_period); absent = not recorded
            row["dir_deg"] = res["model_dir_deg"]
        wres = entry.get("wind_residual") or {}      # S9: the lane's forecast wind at the target hour (knots)
        if wres.get("model_wspd_kt") is not None:
            row["wind_kt"] = wres["model_wspd_kt"]
        if wres.get("model_wdir_deg") is not None:
            row["wind_from_deg"] = wres["model_wdir_deg"]
        rows.append(row)
    return rows


def persistence_rows_from_report(report, now: datetime, leads_h=LEADS_H) -> List[dict]:
    """One persistence row per (buoy, lead): the forecast for now+lead is the buoy's CURRENT
    observation. One row per distinct buoy (spots share buoys), rows without a current observation
    are skipped — a persistence forecast from a dark buoy would be a fabrication."""
    rows, seen = [], set()
    for entry in (report or {}).get("spots") or []:
        bid = entry.get("buoy_id")
        obs = (entry.get("residual") or {}).get("buoy_wvht_m")
        if bid is None or bid in seen or not isinstance(obs, (int, float)):
            continue
        seen.add(bid)
        mwd = (entry.get("residual") or {}).get("buoy_mwd_deg")
        wres = entry.get("wind_residual") or {}
        for lead in leads_h:
            target = (now + timedelta(hours=lead)).strftime("%Y-%m-%dT%H:00:00Z")
            row = {"source": SOURCE_PERSISTENCE, "buoy_id": bid, "target_time": target,
                   "lead_h": float(lead), "hs_m": obs,
                   "tp_s": (entry.get("residual") or {}).get("buoy_dpd_s")}
            if mwd is not None:                        # persistence is S8's no-skill reference too
                row["dir_deg"] = mwd
            if wres.get("buoy_wspd_kt") is not None:   # ... and S9's
                row["wind_kt"] = wres["buoy_wspd_kt"]
                if wres.get("buoy_wdir_deg") is not None:
                    row["wind_from_deg"] = wres["buoy_wdir_deg"]
            rows.append(row)
    return rows


def _om_payload_error(payload) -> Optional[str]:
    """The `reason` from an Open-Meteo error response, or None if the payload looks like data.

    Open-Meteo signals a bad request with HTTP 200 + {"error": true, "reason": "..."} , so the
    HTTP layer cannot catch it and `json.load` cannot either. Checks every element because the
    multi-coordinate form returns a LIST and one bad coordinate is still a broken request.
    """
    for loc in (payload or []):
        if isinstance(loc, dict) and loc.get("error"):
            return str(loc.get("reason") or "unspecified")[:200]
    return None


def fetch_om_forecast_rows(buoys: Dict[str, tuple], now: datetime,
                           leads_h=LEADS_H, timeout: int = 60,
                           model: Optional[str] = None,
                           source: Optional[str] = None) -> List[dict]:
    """The competitor lane: ONE batched multi-coordinate Open-Meteo marine forecast call for every
    mapped buoy, sliced at each lead's target hour. `buoys` maps buoy_id -> (lat, lng).

    `model=None` (the default) sends NO `models=` parameter and therefore requests Open-Meteo's
    `best_match` — byte-identical to every call that existed before this argument did, so the
    existing archive series keeps its meaning. `model="gfs_wave"` pins the SAME-MODEL CONTROL
    (see SOURCE_OM_GFS); `source` then names it so the two lanes never merge into one series.
    """
    if not buoys:
        return []
    ids = list(buoys.keys())
    lats = ",".join(f"{buoys[b][0]:.4f}" for b in ids)
    lngs = ",".join(f"{buoys[b][1]:.4f}" for b in ids)
    url = (f"{OM_MARINE}?latitude={lats}&longitude={lngs}"
           f"&hourly=wave_height,swell_wave_period&forecast_days=4&timezone=UTC")
    if model:
        url += f"&models={model}"
    src = source or (SOURCE_OM if not model else f"open_meteo:{model}")
    req = urllib.request.Request(url, headers={"User-Agent": "raw-surf-skill"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        payload = json.load(r)
    if isinstance(payload, dict):
        payload = [payload]
    # REFUSE RATHER THAN RETURN EMPTY. Open-Meteo answers a bad `models=` with HTTP 200 and a JSON
    # error object, which parses fine and simply carries no `hourly` — so the loop below would emit
    # zero rows and the lane would look "in agreement" forever. An empty competitor lane must be
    # loud; see the OM_CONTROL_MODEL block for the guess that would have shipped exactly that.
    err = _om_payload_error(payload)
    if err:
        raise ValueError(f"Open-Meteo rejected the request (model={model or 'best_match'}): {err}")
    rows = []
    for bid, loc in zip(ids, payload):
        h = (loc or {}).get("hourly") or {}
        times, heights = h.get("time") or [], h.get("wave_height") or []
        periods = h.get("swell_wave_period") or []
        index = {t: i for i, t in enumerate(times)}
        for lead in leads_h:
            target = (now + timedelta(hours=lead)).strftime("%Y-%m-%dT%H:00")
            i = index.get(target)
            if i is None or i >= len(heights) or heights[i] is None:
                continue
            # ⛔ 0.0 IS A COVERAGE HOLE, NOT A FLAT SEA — and skipping it here is what makes this
            # comparison FAIR. `rows_from_calibration_report` has always dropped `hs in (None, 0.0)`
            # for OUR lane; the Open-Meteo lanes did not, so a null-as-zero entered the ledger as a
            # forecast of "flat" and scored against a real observation. Found live 2026-08-10 while
            # first exercising the control: pinned `ncep_gfswave025` returns 0.00 m at Waimea
            # (51201) for all three leads while best_match returns 1.20/1.34/1.48 m. Left in, those
            # rows would have made the SAME-MODEL control look far worse than our chain and
            # produced exactly the wrong verdict — a defect manufactured by the instrument.
            if heights[i] == 0.0:
                continue
            rows.append({"source": src, "buoy_id": bid,
                         "target_time": target + ":00Z", "lead_h": float(lead),
                         "hs_m": heights[i],
                         "tp_s": periods[i] if i < len(periods) else None})
    return rows


def merge_pending(existing, incoming, now: Optional[datetime] = None,
                  max_entries: int = PENDING_MAX_ENTRIES,
                  stats: Optional[dict] = None) -> List[dict]:
    """Append forecasts, keeping the EARLIEST row per dedupe key (the honest lead) and dropping
    rows whose target passed more than PENDING_EXPIRY_H ago (a buoy gap nobody can score).

    ⚠️ THE CAP EVICTS THE FURTHEST-FUTURE TARGETS FIRST (2026-08-08). It used to keep them —
    `out[-max_entries:]` after the ascending sort — which evicts each row exactly as its target
    hour approaches, so once demand exceeded the cap NOTHING could ever score: production logged
    scored=0 on every run from 08-04T12:36Z (the pre-fan-out control 30839909407 was healthy).
    Keeping the EARLIEST targets makes overflow starve only the farthest lead — measured
    100/95.4/9.5% per lead at the old cap versus 0/0/0% — a degradation instead of an outage.
    `stats`, when given, is filled with {kept, expired, cap_evicted} so eviction is observable
    rather than invisible for four days again."""
    now = now or datetime.now(timezone.utc)
    horizon = now - timedelta(hours=PENDING_EXPIRY_H)
    out, seen = [], set()
    expired = 0
    for row in list(existing or []) + list(incoming or []):
        t = _parse_iso(row.get("target_time"))
        if t is None or t < horizon:
            expired += 1
            continue
        key = dedupe_key(row)
        if key in seen:
            continue          # first wins: existing rows precede incoming ⇒ earliest lead kept
        seen.add(key)
        out.append(row)
    out.sort(key=lambda r: (r.get("target_time") or "", r.get("source") or "", r.get("buoy_id") or ""))
    kept = out[:max_entries] if max_entries else out
    if stats is not None:
        stats.update(kept=len(kept), expired=expired, cap_evicted=len(out) - len(kept))
    return kept


def score_pending(pending, report, now: Optional[datetime] = None, stats: Optional[dict] = None):
    """Split pending into (still_pending, scored): a row scores when THIS run's report holds a
    finite nonnegative buoy observation within tolerance of its target hour.

    Invalid forecast heights cannot be recovered by waiting and are rejected, with optional
    counts for the operator report. Valid forecasts retain the existing expiry policy when
    this report has no eligible observation. Explicit calm zero is distinct from missing.
    """
    now = now or datetime.now(timezone.utc)
    obs = {}
    invalid_forecasts = invalid_observations = 0
    for entry in (report or {}).get("spots") or []:
        bid = entry.get("buoy_id")
        res = entry.get("residual") or {}
        bt = _parse_iso(entry.get("buoy_time"))
        if bid is None or bt is None:
            continue
        height = res.get("buoy_wvht_m")
        if not _finite_number(height) or height < 0.0:
            invalid_observations += 1
            continue
        wres = entry.get("wind_residual") or {}         # fresh anemometer reading (age-gated upstream), S9
        obs.setdefault(bid, []).append((bt, height, res.get("buoy_dpd_s"), res.get("buoy_mwd_deg"), res.get("buoy_apd_s"),
                                        wres.get("buoy_wspd_kt"), wres.get("buoy_wdir_deg")))
    still, scored = [], []
    for row in pending or []:
        t = _parse_iso(row.get("target_time"))
        if t is None:
            continue
        height = row.get("hs_m")
        if not _finite_number(height) or height < 0.0:
            invalid_forecasts += 1
            continue
        candidates = obs.get(row.get("buoy_id")) or []
        best = None
        for bt, wvht, dpd, mwd, apd, wkt, wdir in candidates:
            dt_s = abs((bt - t).total_seconds())
            if dt_s <= SCORE_JOIN_TOLERANCE_S and (best is None or dt_s < best[0]):
                best = (dt_s, bt, wvht, dpd, mwd, apd, wkt, wdir)
        if best is not None:
            done = {**row, "obs_time": best[1].isoformat(),
                    "obs_hs_m": best[2], "obs_dpd_s": best[3],
                    "err_m": round(height - best[2], 4)}
            if best[4] is not None:                    # S8's verifying direction and the bimodal flag's APD
                done["obs_mwd_deg"] = best[4]
            if best[5] is not None:
                done["obs_apd_s"] = best[5]
            if best[6] is not None:                    # S9's verifying wind (knots, direction FROM)
                done["obs_wind_kt"] = best[6]
                if best[7] is not None:
                    done["obs_wind_from_deg"] = best[7]
            scored.append(done)
        elif t > now - timedelta(hours=PENDING_EXPIRY_H):
            still.append(row)
        # else: expired unmatched — dropped
    if stats is not None:
        stats.update(invalid_forecasts=invalid_forecasts, invalid_observations=invalid_observations)
    return still, scored


# ⭐⭐⭐ THE MEASUREMENT GATES EVERY ACCURACY DECISION (MASTER AUDIT 1.0 §8.1, 2026-08-03).
# The ledger reported BIAS and MAE and nothing else. That pair cannot answer the question the
# archive was built to settle: reading it for the first time gave ours MAE 0.304 vs Open-Meteo's
# 0.199 at ~ZERO BIAS ON BOTH SIDES — so the gap is SCATTER, and a scatter gap is invisible to the
# two numbers being reported. Every accuracy lever in the queue (Kr, the quantile map, H110, the
# default-model flip) is a constant chosen against a target this summary could not measure.
#
# These are the metrics operational wave centres verify on (Bidlot et al.; ECMWF/NOAA wave
# verification), and each answers a DIFFERENT failure:
#   rmse_m      penalises large misses — with bias ~0 this is the scatter, in metres
#   si          DE-BIASED scatter index = rms(err - bias) / mean(obs). The normalised standard;
#               it is the number that stays comparable across buoys of different sea state
#   corr        does the forecast move WITH the sea at all, or is it flat?
#   sym_slope   sqrt(sum f^2 / sum o^2) — amplitude ratio treating both axes symmetrically.
#               >1 over-reads, <1 under-reads. Unlike bias this survives a symmetric error.
#
# ★ THE REFUSAL (rule: a check that cannot tell "not sampled" from "broken" must REFUSE). Every
#   shape metric is None below `MIN_N_FOR_SHAPE` or on a degenerate denominator, never 0.0 — an
#   r of 1.0 from n=2 and an SI of 0.0 from mean_obs=0 are both indistinguishable from excellence.
# ★ `n` KEEPS ITS OLD MEANING (rows carrying `err_m`) so the existing archive stays one series;
#   `n_paired` is the count that the new metrics were actually computed over. When a row carries
#   `err_m` but not both sides, those two numbers differ — and that difference is the instrument
#   telling you it was starved rather than quietly averaging fewer points.
MIN_N_FOR_SHAPE = 10

# Bands chosen by what they mean to a surfer, not by equal counts: flat / small / rideable / big.
# ⚠️ CANONICAL HERE, imported by `scripts/model_skill_census.py`. A duplicated constant diverges
# only on a boundary, and this repo has already paid for seven copies of one (`e6d4b5b9`).
OBS_BANDS = ((0.0, 0.5, "flat <0.5m"), (0.5, 1.5, "small 0.5-1.5m"),
             (1.5, 3.0, "rideable 1.5-3m"), (3.0, 99.0, "big >3m"))


def obs_band(obs_m) -> Optional[str]:
    """The surfer-meaningful band an observation falls in, or None if it is not a number."""
    if not isinstance(obs_m, (int, float)):
        return None
    for lo, hi, label in OBS_BANDS:
        if lo <= obs_m < hi:
            return label
    return None


def _finite_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def verification_metrics(pairs) -> Optional[dict]:
    """Operational wave-verification metrics over (forecast_m, observed_m) pairs, or None if empty.

    Shape metrics (si/corr/sym_slope) are None rather than a number whenever they would be
    unstable or undefined — see MIN_N_FOR_SHAPE above for why that matters more than coverage."""
    fo = [(f, o) for f, o in (pairs or []) if _finite_number(f) and _finite_number(o)]
    n = len(fo)
    if n == 0:
        return None
    fs = [f for f, _ in fo]
    obs = [o for _, o in fo]
    errs = [f - o for f, o in fo]
    mean_f, mean_o = sum(fs) / n, sum(obs) / n
    bias = mean_f - mean_o
    out = {
        "n_paired": n,
        "mean_obs_m": round(mean_o, 4), "mean_fc_m": round(mean_f, 4),
        "bias_m": round(bias, 4),
        "mae_m": round(sum(abs(e) for e in errs) / n, 4),
        "rmse_m": round(math.sqrt(sum(e * e for e in errs) / n), 4),
        "si": None, "corr": None, "sym_slope": None,
    }
    if n < MIN_N_FOR_SHAPE:
        return out
    if mean_o > 0:
        scatter = math.sqrt(sum((e - bias) ** 2 for e in errs) / n)
        out["si"] = round(scatter / mean_o, 4)
    df = [f - mean_f for f in fs]
    do = [o - mean_o for o in obs]
    den = math.sqrt(sum(x * x for x in df) * sum(y * y for y in do))
    if den > 0:
        out["corr"] = round(sum(x * y for x, y in zip(df, do)) / den, 4)
    sum_oo = sum(o * o for o in obs)
    if sum_oo > 0:
        out["sym_slope"] = round(math.sqrt(sum(f * f for f in fs) / sum_oo), 4)
    return out


def head_to_head(scored_rows, primary: str = SOURCE_OURS,
                 diagnostics: Optional[dict] = None) -> List[dict]:
    """PAIRED comparison of `primary` against every other source, on the EXACT SAME
    (buoy_id, target_time, lead-bucket) keys AND the same verifying observation.

    Matching target hours alone does not establish observation parity: score_pending allows
    observations within 90 minutes, and different scoring runs can select different ones.
    Missing observation identity is ungradeable. Optional diagnostics expose exclusions even
    when no valid comparison survives; existing callers still receive a list of scored pairs.

    ⛔⛔ WHY THIS EXISTS — IT CAUGHT A FALSE ALARM, MINE, ON 2026-08-10. `skill_summary` groups each
    source INDEPENDENTLY, so its MAE column compares DIFFERENT POPULATIONS. Read across that column
    and the archive said `raw_surf` 0.268 vs `persistence` 0.206 — "we lose to the trivial
    baseline", which was reported as a finding. It is an artifact: `raw_surf` spanned 2,825 rows
    over 64 target times, `persistence` 374 rows over SEVEN, because `persistence_rows_from_report`
    only emits for buoys carrying a live observation. On the identical 374 keys we WIN, 0.183 vs
    0.206. The unpaired column had inverted the sign of the answer.

    ★★★ PARITY OF STATISTIC IS NOT PARITY OF POPULATION. A per-source MAE table invites a
    comparison it cannot support, so the comparison is computed here instead of left to the reader.

    Emits `n_ours_total` / `n_theirs_total` beside `n_paired` on purpose: when those three diverge
    the populations differ, which is exactly the condition that made the raw column misleading.
    `win_rate` is the fraction of paired keys where our absolute error is strictly smaller — a
    median-free view, because one storm can move an MAE and cannot move a win rate.
    """
    by_source: Dict[str, Dict[tuple, dict]] = {}
    invalid_errors = 0
    for r in scored_rows or []:
        e = r.get("err_m")
        if not _finite_number(e):
            invalid_errors += 1
            continue
        key = (r.get("buoy_id"), r.get("target_time"), _lead_bucket(r.get("lead_h") or 0))
        by_source.setdefault(r.get("source"), {})[key] = r

    ours = by_source.get(primary) or {}
    out = []
    exclusions = []
    for source in sorted(k for k in by_source if k != primary):
        theirs = by_source[source]
        for bucket in sorted({k[2] for k in ours} | {k[2] for k in theirs}):
            candidates = [k for k in ours if k[2] == bucket and k in theirs]
            if not candidates:
                continue
            common = []
            missing = mismatched = 0
            for key in candidates:
                our_obs, their_obs = ours[key], theirs[key]
                our_time, their_time = _parse_iso(our_obs.get("obs_time")), _parse_iso(their_obs.get("obs_time"))
                our_h, their_h = our_obs.get("obs_hs_m"), their_obs.get("obs_hs_m")
                if (our_time is None or their_time is None
                        or not _finite_number(our_h) or not _finite_number(their_h)):
                    missing += 1
                elif our_time != their_time or our_h != their_h:
                    mismatched += 1
                else:
                    common.append(key)
            n = len(common)
            excluded = {"source": source, "lead_h": bucket * 24,
                        "n_target_matched": len(candidates), "n_paired": n,
                        "n_observation_mismatch": mismatched, "n_observation_missing": missing}
            exclusions.append(excluded)
            if not n:
                continue
            mo = sum(abs(ours[k]["err_m"]) for k in common) / n
            mt = sum(abs(theirs[k]["err_m"]) for k in common) / n
            wins = sum(1 for k in common if abs(ours[k]["err_m"]) < abs(theirs[k]["err_m"]))
            out.append({
                **excluded,
                "n_ours_total": sum(1 for k in ours if k[2] == bucket),
                "n_theirs_total": sum(1 for k in theirs if k[2] == bucket),
                "mae_ours_m": round(mo, 4), "mae_theirs_m": round(mt, 4),
                "delta_m": round(mo - mt, 4),
                "win_rate": round(wins / n, 4),
                "we_lose": mo > mt,
            })
    if diagnostics is not None:
        diagnostics.update(invalid_error_rows=invalid_errors, comparisons=exclusions)
    return out


def skill_summary(scored_rows) -> List[dict]:
    """Per source x lead-bucket: n, n_buoys, bias, MAE — plus RMSE / scatter index / correlation /
    symmetric slope, and the same metrics per observed-height band.

    ⚠️ A single MAE hides the SHAPE. Measured at 60 buoys, GFS's error was concentrated on FLAT
    seas (0.616 vs EURO's 0.263) — over-reading a calm day is the app inventing surf, and it is the
    error a surfer notices most while contributing least to the average."""
    groups: Dict[tuple, List[dict]] = {}
    for r in scored_rows or []:
        if not _finite_number(r.get("err_m")):
            continue
        groups.setdefault((r.get("source"), _lead_bucket(r.get("lead_h") or 0)), []).append(r)
    out = []
    for (source, bucket), rows in sorted(groups.items()):
        errs = [r["err_m"] for r in rows]
        row = {"source": source, "lead_h": bucket * 24, "n": len(errs),
               "n_buoys": len({r.get("buoy_id") for r in rows}),
               "bias_m": round(sum(errs) / len(errs), 4),
               "mae_m": round(sum(abs(e) for e in errs) / len(errs), 4)}
        pairs = [(r.get("hs_m"), r.get("obs_hs_m")) for r in rows]
        metrics = verification_metrics(pairs)
        if metrics:
            # `bias_m`/`mae_m` above are computed from `err_m` and stay authoritative; the paired
            # recomputation only ADDS fields, so a row missing one side cannot change the series.
            row.update({k: v for k, v in metrics.items() if k not in ("bias_m", "mae_m")})
            bands = {}
            for lo, hi, label in OBS_BANDS:
                sub = [(r.get("hs_m"), r.get("obs_hs_m")) for r in rows
                       if obs_band(r.get("obs_hs_m")) == label]
                m = verification_metrics(sub)
                if m:
                    bands[label] = m
            if bands:
                row["by_obs_band"] = bands
        out.append(row)
    return out


async def run_skill_ledger(store, resolver, spots, model: str, report,
                           now: Optional[datetime] = None) -> Optional[dict]:
    """The wired entry point (guarded by the caller): ledger new forecasts, score arrivals.
    Returns {"ledgered": n, "scored": n, "summary": [...]} or None when disabled."""
    if os.environ.get("FORECAST_SKILL", "1") == "0":
        return None
    from services.weather_pipeline.buoy_calibration import (
        calibrate_spots, fetch_ndbc_station_coords, load_calibration_rows_l2, upload_calibration_l2,
    )
    now = now or datetime.now(timezone.utc)
    incoming: List[dict] = []
    # The served model first, then any comparison models — each is an INDEPENDENT source, so one
    # model failing a lead never removes another's row. See COMPARE_MODELS_DEFAULT for the cost.
    for mdl in [model] + compare_models(model):
        src = source_for(mdl, model)
        for lead in LEADS_H:
            target = (now + timedelta(hours=lead)).strftime("%Y-%m-%dT%H:00:00Z")
            try:
                if mdl == GFS_RAW:                   # raw GFS, not the served consensus (compare_models)
                    from services.weather_pipeline.consensus_serve import serve_raw
                    with serve_raw():
                        lead_report = await calibrate_spots(resolver, spots, "GFS", target)
                elif mdl == GFS_SCALAR:              # the served GFS, sampled with a scalar height (compare_models)
                    from services.weather_pipeline.sampler import force_scalar_height
                    with force_scalar_height():
                        lead_report = await calibrate_spots(resolver, spots, "GFS", target)
                else:
                    lead_report = await calibrate_spots(resolver, spots, mdl, target)
                incoming.extend(rows_from_calibration_report(lead_report, target, lead, source=src))
            except Exception as e:
                logger.warning("[forecast-skill] %s lead +%dh resolve failed (%s)", src, lead, e)
    if os.environ.get("FORECAST_SKILL_PERSISTENCE", "1") != "0":
        incoming.extend(persistence_rows_from_report(report, now))
    try:
        coords = await fetch_ndbc_station_coords()
        buoys = {}
        for entry in (report or {}).get("spots") or []:
            bid = entry.get("buoy_id")
            if bid and bid in coords and bid not in buoys:
                buoys[bid] = coords[bid]
        incoming.extend(fetch_om_forecast_rows(buoys, now))
        # The SAME-MODEL CONTROL, in its OWN try so a failure here can never cost us the
        # competitor lane that already works. One extra batched request per run, not per buoy.
        if os.environ.get("FORECAST_SKILL_OM_CONTROL", "1") != "0":
            try:
                incoming.extend(fetch_om_forecast_rows(
                    buoys, now, model=OM_CONTROL_MODEL, source=SOURCE_OM_GFS))
            except Exception as e:
                logger.warning("[forecast-skill] OM same-model control lane failed (%s)", e)
    except Exception as e:
        logger.warning("[forecast-skill] competitor lane failed (%s)", e)

    pending, pending_exists = load_calibration_rows_l2(SKILL_PENDING_L2_KEY)
    merge_stats: Dict[str, int] = {}
    pending = merge_pending(pending, incoming, now=now, stats=merge_stats)
    score_stats: Dict[str, int] = {}
    still, scored = score_pending(pending, report, now=now, stats=score_stats)
    archives = []
    reads: Dict[str, tuple] = {}

    def load(key):                       # one read per object per pass: the frozen month is ~50 MB
        if key not in reads:
            reads[key] = load_calibration_rows_l2(key)
        return reads[key]

    if scored:
        groups: Dict[str, List[dict]] = {}
        for r in scored:
            groups.setdefault(archive_keys.key_for_target(_parse_iso(r.get("target_time"))), []).append(r)
        for key, rows in groups.items():
            existing, exists = load(key)
            seen = {dedupe_key(r) for r in existing}
            fresh = [r for r in rows if dedupe_key(r) not in seen]
            frozen = archive_keys.month_object_of(key)       # a day's rows also dedupe against the frozen month
            if fresh and frozen:
                seen = {dedupe_key(r) for r in load(frozen)[0]}
                fresh = [r for r in fresh if dedupe_key(r) not in seen]
            if fresh:
                archives.append((key, existing + fresh, exists))
    # Preflight every touched month before any write. A partial archive write is
    # safe to retry by dedupe; consume pending only after every archive acknowledges.
    # This is not CAS: concurrent successful read/modify/write updates remain separate.
    for key, rows, exists in archives:
        upload_calibration_l2(store, rows, key, strict=True, overwrite=exists)
    upload_calibration_l2(store, still, SKILL_PENDING_L2_KEY,
                          strict=True, overwrite=pending_exists)
    summary = skill_summary(scored)
    # ⚠️ The `ledgered=%d scored=%d` prefix is an operator surface: it is the string the Actions-log
    # grep dated the 08-04 outage with. Append fields, never reorder it.
    logger.info("[forecast-skill] ledgered=%d scored=%d pending=%d evicted_cap=%d invalid_forecasts=%d invalid_observations=%d %s",
                len(incoming), len(scored), len(still), merge_stats.get("cap_evicted", 0),
                score_stats["invalid_forecasts"], score_stats["invalid_observations"],
                summary if summary else "")
    # ── SHADOW MOS (roadmap stage 5, step 1) — measurement only, after every write has landed ──
    # Its own try and its own kill switch (FORECAST_SKILL_MOS=0): a read or fit failure here costs
    # the shadow block and nothing else. See skill_mos.py.
    mos = attribution = consensus = dirper = None
    if os.environ.get("FORECAST_SKILL_MOS", "1") != "0":
        try:
            from services.weather_pipeline.skill_attribution import same_model_attribution
            from services.weather_pipeline.skill_mos import shadow_report
            history = mos_history_rows(now, archives, load)
            mos = shadow_report(history, now)
            # WHERE the paired same-model gap comes from (tier / frame snap / cycle age). Same history,
            # same guard: a failure costs these two blocks and nothing else.
            attribution = same_model_attribution(history)
            # The three-model consensus (stage 5) on the same scored history: measurement only.
            from services.weather_pipeline.skill_consensus import consensus_report, shadow_report as consensus_shadow
            consensus = consensus_report(history, now)
            # The BUILT shadow (D-009) beside what it was built from: published inside the same block.
            consensus["shadow"] = consensus_shadow(history, now)
            # S7/S8: period and direction on the same history (skill_direction_period); its own guard.
            try:
                from services.weather_pipeline.skill_direction_period import direction_period_report
                dirper = direction_period_report(history, now)
            except Exception as e:
                logger.warning("[forecast-skill] direction/period block skipped (%s)", e)
        except Exception as e:
            logger.warning("[forecast-skill] MOS shadow skipped (%s)", e)
    return {"ledgered": len(incoming), "scored": len(scored),
            "pending_kept": len(still), "pending_evicted_cap": merge_stats.get("cap_evicted", 0),
            "summary": summary, "scoring_rejections": score_stats, "mos_shadow": mos,
            "same_model_attribution": attribution, "consensus": consensus, "direction_period": dirper}


def mos_history_rows(now: datetime, archives, load_rows) -> List[dict]:
    """The scored rows of this month and the previous one: the shadow MOS's training and held-out
    window. An object this run just wrote is taken from `archives` rather than read back."""
    prev = now.replace(day=1) - timedelta(days=1)
    written = {key: rows for key, rows, _ in archives}
    through = (now.astimezone(timezone.utc) + timedelta(days=1)).date()     # tolerance lets a row sit past `now`
    rows: List[dict] = []
    for month in (prev, now):
        rows.extend(archive_keys.read_month(f"{month:%Y-%m}", through, load_rows, override=written)[0])
    return rows


def attach_to_report(report, skill) -> None:
    """Write the skill block onto the calibration report. PRESENT-BUT-EMPTY IS DELIBERATE:
    with the old `if skill.get("summary")` guard, scored=0 for four days (08-04 -> 08-08) was
    byte-identical on the wire to "the ledger never ran", so the outage was only datable from CI
    logs. `forecast_skill` keeps its existing shape (a list); `forecast_skill_ops` carries the
    counts — `pending_evicted_cap` > 0 is the early signal the last starvation never gave."""
    if report is None or skill is None:
        return
    report["forecast_skill"] = skill.get("summary") or []
    report["forecast_skill_ops"] = {k: skill.get(k) for k in
                                    ("ledgered", "scored", "pending_kept", "pending_evicted_cap")}
    if "scoring_rejections" in skill:
        report["forecast_skill_ops"]["scoring_rejections"] = skill["scoring_rejections"]
    if skill.get("mos_shadow") is not None:
        report["forecast_skill_mos_shadow"] = skill["mos_shadow"]
    if skill.get("same_model_attribution") is not None:
        report["forecast_skill_same_model"] = skill["same_model_attribution"]
    if skill.get("consensus") is not None:
        report["forecast_skill_consensus"] = skill["consensus"]
    if skill.get("direction_period") is not None:
        report["forecast_skill_direction_period"] = skill["direction_period"]
